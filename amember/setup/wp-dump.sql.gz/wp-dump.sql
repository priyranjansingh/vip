-- MySQL dump 10.13  Distrib 5.1.69, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: amember-build
-- ------------------------------------------------------
-- Server version	5.1.69-0ubuntu0.10.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `am_access`
--

DROP TABLE IF EXISTS `am_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_access` (
  `access_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `invoice_payment_id` int(11) DEFAULT NULL,
  `invoice_item_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `transaction_id` varchar(64) DEFAULT NULL,
  `begin_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '1',
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`access_id`),
  UNIQUE KEY `invoice_id_2` (`invoice_id`,`user_id`,`product_id`,`transaction_id`),
  KEY `user_id` (`user_id`),
  KEY `invoice_id` (`invoice_id`,`invoice_item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_access`
--

LOCK TABLES `am_access` WRITE;
/*!40000 ALTER TABLE `am_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_access_cache`
--

DROP TABLE IF EXISTS `am_access_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_access_cache` (
  `user_id` int(11) NOT NULL,
  `fn` enum('product_id','product_category_id') NOT NULL,
  `id` int(11) NOT NULL,
  `days` int(11) DEFAULT NULL,
  `begin_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `status` enum('active','expired') NOT NULL,
  UNIQUE KEY `speed` (`user_id`,`fn`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_access_cache`
--

LOCK TABLES `am_access_cache` WRITE;
/*!40000 ALTER TABLE `am_access_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_access_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_access_log`
--

DROP TABLE IF EXISTS `am_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_access_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `remote_addr` varchar(15) DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`,`time`,`remote_addr`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_access_log`
--

LOCK TABLES `am_access_log` WRITE;
/*!40000 ALTER TABLE `am_access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_admin`
--

DROP TABLE IF EXISTS `am_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL,
  `name_f` varchar(64) NOT NULL,
  `name_l` varchar(64) NOT NULL,
  `pass` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(32) DEFAULT NULL,
  `last_session` varchar(32) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `super_user` smallint(6) NOT NULL DEFAULT '0',
  `perms` text,
  `prefs` blob,
  `reseller_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_admin`
--

LOCK TABLES `am_admin` WRITE;
/*!40000 ALTER TABLE `am_admin` DISABLE KEYS */;
INSERT INTO `am_admin` VALUES (1,'admin','','','$P$F62m9jBnmJ/9TrphnvGyrcJAsCGOeY/',NULL,NULL,NULL,'admin@localhost',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `am_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_admin_log`
--

DROP TABLE IF EXISTS `am_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_admin_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `dattm` datetime DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `tablename` varchar(32) NOT NULL,
  `record_id` varchar(32) DEFAULT NULL,
  `message` text,
  `admin_login` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `al` (`tablename`,`record_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_admin_log`
--

LOCK TABLES `am_admin_log` WRITE;
/*!40000 ALTER TABLE `am_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff3_banner`
--

DROP TABLE IF EXISTS `am_aff3_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff3_banner` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_link_id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` char(1) NOT NULL,
  PRIMARY KEY (`banner_id`),
  UNIQUE KEY `banner_type` (`banner_link_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff3_banner`
--

LOCK TABLES `am_aff3_banner` WRITE;
/*!40000 ALTER TABLE `am_aff3_banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff3_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_banner`
--

DROP TABLE IF EXISTS `am_aff_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_banner` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `desc` text,
  `html` text,
  `upload_id` int(11) DEFAULT NULL,
  `upload_big_id` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `mime` varchar(64) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `is_disabled` smallint(6) DEFAULT NULL,
  `user_group_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_banner`
--

LOCK TABLES `am_aff_banner` WRITE;
/*!40000 ALTER TABLE `am_aff_banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_click`
--

DROP TABLE IF EXISTS `am_aff_click`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_click` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `aff_id` int(11) DEFAULT NULL,
  `time` datetime NOT NULL,
  `banner_id` int(11) DEFAULT NULL,
  `remote_addr` varchar(15) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `aff_id` (`aff_id`,`time`,`remote_addr`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_click`
--

LOCK TABLES `am_aff_click` WRITE;
/*!40000 ALTER TABLE `am_aff_click` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff_click` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_commission`
--

DROP TABLE IF EXISTS `am_aff_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_commission` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `aff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `record_type` enum('commission','void') NOT NULL DEFAULT 'commission',
  `invoice_id` int(11) NOT NULL,
  `invoice_item_id` int(11) NOT NULL,
  `invoice_payment_id` int(11) DEFAULT NULL,
  `receipt_id` char(32) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `is_first` int(11) NOT NULL,
  `payout_detail_id` int(11) DEFAULT NULL,
  `tier` smallint(6) DEFAULT '0',
  PRIMARY KEY (`commission_id`),
  UNIQUE KEY `payment` (`invoice_id`,`invoice_payment_id`,`invoice_item_id`,`product_id`,`record_type`,`tier`),
  KEY `aff_id` (`aff_id`,`date`),
  KEY `ac` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_commission`
--

LOCK TABLES `am_aff_commission` WRITE;
/*!40000 ALTER TABLE `am_aff_commission` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_commission_rule`
--

DROP TABLE IF EXISTS `am_aff_commission_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_commission_rule` (
  `rule_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text,
  `sort_order` int(11) DEFAULT '0',
  `type` enum('custom','multi','global','global-2','global-1') DEFAULT NULL,
  `tier` smallint(6) DEFAULT '0',
  `conditions` text,
  `free_signup_c` decimal(12,2) DEFAULT NULL,
  `free_signup_t` varchar(16) DEFAULT NULL,
  `first_payment_c` decimal(12,2) DEFAULT NULL,
  `first_payment_t` varchar(16) DEFAULT NULL,
  `recurring_c` decimal(12,2) DEFAULT NULL,
  `recurring_t` varchar(16) DEFAULT NULL,
  `multi` decimal(12,2) DEFAULT NULL,
  `is_disabled` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rule_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_commission_rule`
--

LOCK TABLES `am_aff_commission_rule` WRITE;
/*!40000 ALTER TABLE `am_aff_commission_rule` DISABLE KEYS */;
INSERT INTO `am_aff_commission_rule` VALUES (1,'Default Commission',1000,'global',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(2,'2-Tier Affiliates Commission',20000,'global',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `am_aff_commission_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_lead`
--

DROP TABLE IF EXISTS `am_aff_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_lead` (
  `lead_id` int(11) NOT NULL AUTO_INCREMENT,
  `aff_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `banner_id` int(11) DEFAULT NULL,
  `remote_addr` varchar(15) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `first_visited` datetime DEFAULT NULL,
  PRIMARY KEY (`lead_id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_lead`
--

LOCK TABLES `am_aff_lead` WRITE;
/*!40000 ALTER TABLE `am_aff_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_payout`
--

DROP TABLE IF EXISTS `am_aff_payout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_payout` (
  `payout_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `thresehold_date` date NOT NULL,
  `total` decimal(12,2) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`payout_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_payout`
--

LOCK TABLES `am_aff_payout` WRITE;
/*!40000 ALTER TABLE `am_aff_payout` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff_payout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_aff_payout_detail`
--

DROP TABLE IF EXISTS `am_aff_payout_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_aff_payout_detail` (
  `payout_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `aff_id` int(11) NOT NULL,
  `payout_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `is_paid` tinyint(4) NOT NULL DEFAULT '0',
  `receipt_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`payout_detail_id`),
  UNIQUE KEY `payout_id` (`payout_id`,`aff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_aff_payout_detail`
--

LOCK TABLES `am_aff_payout_detail` WRITE;
/*!40000 ALTER TABLE `am_aff_payout_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_aff_payout_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_api_key`
--

DROP TABLE IF EXISTS `am_api_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_api_key` (
  `key_id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `is_disabled` tinyint(4) NOT NULL DEFAULT '0',
  `perms` text,
  PRIMARY KEY (`key_id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_api_key`
--

LOCK TABLES `am_api_key` WRITE;
/*!40000 ALTER TABLE `am_api_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_api_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_ban`
--

DROP TABLE IF EXISTS `am_ban`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_ban` (
  `ban_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL,
  `value` varchar(255) NOT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ban_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_ban`
--

LOCK TABLES `am_ban` WRITE;
/*!40000 ALTER TABLE `am_ban` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_ban` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_billing_plan`
--

DROP TABLE IF EXISTS `am_billing_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_billing_plan` (
  `plan_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `terms` varchar(255) NOT NULL,
  `first_price` decimal(12,2) NOT NULL,
  `first_period` varchar(32) NOT NULL,
  `rebill_times` int(11) NOT NULL DEFAULT '0',
  `second_price` decimal(12,2) DEFAULT NULL,
  `second_period` varchar(32) DEFAULT NULL,
  `disabled` tinyint(4) NOT NULL DEFAULT '0',
  `qty` int(11) NOT NULL DEFAULT '1',
  `variable_qty` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`plan_id`),
  KEY `product` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_billing_plan`
--

LOCK TABLES `am_billing_plan` WRITE;
/*!40000 ALTER TABLE `am_billing_plan` DISABLE KEYS */;
INSERT INTO `am_billing_plan` VALUES (1,1,'Default Billing Plan','','1.11','1d',99999,'2.22','2d',0,1,0);
/*!40000 ALTER TABLE `am_billing_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_cc`
--

DROP TABLE IF EXISTS `am_cc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_cc` (
  `cc_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `cc` varchar(25) DEFAULT NULL,
  `cc_number` varchar(255) DEFAULT NULL,
  `cc_expire` char(4) DEFAULT NULL,
  `cc_name_f` varchar(64) DEFAULT NULL,
  `cc_name_l` varchar(64) DEFAULT NULL,
  `cc_country` varchar(255) DEFAULT NULL,
  `cc_street` varchar(255) DEFAULT NULL,
  `cc_street2` varchar(255) DEFAULT NULL,
  `cc_city` varchar(255) DEFAULT NULL,
  `cc_state` varchar(255) DEFAULT NULL,
  `cc_zip` varchar(255) DEFAULT NULL,
  `cc_company` varchar(255) DEFAULT NULL,
  `cc_phone` varchar(255) DEFAULT NULL,
  `cc_housenumber` varchar(255) DEFAULT NULL,
  `cc_province` varchar(50) DEFAULT NULL,
  `cc_issuenum` varchar(25) DEFAULT NULL,
  `cc_startdate` varchar(12) DEFAULT NULL,
  `cc_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cc_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_cc`
--

LOCK TABLES `am_cc` WRITE;
/*!40000 ALTER TABLE `am_cc` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_cc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_cc_rebill`
--

DROP TABLE IF EXISTS `am_cc_rebill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_cc_rebill` (
  `cc_rebill_id` int(11) NOT NULL AUTO_INCREMENT,
  `tm_added` datetime NOT NULL,
  `paysys_id` varchar(64) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rebill_date` date DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `status_tm` datetime DEFAULT NULL,
  `status_msg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cc_rebill_id`),
  UNIQUE KEY `invoice_date` (`invoice_id`,`rebill_date`),
  KEY `by_date` (`rebill_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_cc_rebill`
--

LOCK TABLES `am_cc_rebill` WRITE;
/*!40000 ALTER TABLE `am_cc_rebill` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_cc_rebill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_config`
--

DROP TABLE IF EXISTS `am_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(64) NOT NULL,
  `config` mediumblob,
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_config`
--

LOCK TABLES `am_config` WRITE;
/*!40000 ALTER TABLE `am_config` DISABLE KEYS */;
INSERT INTO `am_config` VALUES (2,'default','a:26:{s:8:\"root_url\";s:24:\"http://localhost/amember\";s:9:\"root_surl\";s:24:\"http://localhost/amember\";s:11:\"admin_email\";s:15:\"admin@localhost\";s:16:\"login_min_length\";s:1:\"6\";s:16:\"login_max_length\";s:2:\"32\";s:15:\"pass_min_length\";s:1:\"6\";s:15:\"pass_max_length\";s:2:\"32\";s:16:\"clear_access_log\";s:1:\"1\";s:21:\"clear_access_log_days\";s:1:\"7\";s:12:\"max_ip_count\";s:1:\"5\";s:13:\"max_ip_period\";s:4:\"1440\";s:11:\"multi_title\";s:10:\"Membership\";s:16:\"send_signup_mail\";s:1:\"1\";s:7:\"license\";s:59:\"Ly8lPTszJyC8usUrMTUnNzddLzs8FMlNzk1KLwGwTcxMLQ6uAIH8rU0sA0X\";s:15:\"plugins.protect\";a:1:{i:0;s:11:\"new-rewrite\";}s:10:\"site_title\";s:11:\"aMember Pro\";s:15:\"skip_index_page\";s:1:\"1\";s:23:\"auto_login_after_signup\";s:1:\"1\";s:5:\"admin\";a:1:{s:15:\"records-on-page\";s:2:\"25\";}s:7:\"modules\";a:3:{i:0;s:3:\"aff\";i:1;s:8:\"helpdesk\";i:2;s:10:\"newsletter\";}s:22:\"login_session_lifetime\";N;s:4:\"lang\";N;s:8:\"am3_urls\";N;s:7:\"plugins\";a:2:{s:7:\"payment\";a:1:{i:0;s:7:\"offline\";}s:7:\"protect\";a:1:{i:0;s:9:\"wordpress\";}}s:8:\"use_cron\";N;s:25:\"disable_unsubscribe_block\";N;}');
/*!40000 ALTER TABLE `am_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_country`
--

DROP TABLE IF EXISTS `am_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country` char(2) NOT NULL,
  `alpha2` char(2) NOT NULL,
  `alpha3` char(3) NOT NULL,
  `numeric` smallint(6) NOT NULL,
  `title` varchar(64) DEFAULT NULL,
  `tag` int(11) DEFAULT NULL,
  `status` enum('added','changed') DEFAULT NULL,
  PRIMARY KEY (`country_id`),
  UNIQUE KEY `country` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_country`
--

LOCK TABLES `am_country` WRITE;
/*!40000 ALTER TABLE `am_country` DISABLE KEYS */;
INSERT INTO `am_country` VALUES (1,'US','US','USA',840,'United States',10,NULL),(2,'CA','CA','CAN',124,'Canada',5,NULL),(3,'AF','AF','AFG',4,'Afghanistan',0,NULL),(4,'AL','AL','ALB',8,'Albania',0,NULL),(5,'DZ','DZ','DZA',12,'Algeria',0,NULL),(6,'AS','AS','ASM',16,'American Samoa',0,NULL),(7,'AD','AD','AND',20,'Andorra',0,NULL),(8,'AO','AO','AGO',24,'Angola',0,NULL),(9,'AI','AI','AIA',660,'Anguilla',0,NULL),(10,'AQ','AQ','ATA',10,'Antarctica',0,NULL),(11,'AG','AG','ATG',28,'Antigua and Barbuda',0,NULL),(12,'AR','AR','ARG',32,'Argentina',0,NULL),(13,'AM','AM','ARM',51,'Armenia',0,NULL),(14,'AW','AW','ABW',533,'Aruba',0,NULL),(15,'AU','AU','AUS',36,'Australia',0,NULL),(16,'AT','AT','AUT',40,'Austria',0,NULL),(17,'AZ','AZ','AZE',31,'Azerbaijan',0,NULL),(18,'BS','BS','BHS',44,'Bahamas',0,NULL),(19,'BH','BH','BHR',48,'Bahrain',0,NULL),(20,'BD','BD','BGD',50,'Bangladesh',0,NULL),(21,'BB','BB','BRB',52,'Barbados',0,NULL),(22,'BY','BY','BLR',112,'Belarus',0,NULL),(23,'BE','BE','BEL',56,'Belgium',0,NULL),(24,'BZ','BZ','BLZ',84,'Belize',0,NULL),(25,'BJ','BJ','BEN',204,'Benin',0,NULL),(26,'BM','BM','BMU',60,'Bermuda',0,NULL),(27,'BT','BT','BTN',64,'Bhutan',0,NULL),(28,'BO','BO','BOL',68,'Bolivia',0,NULL),(29,'BA','BA','BIH',70,'Bosnia and Herzegovina',0,NULL),(30,'BW','BW','BWA',72,'Botswana',0,NULL),(31,'BV','BV','BVT',74,'Bouvet Island',0,NULL),(32,'BR','BR','BRA',76,'Brazil',0,NULL),(33,'IO','IO','IOT',86,'British Indian Ocean Territory',0,NULL),(34,'BN','BN','BRN',96,'Brunei',0,NULL),(35,'BG','BG','BGR',100,'Bulgaria',0,NULL),(36,'BF','BF','BFA',854,'Burkina Faso',0,NULL),(37,'BI','BI','BDI',108,'Burundi',0,NULL),(38,'KH','KH','KHM',116,'Cambodia',0,NULL),(39,'CM','CM','CMR',120,'Cameroon',0,NULL),(40,'CV','CV','CPV',132,'Cape Verde',0,NULL),(41,'KY','KY','CYM',136,'Cayman Islands',0,NULL),(42,'CF','CF','CAF',140,'Central African Republic',0,NULL),(43,'TD','TD','TCD',148,'Chad',0,NULL),(44,'CL','CL','CHL',152,'Chile',0,NULL),(45,'CN','CN','CHN',156,'China',0,NULL),(46,'CX','CX','CXR',162,'Christmas Island',0,NULL),(47,'CC','CC','CCK',166,'Cocos (Keeling) Islands',0,NULL),(48,'CO','CO','COL',170,'Colombia',0,NULL),(49,'KM','KM','COM',174,'Comoros',0,NULL),(50,'CG','CG','COG',178,'Congo',0,NULL),(51,'CK','CK','COK',184,'Cook Islands',0,NULL),(52,'CR','CR','CRI',188,'Costa Rica',0,NULL),(53,'CI','CI','CIV',384,'Cote d\'Ivoire',0,NULL),(54,'HR','HR','HRV',191,'Croatia (Hrvatska)',0,NULL),(55,'CU','CU','CUB',192,'Cuba',0,NULL),(56,'CY','CY','CYP',196,'Cyprus',0,NULL),(57,'CZ','CZ','CZE',203,'Czech Republic',0,NULL),(58,'CD','CD','COD',180,'Congo (DRC)',0,NULL),(59,'DK','DK','DNK',208,'Denmark',0,NULL),(60,'DJ','DJ','DJI',262,'Djibouti',0,NULL),(61,'DM','DM','DMA',212,'Dominica',0,NULL),(62,'DO','DO','DOM',214,'Dominican Republic',0,NULL),(63,'TL','TL','TLS',626,'East Timor',0,NULL),(64,'EC','EC','ECU',218,'Ecuador',0,NULL),(65,'EG','EG','EGY',818,'Egypt',0,NULL),(66,'SV','SV','SLV',222,'El Salvador',0,NULL),(67,'GQ','GQ','GNQ',226,'Equatorial Guinea',0,NULL),(68,'ER','ER','ERI',232,'Eritrea',0,NULL),(69,'EE','EE','EST',233,'Estonia',0,NULL),(70,'ET','ET','ETH',231,'Ethiopia',0,NULL),(71,'FK','FK','FLK',238,'Falkland Islands (Islas Malvinas)',0,NULL),(72,'FO','FO','FRO',234,'Faroe Islands',0,NULL),(73,'FJ','FJ','FJI',242,'Fiji Islands',0,NULL),(74,'FI','FI','FIN',246,'Finland',0,NULL),(75,'FR','FR','FRA',250,'France',0,NULL),(76,'GF','GF','GUF',254,'French Guiana',0,NULL),(77,'PF','PF','PYF',258,'French Polynesia',0,NULL),(78,'TF','TF','ATF',260,'French Southern and Antarctic Lands',0,NULL),(79,'GA','GA','GAB',266,'Gabon',0,NULL),(80,'GM','GM','GMB',270,'Gambia',0,NULL),(81,'GE','GE','GEO',268,'Georgia',0,NULL),(82,'DE','DE','DEU',276,'Germany',0,NULL),(83,'GH','GH','GHA',288,'Ghana',0,NULL),(84,'GI','GI','GIB',292,'Gibraltar',0,NULL),(85,'GR','GR','GRC',300,'Greece',0,NULL),(86,'GL','GL','GRL',304,'Greenland',0,NULL),(87,'GD','GD','GRD',308,'Grenada',0,NULL),(88,'GP','GP','GLP',312,'Guadeloupe',0,NULL),(89,'GU','GU','GUM',316,'Guam',0,NULL),(90,'GT','GT','GTM',320,'Guatemala',0,NULL),(91,'GN','GN','GIN',324,'Guinea',0,NULL),(92,'GW','GW','GNB',624,'Guinea-Bissau',0,NULL),(93,'GY','GY','GUY',328,'Guyana',0,NULL),(94,'HT','HT','HTI',332,'Haiti',0,NULL),(95,'HM','HM','HMD',334,'Heard Island and McDonald Islands',0,NULL),(96,'HN','HN','HND',340,'Honduras',0,NULL),(97,'HK','HK','HKG',344,'Hong Kong SAR',0,NULL),(98,'HU','HU','HUN',348,'Hungary',0,NULL),(99,'IS','IS','ISL',352,'Iceland',0,NULL),(100,'IN','IN','IND',356,'India',0,NULL),(101,'ID','ID','IDN',360,'Indonesia',0,NULL),(102,'IR','IR','IRN',364,'Iran',0,NULL),(103,'IQ','IQ','IRQ',368,'Iraq',0,NULL),(104,'IE','IE','IRL',372,'Ireland',0,NULL),(105,'IL','IL','ISR',376,'Israel',0,NULL),(106,'IT','IT','ITA',380,'Italy',0,NULL),(107,'JM','JM','JAM',388,'Jamaica',0,NULL),(108,'JP','JP','JPN',392,'Japan',0,NULL),(109,'JO','JO','JOR',400,'Jordan',0,NULL),(110,'KZ','KZ','KAZ',398,'Kazakhstan',0,NULL),(111,'KE','KE','KEN',404,'Kenya',0,NULL),(112,'KI','KI','KIR',296,'Kiribati',0,NULL),(113,'KR','KR','KOR',410,'Korea',0,NULL),(114,'KW','KW','KWT',414,'Kuwait',0,NULL),(115,'KG','KG','KGZ',417,'Kyrgyzstan',0,NULL),(116,'LA','LA','LAO',418,'Laos',0,NULL),(117,'LV','LV','LVA',428,'Latvia',0,NULL),(118,'LB','LB','LBN',422,'Lebanon',0,NULL),(119,'LS','LS','LSO',426,'Lesotho',0,NULL),(120,'LR','LR','LBR',430,'Liberia',0,NULL),(121,'LY','LY','LBY',434,'Libya',0,NULL),(122,'LI','LI','LIE',438,'Liechtenstein',0,NULL),(123,'LT','LT','LTU',440,'Lithuania',0,NULL),(124,'LU','LU','LUX',442,'Luxembourg',0,NULL),(125,'MO','MO','MAC',446,'Macao SAR',0,NULL),(126,'MK','MK','MKD',807,'Macedonia',0,NULL),(127,'MG','MG','MDG',450,'Madagascar',0,NULL),(128,'MW','MW','MWI',454,'Malawi',0,NULL),(129,'MY','MY','MYS',458,'Malaysia',0,NULL),(130,'MV','MV','MDV',462,'Maldives',0,NULL),(131,'ML','ML','MLI',466,'Mali',0,NULL),(132,'MT','MT','MLT',470,'Malta',0,NULL),(133,'MH','MH','MHL',584,'Marshall Islands',0,NULL),(134,'MQ','MQ','MTQ',474,'Martinique',0,NULL),(135,'MR','MR','MRT',478,'Mauritania',0,NULL),(136,'MU','MU','MUS',480,'Mauritius',0,NULL),(137,'YT','YT','MYT',175,'Mayotte',0,NULL),(138,'MX','MX','MEX',484,'Mexico',0,NULL),(139,'FM','FM','FSM',583,'Micronesia',0,NULL),(140,'MD','MD','MDA',498,'Moldova',0,NULL),(141,'MC','MC','MCO',492,'Monaco',0,NULL),(142,'MN','MN','MNG',496,'Mongolia',0,NULL),(143,'MS','MS','MSR',500,'Montserrat',0,NULL),(144,'MA','MA','MAR',504,'Morocco',0,NULL),(145,'MZ','MZ','MOZ',508,'Mozambique',0,NULL),(146,'MM','MM','MMR',104,'Myanmar',0,NULL),(147,'NA','NA','NAM',516,'Namibia',0,NULL),(148,'NR','NR','NRU',520,'Nauru',0,NULL),(149,'NP','NP','NPL',524,'Nepal',0,NULL),(150,'NL','NL','NLD',528,'Netherlands',0,NULL),(151,'AN','AN','ANT',127,'Netherlands Antilles',0,NULL),(152,'NC','NC','NCL',540,'New Caledonia',0,NULL),(153,'NZ','NZ','NZL',554,'New Zealand',0,NULL),(154,'NI','NI','NIC',558,'Nicaragua',0,NULL),(155,'NE','NE','NER',562,'Niger',0,NULL),(156,'NG','NG','NGA',566,'Nigeria',0,NULL),(157,'NU','NU','NIU',570,'Niue',0,NULL),(158,'NF','NF','NFK',574,'Norfolk Island',0,NULL),(159,'KP','KP','PRK',408,'North Korea',0,NULL),(160,'MP','MP','MNP',580,'Northern Mariana Islands',0,NULL),(161,'NO','NO','NOR',578,'Norway',0,NULL),(162,'OM','OM','OMN',512,'Oman',0,NULL),(163,'PK','PK','PAK',586,'Pakistan',0,NULL),(164,'PW','PW','PLW',585,'Palau',0,NULL),(165,'PA','PA','PAN',591,'Panama',0,NULL),(166,'PG','PG','PNG',598,'Papua New Guinea',0,NULL),(167,'PY','PY','PRY',600,'Paraguay',0,NULL),(168,'PE','PE','PER',604,'Peru',0,NULL),(169,'PH','PH','PHL',608,'Philippines',0,NULL),(170,'PN','PN','PCN',612,'Pitcairn Islands',0,NULL),(171,'PL','PL','POL',616,'Poland',0,NULL),(172,'PT','PT','PRT',620,'Portugal',0,NULL),(173,'PR','PR','PRI',630,'Puerto Rico',0,NULL),(174,'QA','QA','QAT',634,'Qatar',0,NULL),(175,'RE','RE','REU',638,'Reunion',0,NULL),(176,'RO','RO','ROU',642,'Romania',0,NULL),(177,'RU','RU','RUS',643,'Russia',0,NULL),(178,'RW','RW','RWA',646,'Rwanda',0,NULL),(179,'WS','WS','WSM',882,'Samoa',0,NULL),(180,'SM','SM','SMR',674,'San Marino',0,NULL),(181,'ST','ST','STP',678,'Sao Tome and Principe',0,NULL),(182,'SA','SA','SAU',682,'Saudi Arabia',0,NULL),(183,'SN','SN','SEN',686,'Senegal',0,NULL),(184,'ME','ME','MNE',499,'Montenegro',0,NULL),(185,'SC','SC','SYC',690,'Seychelles',0,NULL),(186,'SL','SL','SLE',694,'Sierra Leone',0,NULL),(187,'SG','SG','SGP',702,'Singapore',0,NULL),(188,'SK','SK','SVK',703,'Slovakia',0,NULL),(189,'SI','SI','SVN',705,'Slovenia',0,NULL),(190,'SB','SB','SLB',90,'Solomon Islands',0,NULL),(191,'SO','SO','SOM',706,'Somalia',0,NULL),(192,'ZA','ZA','ZAF',710,'South Africa',0,NULL),(193,'GS','GS','SGS',239,'South Georgia and the South Sandwich Islands',0,NULL),(194,'ES','ES','ESP',724,'Spain',0,NULL),(195,'LK','LK','LKA',144,'Sri Lanka',0,NULL),(196,'SH','SH','SHN',654,'St. Helena',0,NULL),(197,'KN','KN','KNA',659,'St. Kitts and Nevis',0,NULL),(198,'LC','LC','LCA',662,'St. Lucia',0,NULL),(199,'PM','PM','SPM',666,'St. Pierre and Miquelon',0,NULL),(200,'VC','VC','VCT',670,'St. Vincent and the Grenadines',0,NULL),(201,'SD','SD','SDN',729,'Sudan',0,NULL),(202,'SR','SR','SUR',740,'Suriname',0,NULL),(203,'SJ','SJ','SJM',744,'Svalbard and Jan Mayen',0,NULL),(204,'SZ','SZ','SWZ',748,'Swaziland',0,NULL),(205,'SE','SE','SWE',752,'Sweden',0,NULL),(206,'CH','CH','CHE',756,'Switzerland',0,NULL),(207,'SY','SY','SYR',760,'Syria',0,NULL),(208,'TW','TW','TWN',158,'Taiwan',0,NULL),(209,'TJ','TJ','TJK',762,'Tajikistan',0,NULL),(210,'TZ','TZ','TZA',834,'Tanzania',0,NULL),(211,'TH','TH','THA',764,'Thailand',0,NULL),(212,'TG','TG','TGO',768,'Togo',0,NULL),(213,'TK','TK','TKL',772,'Tokelau',0,NULL),(214,'TO','TO','TON',776,'Tonga',0,NULL),(215,'TT','TT','TTO',780,'Trinidad and Tobago',0,NULL),(216,'TN','TN','TUN',788,'Tunisia',0,NULL),(217,'TR','TR','TUR',792,'Turkey',0,NULL),(218,'TM','TM','TKM',795,'Turkmenistan',0,NULL),(219,'TC','TC','TCA',796,'Turks and Caicos Islands',0,NULL),(220,'TV','TV','TUV',798,'Tuvalu',0,NULL),(221,'UG','UG','UGA',800,'Uganda',0,NULL),(222,'UA','UA','UKR',804,'Ukraine',0,NULL),(223,'AE','AE','ARE',784,'United Arab Emirates',0,NULL),(224,'GB','GB','GBR',826,'United Kingdom',0,NULL),(225,'UM','UM','UMI',581,'United States Minor Outlying Islands',0,NULL),(226,'UY','UY','URY',858,'Uruguay',0,NULL),(227,'UZ','UZ','UZB',860,'Uzbekistan',0,NULL),(228,'VU','VU','VUT',548,'Vanuatu',0,NULL),(229,'VA','VA','VAT',336,'Vatican City',0,NULL),(230,'VE','VE','VEN',862,'Venezuela',0,NULL),(231,'VN','VN','VNM',704,'Viet Nam',0,NULL),(232,'VG','VG','VGB',92,'Virgin Islands (British)',0,NULL),(233,'VI','VI','VIR',850,'Virgin Islands',0,NULL),(234,'WF','WF','WLF',876,'Wallis and Futuna',0,NULL),(235,'YE','YE','YEM',887,'Yemen',0,NULL),(236,'ZM','ZM','ZMB',894,'Zambia',0,NULL),(237,'ZW','ZW','ZWE',716,'Zimbabwe',0,NULL),(238,'AX','AX','ALA',248,'Åland Islands',0,NULL),(239,'BQ','BQ','BES',535,'Bonaire, Sint Eustatius and Saba',0,NULL),(240,'CW','CW','CUW',531,'Curaçao',0,NULL),(241,'GG','GG','GGY',831,'Guernsey',0,NULL),(242,'IM','IM','IMN',833,'Isle of Man',0,NULL),(243,'JE','JE','JEY',832,'Jersey',0,NULL),(245,'PS','PS','PSE',275,'Palestinian Territory, Occupied',0,NULL),(246,'BL','BL','BLM',652,'Saint Barthélemy',0,NULL),(247,'MF','MF','MAF',663,'Saint Martin (French part)',0,NULL),(248,'RS','RS','SRB',688,'Serbia',0,NULL),(249,'SX','SX','SXM',534,'Sint Maarten (Dutch part)',0,NULL),(250,'SS','SS','SSD',728,'South Sudan',0,NULL),(251,'EH','EH','ESH',732,'Western Sahara',0,NULL);
/*!40000 ALTER TABLE `am_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_coupon`
--

DROP TABLE IF EXISTS `am_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_coupon` (
  `coupon_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_id` int(10) unsigned NOT NULL,
  `code` varchar(32) NOT NULL,
  `used_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`coupon_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_coupon`
--

LOCK TABLES `am_coupon` WRITE;
/*!40000 ALTER TABLE `am_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_coupon_batch`
--

DROP TABLE IF EXISTS `am_coupon_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_coupon_batch` (
  `batch_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(128) DEFAULT NULL,
  `discount_type` enum('percent','number') DEFAULT 'number',
  `discount` decimal(12,2) DEFAULT NULL,
  `begin_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `is_disabled` tinyint(4) DEFAULT NULL,
  `is_recurring` tinyint(4) NOT NULL DEFAULT '0',
  `product_ids` varchar(255) DEFAULT NULL,
  `use_count` int(11) DEFAULT NULL,
  `user_use_count` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_coupon_batch`
--

LOCK TABLES `am_coupon_batch` WRITE;
/*!40000 ALTER TABLE `am_coupon_batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_coupon_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_currency_exchange`
--

DROP TABLE IF EXISTS `am_currency_exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_currency_exchange` (
  `rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `currency` char(3) NOT NULL,
  `date` date NOT NULL,
  `rate` decimal(12,6) NOT NULL,
  PRIMARY KEY (`rate_id`),
  UNIQUE KEY `currency_rate` (`currency`,`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_currency_exchange`
--

LOCK TABLES `am_currency_exchange` WRITE;
/*!40000 ALTER TABLE `am_currency_exchange` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_currency_exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_data`
--

DROP TABLE IF EXISTS `am_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_data` (
  `table` varchar(64) NOT NULL,
  `id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '0',
  `value` varchar(255) DEFAULT NULL,
  `blob` mediumblob,
  UNIQUE KEY `table` (`table`,`id`,`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_data`
--

LOCK TABLES `am_data` WRITE;
/*!40000 ALTER TABLE `am_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_directory`
--

DROP TABLE IF EXISTS `am_directory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_directory` (
  `directory_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `comment` text,
  `index_fields` text,
  `detail_fields` text,
  `add_query_conditions` text,
  PRIMARY KEY (`directory_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_directory`
--

LOCK TABLES `am_directory` WRITE;
/*!40000 ALTER TABLE `am_directory` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_directory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_email_sent`
--

DROP TABLE IF EXISTS `am_email_sent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_email_sent` (
  `email_sent_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) DEFAULT NULL,
  `format` varchar(16) DEFAULT NULL,
  `body` text,
  `files` varchar(255) DEFAULT NULL,
  `newsletter_ids` varchar(255) DEFAULT NULL,
  `count_users` int(11) DEFAULT NULL,
  `sent_users` int(11) DEFAULT NULL,
  `last_email` varchar(255) DEFAULT NULL,
  `desc_users` varchar(255) DEFAULT NULL,
  `is_cancelled` varchar(255) DEFAULT NULL,
  `serialized_vars` text,
  `tm_added` datetime NOT NULL,
  `tm_finished` datetime DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`email_sent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_email_sent`
--

LOCK TABLES `am_email_sent` WRITE;
/*!40000 ALTER TABLE `am_email_sent` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_email_sent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_email_template`
--

DROP TABLE IF EXISTS `am_email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_email_template` (
  `email_template_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `lang` varchar(16) NOT NULL,
  `format` enum('text','html','multipart') NOT NULL DEFAULT 'text',
  `subject` varchar(255) NOT NULL,
  `txt` mediumtext NOT NULL,
  `plain_txt` mediumtext,
  `attachments` mediumtext,
  `day` int(11) DEFAULT NULL,
  `days` varchar(255) DEFAULT NULL,
  `conditions` text,
  `not_conditions` varchar(255) DEFAULT NULL,
  `not_conditions_expired` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`email_template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_email_template`
--

LOCK TABLES `am_email_template` WRITE;
/*!40000 ALTER TABLE `am_email_template` DISABLE KEYS */;
INSERT INTO `am_email_template` VALUES (1,'aff.registration_mail','en','text','%site_title% Affiliate Program Registration','Dear %user.name_f% %user.name_l%,\n\nThank you for registration on %site_title% affiliate program!\n\n   Your User ID: %user.login% \n   Your Password: %password%\n\nLog-on to your affiliate pages at:\n%root_url%/member/aff\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'aff.mail_sale_admin','en','text','** Affiliate Commission','Dear admin,\n\nNew sale has been made with using of affiliate link.\nYou may find sale details below:\n\n----\nAffilate: %affiliate.user_id% / %affiliate.login% / %affiliate.email% \n          %affiliate.name_f% %affiliate.name_l% / %affiliate.remote_addr%\nNew Member: %user.user_id% / %user.login% / %user.email% \n          %user.name_f% %user.name_l% / %user.remote_addr%\nPayment REF: %payment.payment_id%\nTotal:       %payment.amount%\nProduct ordered: %product.title%\nCommission paid: %commission%\n----\n\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'aff.mail_sale_user','en','text','** Affiliate Sale','Dear %affiliate.name_f% %affiliate.name_l%,\n\nNew sale has been made by your affiliate link and \ncommission credited to your balance. You may find \nsale details below:\n\n----\nPayment REF: %payment.invoice_payment_id%\nTotal:       %payment.amount%\nProduct ordered: %product.title%\nYour commission: %commission%\n----\n\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'aff.new_payouts','en','text','** Affiliate Payout ToDo','Dear Admin,\n\nNew payouts were generated for you affiliates. Please visit\n%url%\nto pay earnings.\n----\nYour aMember Pro installation\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'cc.admin_rebill_stats','en','text','%site_title% - %plugin% Rebill Statistics (%short_stats%)','Hello,\n\nOutlined below are the results of latest rebilling attempt on  %site_title% \n\nHere you can find statistics about SUCCESS rebills \n===\n%rebills_success%\n\n\nHere you can find statistics about FAILED rebills \n=== \n%rebills_failed%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'cc.rebill_failed','en','text','%site_title% Subscription Renewal Failed','Hello %user.name_f% %user.name_l%,\n\nYour subscription was not renewed automatically by membership system\ndue to payment failure: %error%\n\n%prorate%\n\nYou may update your credit card info here:.\n%root_url%/member\n\nThank you for attention!\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'cc.rebill_success','en','text','%site_title% Subscription Renewed','Hello %user.name_f% %user.name_l%,\n        \nYour subscription has been renewed automatically by our membership system.\nYour credit card was charged %amount%\n        \nNext renewal date: %rebill_date%\n        \nYou may login to membership info page at :\n%root_url%/member\n\nThank you!\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'cc.card_expire','en','text','Credit Card Expiration','Hello %user.name_f% %user.name_l%,\n    \nYour credit card that we have on file for recurring billing will expire\non %expires%. Next recurring billing for invoice %invoice.public_id%\nis sheduled for %invoice.rebill_date|date%.\n        \nTo avoid any interruption of your subscription, please visit page\n%root_url%/member\nand update your credit card information..\n\nThank you!\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'send_security_code','en','text','Your Lost Password','Dear %user.name_f% %user.name_l%,\n\nYou have requested your log-in information.\n\n     Your User ID:  %user.login%\n\nFollow a link below to change your password:\n  %url%\n    \nThis link will be active %hours% hour(s).\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'send_security_code_admin','en','text','Your Lost Password','Dear %user.name_f% %user.name_l%,\n\nYou have requested your admin log-in information.\n\n     Your User ID:  %user.login%\n\nFollow a link below to change your password:\n  %url%\n    \nThis link will be active %hours% hour(s).\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'send_password_admin','en','text','New Admin Password','Dear Administrator,\n\nYou have requested to reset your access credentials.\n\n     Your User ID:  %user.login%\n     New Password:  %pass%\n\nPlease login to admin control panel at:\n     %root_url%/admin/\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'manually_approve','en','text','%site_title% Your signup is pending','Dear %user.name_f% %user.name_l%,\n\nThank you for subscribing!\n\nWe review all payments manually, so your payment \nstatus is pending. You will receive email when your\naccount will be approved. Thank you for your patience.\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'invoice_approval_wait_user','en','text','%site_title% Your payment is under review','Dear %user.name_f% %user.name_l%,\n\nThank you for subscribing!\n\nWe review all payments manually, so your payment \nstatus is pending. You will receive email when your\npayment will be approved. Thank you for your patience.\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'invoice_approved_user','en','text','%site_title% Your payment was approved!','Dear %user.name_f% %user.name_l%,\n\nThank you for subscribing!\nYour payment was approved by our staff. \n\n   Your User ID: %user.login%  \n\nLog-on to your member pages at:\n%root_url%/member\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'mail_cancel_admin','en','text','%site_title% - User subscription cancelled','User %user.login%, \"%user.name_f% %user.name_l%\" <%user.email%>\nhas cancelled recurring subscription #%invoice.invoice_id% to product\n%product.title%.\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'mail_cancel_member','en','text','%site_title% - Subscription cancelled','Dear %user.name_f% %user.name_l%,\n\nYour subscription to \"%product.title%\" cancelled. Feel free to subscribe \nagain, you can do it here:\n  %root_url%/member\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'send_payment_admin','en','text','%site_title% *** New Payment','\nPayment Amount: %payment.amount% %payment.currency%\nPayment Reference: %payment.receipt_id%            \n\n%invoice_text%\n\nUser details:\n    Username:   %user.login%\n    Email:      %user.email%\n    Name:       %user.name_f% %user.name_l%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'registration_mail','en','text','%site_title% Registration','Dear %user.name_f% %user.name_l%,\n\nThank you for registration on %site_title%!\n\n   Your User ID: %user.login% \n   Your Password: %password%\n\nLog-on to your member pages at:\n%root_url%/member\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'changepass_mail','en','text','%site_title% Password Change','Dear %user.name_f% %user.name_l%,\n\nYou changed password on %site_title%!\n\n   Your User ID: %user.login%\n   Your Password: %password%\n\nLog-on to your member pages at:\n%root_url%/member\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'send_signup_mail','en','text','%site_title% - Membership Information','Dear %user.name_f% %user.name_l%,\n\nThank you for subscribing on %site_title%!\n\n   Your User ID: %user.login%  \n\nLog-on to your member pages at:\n%root_url%/member\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'send_payment_mail','en','text','%site_title% - Payment Receipt','Thank you for your order. You may find order details below:\n\nPayment Amount: %payment.amount% %payment.currency%\nPayment Reference: %payment.receipt_id%            \n                       \n%invoice_text%\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'verify_email_signup','en','text','%site_title% - Account Verification','Hello %user.name_f% %user.name_l%,\n\nYou (or someone else) has just registered an account on %site_title%.\nClicking on the link below will activate the account:\n%url%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'verify_email_profile','en','text','%site_title% - Account Verification','Hello %user.name_f% %user.name_l%,\n\nYou (or someone else) has just changed email address in your account on %site_title%.\nClicking on the link below will approve this change:\n%url%\n\nPlease note that email address will be changed in your profile only if you will click on above link.\nIf you didn\'t request email address change just disregard this message.\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'send_free_payment_admin','en','text','%site_title% *** New Free Signup','\n%invoice_text%\n\nUser details:\n    Username:   %user.login%\n    Email:      %user.email%\n    Name:       %user.name_f% %user.name_l%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'manually_approve_admin','en','text','%site_title% Your approval required','\nNew signup completed and is awaiting your approval.\nPlease log into aMember CP\n        %root_url%/admin/\nand then click the following link:\n        %root_url%/admin-users?_u_a=edit&_u_id=%user.user_id%\n\nUser details:\n    Username:   %user.login%\n    Email:      %user.email%\n    Name:       %user.name_f% %user.name_l%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'invoice_approval_wait_admin','en','text','%site_title% Your approval required','\nNew signup completed and is awaiting your approval.\nPlease log into aMember CP\n        %root_url%/admin/\nand then click the following link:\n        %root_url%/admin-user-payments/index/user_id/%user.user_id%\n\nUser details:\n    Username:   %user.login%\n    Email:      %user.email%\n    Name:       %user.name_f% %user.name_l%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'max_ip_actions_admin','en','text','%site_title% Account Sharing Violation Detected','\nThere is an automated message from aMember Pro script. \nAn account violation has been detected for the following\ncustomer:\nUser details:\n    Username:   %user.login%\n    Email:      %user.email%\n    Name:       %user.name_f% %user.name_l%\n%userlocked%    \nIt has reached configured limit of %maxipcount% IP within\n%maxipperiod% minutes. Please login into aMember CP and review\nhis access log. \n\nIf it looks like a script mistake, you may disable sharing violation checking \nfor this user in the \"User Profile\", or disable it globally at aMember CP -> \nSetup -> LoginPage by setting \"if customer uses more than IP\" to something like \"99999\".\n    \n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'max_ip_actions_user','en','text','%site_title% Account Sharing Violation Detected','\nThere is an automated message from aMember Pro script. \nAn account violation has been detected.\n%userlocked%\n\nIt has reached configured limit of %maxipcount% IP within\n%maxipperiod% minutes.\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,'admin_cancel_upgraded_invoice','en','text','%site_title% Cancel Upgraded Invoice','\nThere is an automated message from aMember Pro script. \n            \nYour customer %user.login% \"%user.name_f% %user.name_l%\" <%user.email%> \nrecently changed his subscription to new payment plan. Unfortunaetly,\nthe payment system does not allow to cancel previous subscription automatically.\nPlease cancel previous user recurring subscription manually:\n   Payment System:         %invoice.paysys_id%\n   aMember Invoice Id:     %invoice.public_id%\n   Subscription Reference: %subscr_id%\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'admin_refund_upgraded_invoice','en','text','%site_title% Refund Upgraded Invoice','\nThere is an automated message from aMember Pro script.\n             \nYour customer %user.login% \"%user.name_f% %user.name_l%\" <%user.email%> \nrecently changed his subscription to new payment plan. aMember has done \ncalculations and it is necessary to refund amount of money to the customer.\n            \nUnfortunaetly, the payment system does not allow to process refunds\nautomatically.\nPlease process refund manually via payment system control panel:\n\n   Payment System:         %invoice.paysys_id%\n   Last Payment Reference: %subscr_id%\n   Amount to refund:       %refund_amount% %invoice.currency%\n   aMember Invoice Id:     %invoice.public_id%\n   \n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,'helpdesk.notify_new_message','en','text','New Message for Your Ticket [#%ticket.ticket_mask%]','Dear %user.name_f% %user.name_l%,\n\nYou have received a new message in helpdesk\nfor your ticket [%ticket.subject%]\n\n     Follow a link below to view this message:\n     %url%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,'helpdesk.notify_new_message_admin','en','text','New Message for Ticket [#%ticket.ticket_mask%]','\n            \nYou have received a new message in helpdesk\nfor ticket [%ticket.subject%]\n\n     Follow a link below to view this message:\n     %url%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,'helpdesk.new_ticket','en','text','New Ticket [#%ticket.ticket_mask%]','Dear %user.name_f% %user.name_l%,\n\nYou created ticket [%ticket.subject%]\nin our helpdesk system.\n\nThank you for your enquiry.\nWe will respond within 24 hours.\n\n    Follow a link below to view your ticket:\n    %url%\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,'subusers.registration_mail','en','text','%site_title% Registration','Dear %user.name_f% %user.name_l%,\n\nAn account has been create for you on %site_title%!\n\n   Your User ID: %user.login% \n   Your Password: %password%\n\nLog-on to use your subscription \n   %root_url%/member\n\n--\nBest Regards,\n%site_title%\n%root_url%\n        ',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `am_email_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_error_log`
--

DROP TABLE IF EXISTS `am_error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_error_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `time` datetime NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `remote_addr` varchar(15) DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  `error` text,
  `trace` text,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_error_log`
--

LOCK TABLES `am_error_log` WRITE;
/*!40000 ALTER TABLE `am_error_log` DISABLE KEYS */;
INSERT INTO `am_error_log` VALUES (1,NULL,'2013-04-29 07:53:29','http://localhost/amember',NULL,'','<b>WARNING:</b> xcache_get(): xcache.var_size is either 0 or too small to enable var data caching\nin line 95 of file /home/alex/amember/library/Zend/Cache/Backend/Xcache.php','xcache_get [ library/Zend/Cache/Backend/Xcache.php : 95 ]\nZend_Cache_Backend_Xcache->load [ library/Zend/Cache/Core.php : 305 ]\nZend_Cache_Core->load [ library/Zend/Cache/Frontend/Function.php : 98 ]\nZend_Cache_Frontend_Function->call [ library/Am/Locale.php : 206 ]\nAm_Locale->getData [ library/Am/Locale.php : 185 ]\nAm_Locale->getDateFormat [ library/Am/Locale.php : 394 ]\nAm_Locale::initLocale [ library/Am/App.php : 1370 ]\nAm_App->bootstrap [ bootstrap.php : 25 ]\nrequire_once [ utils/build/make-install-db.php : 105 ]\n'),(2,NULL,'2013-04-29 07:53:29','http://localhost/amember',NULL,'','<b>WARNING:</b> xcache_set(): xcache.var_size is either 0 or too small to enable var data caching\nin line 134 of file /home/alex/amember/library/Zend/Cache/Backend/Xcache.php','xcache_set [ library/Zend/Cache/Backend/Xcache.php : 134 ]\nZend_Cache_Backend_Xcache->save [ library/Zend/Cache/Core.php : 389 ]\nZend_Cache_Core->save [ library/Zend/Cache/Frontend/Function.php : 109 ]\nZend_Cache_Frontend_Function->call [ library/Am/Locale.php : 206 ]\nAm_Locale->getData [ library/Am/Locale.php : 185 ]\nAm_Locale->getDateFormat [ library/Am/Locale.php : 394 ]\nAm_Locale::initLocale [ library/Am/App.php : 1370 ]\nAm_App->bootstrap [ bootstrap.php : 25 ]\nrequire_once [ utils/build/make-install-db.php : 105 ]\n'),(3,NULL,'2013-04-29 07:53:29','http://localhost/amember',NULL,'','<b>WARNING:</b> xcache_unset(): xcache.var_size is either 0 or too small to enable var data caching\nin line 149 of file /home/alex/amember/library/Zend/Cache/Backend/Xcache.php','xcache_unset [ library/Zend/Cache/Backend/Xcache.php : 149 ]\nZend_Cache_Backend_Xcache->remove [ library/Zend/Cache/Core.php : 398 ]\nZend_Cache_Core->save [ library/Zend/Cache/Frontend/Function.php : 109 ]\nZend_Cache_Frontend_Function->call [ library/Am/Locale.php : 206 ]\nAm_Locale->getData [ library/Am/Locale.php : 185 ]\nAm_Locale->getDateFormat [ library/Am/Locale.php : 394 ]\nAm_Locale::initLocale [ library/Am/App.php : 1370 ]\nAm_App->bootstrap [ bootstrap.php : 25 ]\nrequire_once [ utils/build/make-install-db.php : 105 ]\n');
/*!40000 ALTER TABLE `am_error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_example`
--

DROP TABLE IF EXISTS `am_example`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_example` (
  `example_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `comment` text,
  PRIMARY KEY (`example_id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_example`
--

LOCK TABLES `am_example` WRITE;
/*!40000 ALTER TABLE `am_example` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_example` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_exchange_rate`
--

DROP TABLE IF EXISTS `am_exchange_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_exchange_rate` (
  `rate_id` int(11) NOT NULL AUTO_INCREMENT,
  `from` char(3) NOT NULL,
  `to` char(3) NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`rate_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_exchange_rate`
--

LOCK TABLES `am_exchange_rate` WRITE;
/*!40000 ALTER TABLE `am_exchange_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_exchange_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_failed_login`
--

DROP TABLE IF EXISTS `am_failed_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_failed_login` (
  `failed_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` char(15) NOT NULL,
  `login_type` int(11) NOT NULL,
  `failed_logins` int(11) NOT NULL,
  `last_failed` int(11) NOT NULL,
  PRIMARY KEY (`failed_login_id`),
  UNIQUE KEY `ip` (`ip`,`login_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_failed_login`
--

LOCK TABLES `am_failed_login` WRITE;
/*!40000 ALTER TABLE `am_failed_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_failed_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_file`
--

DROP TABLE IF EXISTS `am_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_file` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text,
  `path` varchar(255) NOT NULL,
  `mime` varchar(64) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `display_type` varchar(255) DEFAULT NULL,
  `dattm` datetime DEFAULT NULL,
  `hide` smallint(6) DEFAULT '0',
  `download_limit` varchar(50) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_file`
--

LOCK TABLES `am_file` WRITE;
/*!40000 ALTER TABLE `am_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_file_download`
--

DROP TABLE IF EXISTS `am_file_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_file_download` (
  `download_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dattm` datetime NOT NULL,
  `remote_addr` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`download_id`),
  KEY `download` (`file_id`,`user_id`,`dattm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_file_download`
--

LOCK TABLES `am_file_download` WRITE;
/*!40000 ALTER TABLE `am_file_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_file_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_folder`
--

DROP TABLE IF EXISTS `am_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_folder` (
  `folder_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text,
  `path` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `method` varchar(64) DEFAULT NULL,
  `dattm` datetime DEFAULT NULL,
  `hide` smallint(6) DEFAULT '0',
  PRIMARY KEY (`folder_id`),
  UNIQUE KEY `path` (`path`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_folder`
--

LOCK TABLES `am_folder` WRITE;
/*!40000 ALTER TABLE `am_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_helpdesk_category`
--

DROP TABLE IF EXISTS `am_helpdesk_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_helpdesk_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `is_disabled` tinyint(4) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_helpdesk_category`
--

LOCK TABLES `am_helpdesk_category` WRITE;
/*!40000 ALTER TABLE `am_helpdesk_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_helpdesk_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_helpdesk_faq`
--

DROP TABLE IF EXISTS `am_helpdesk_faq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_helpdesk_faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_helpdesk_faq`
--

LOCK TABLES `am_helpdesk_faq` WRITE;
/*!40000 ALTER TABLE `am_helpdesk_faq` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_helpdesk_faq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_helpdesk_message`
--

DROP TABLE IF EXISTS `am_helpdesk_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_helpdesk_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `dattm` datetime NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `type` enum('message','comment') NOT NULL,
  `content` text NOT NULL,
  `attachments` varchar(255) NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `ticket_id_type` (`ticket_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_helpdesk_message`
--

LOCK TABLES `am_helpdesk_message` WRITE;
/*!40000 ALTER TABLE `am_helpdesk_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_helpdesk_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_helpdesk_snippet`
--

DROP TABLE IF EXISTS `am_helpdesk_snippet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_helpdesk_snippet` (
  `snippet_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`snippet_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_helpdesk_snippet`
--

LOCK TABLES `am_helpdesk_snippet` WRITE;
/*!40000 ALTER TABLE `am_helpdesk_snippet` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_helpdesk_snippet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_helpdesk_ticket`
--

DROP TABLE IF EXISTS `am_helpdesk_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_helpdesk_ticket` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_mask` varchar(16) NOT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `status` enum('new','awaiting_user_response','awaiting_admin_response','closed') NOT NULL,
  `subject` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `ticket_mask` (`ticket_mask`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_helpdesk_ticket`
--

LOCK TABLES `am_helpdesk_ticket` WRITE;
/*!40000 ALTER TABLE `am_helpdesk_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_helpdesk_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_integration`
--

DROP TABLE IF EXISTS `am_integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_integration` (
  `integration_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(255) NOT NULL,
  `plugin` text,
  `vars` text,
  PRIMARY KEY (`integration_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_integration`
--

LOCK TABLES `am_integration` WRITE;
/*!40000 ALTER TABLE `am_integration` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_invoice`
--

DROP TABLE IF EXISTS `am_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_invoice` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `paysys_id` varchar(64) DEFAULT NULL,
  `currency` char(3) NOT NULL,
  `first_subtotal` decimal(12,2) DEFAULT NULL,
  `first_discount` decimal(12,2) DEFAULT NULL,
  `first_tax` decimal(12,2) DEFAULT NULL,
  `first_shipping` decimal(12,2) DEFAULT NULL,
  `first_total` decimal(12,2) DEFAULT NULL,
  `first_period` varchar(32) NOT NULL,
  `rebill_times` int(11) DEFAULT NULL,
  `second_subtotal` decimal(12,2) DEFAULT NULL,
  `second_discount` decimal(12,2) DEFAULT NULL,
  `second_tax` decimal(12,2) DEFAULT NULL,
  `second_shipping` decimal(12,2) DEFAULT NULL,
  `second_total` decimal(12,2) DEFAULT NULL,
  `second_period` varchar(32) DEFAULT NULL,
  `tax_rate` varchar(255) DEFAULT NULL,
  `tax_type` varchar(255) DEFAULT NULL,
  `tax_title` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `coupon_id` int(11) DEFAULT NULL,
  `is_confirmed` tinyint(4) DEFAULT NULL,
  `public_id` char(16) NOT NULL,
  `invoice_key` varchar(32) DEFAULT NULL,
  `tm_added` datetime NOT NULL,
  `tm_started` datetime DEFAULT NULL,
  `tm_cancelled` datetime DEFAULT NULL,
  `rebill_date` date DEFAULT NULL,
  `comment` text,
  `base_currency_multi` decimal(12,6) DEFAULT '1.000000',
  PRIMARY KEY (`invoice_id`),
  UNIQUE KEY `public_id` (`public_id`),
  KEY `user_id` (`user_id`),
  KEY `rebill_date` (`rebill_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_invoice`
--

LOCK TABLES `am_invoice` WRITE;
/*!40000 ALTER TABLE `am_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_invoice_item`
--

DROP TABLE IF EXISTS `am_invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_invoice_item` (
  `invoice_item_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `item_type` varchar(16) NOT NULL DEFAULT 'product',
  `item_title` varchar(255) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '1',
  `first_price` decimal(12,2) NOT NULL,
  `first_discount` decimal(12,2) NOT NULL,
  `first_tax` decimal(12,2) NOT NULL,
  `first_total` decimal(12,2) NOT NULL,
  `first_shipping` decimal(12,2) NOT NULL,
  `first_period` varchar(32) NOT NULL,
  `rebill_times` int(11) DEFAULT NULL,
  `second_price` decimal(12,2) DEFAULT NULL,
  `second_discount` decimal(12,2) DEFAULT NULL,
  `second_tax` decimal(12,2) DEFAULT NULL,
  `second_total` decimal(12,2) DEFAULT NULL,
  `second_shipping` decimal(12,2) DEFAULT NULL,
  `second_period` varchar(32) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `tax_group` varchar(255) DEFAULT '-1',
  `is_countable` tinyint(4) NOT NULL DEFAULT '0',
  `variable_qty` tinyint(4) NOT NULL DEFAULT '0',
  `is_tangible` tinyint(4) DEFAULT NULL,
  `billing_plan_id` int(11) DEFAULT NULL,
  `billing_plan_data` text,
  `option1` varchar(255) DEFAULT NULL,
  `option2` varchar(255) DEFAULT NULL,
  `option3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`invoice_item_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_invoice_item`
--

LOCK TABLES `am_invoice_item` WRITE;
/*!40000 ALTER TABLE `am_invoice_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_invoice_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_invoice_log`
--

DROP TABLE IF EXISTS `am_invoice_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_invoice_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `tm` datetime NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `paysys_id` varchar(64) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `details` text,
  `remote_addr` varchar(15) DEFAULT NULL,
  `is_processed` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_invoice_log`
--

LOCK TABLES `am_invoice_log` WRITE;
/*!40000 ALTER TABLE `am_invoice_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_invoice_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_invoice_payment`
--

DROP TABLE IF EXISTS `am_invoice_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_invoice_payment` (
  `invoice_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `paysys_id` varchar(64) DEFAULT NULL,
  `receipt_id` varchar(64) NOT NULL,
  `transaction_id` varchar(64) NOT NULL,
  `dattm` datetime NOT NULL,
  `currency` char(3) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) DEFAULT NULL,
  `tax` decimal(12,2) DEFAULT NULL,
  `shipping` decimal(12,2) DEFAULT NULL,
  `refund_dattm` datetime DEFAULT NULL,
  `base_currency_multi` decimal(12,6) DEFAULT '1.000000',
  PRIMARY KEY (`invoice_payment_id`),
  UNIQUE KEY `invoice_id` (`invoice_id`,`user_id`,`transaction_id`),
  KEY `user_id` (`user_id`),
  KEY `dattm` (`dattm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_invoice_payment`
--

LOCK TABLES `am_invoice_payment` WRITE;
/*!40000 ALTER TABLE `am_invoice_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_invoice_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_invoice_refund`
--

DROP TABLE IF EXISTS `am_invoice_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_invoice_refund` (
  `invoice_refund_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `invoice_payment_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `paysys_id` varchar(64) DEFAULT NULL,
  `receipt_id` varchar(64) NOT NULL,
  `transaction_id` varchar(64) NOT NULL,
  `dattm` datetime NOT NULL,
  `currency` char(3) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `refund_type` int(11) NOT NULL DEFAULT '0',
  `base_currency_multi` decimal(12,6) DEFAULT '1.000000',
  PRIMARY KEY (`invoice_refund_id`),
  UNIQUE KEY `invoice_id` (`invoice_id`,`user_id`,`transaction_id`),
  KEY `user_id` (`user_id`),
  KEY `dattm` (`dattm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_invoice_refund`
--

LOCK TABLES `am_invoice_refund` WRITE;
/*!40000 ALTER TABLE `am_invoice_refund` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_invoice_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_link`
--

DROP TABLE IF EXISTS `am_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `dattm` datetime DEFAULT NULL,
  `hide` smallint(6) DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_link`
--

LOCK TABLES `am_link` WRITE;
/*!40000 ALTER TABLE `am_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_mail_queue`
--

DROP TABLE IF EXISTS `am_mail_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_mail_queue` (
  `queue_id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `recipients` varchar(255) NOT NULL,
  `count_recipients` smallint(6) NOT NULL,
  `subject` text,
  `added` int(11) NOT NULL,
  `sent` int(11) DEFAULT NULL,
  `failures` int(11) DEFAULT '0',
  `priority` int(11) DEFAULT '0',
  `last_error` varchar(255) DEFAULT NULL,
  `headers` blob,
  `body` blob,
  PRIMARY KEY (`queue_id`),
  KEY `sent` (`sent`,`priority`,`added`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_mail_queue`
--

LOCK TABLES `am_mail_queue` WRITE;
/*!40000 ALTER TABLE `am_mail_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_mail_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_newsletter_list`
--

DROP TABLE IF EXISTS `am_newsletter_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_newsletter_list` (
  `list_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plugin_id` varchar(64) DEFAULT NULL,
  `plugin_list_id` varchar(255) DEFAULT NULL,
  `title` varchar(60) NOT NULL,
  `desc` text,
  `disabled` smallint(6) NOT NULL DEFAULT '0',
  `auto_subscribe` smallint(6) NOT NULL DEFAULT '0',
  `auto_unsubscribe` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_newsletter_list`
--

LOCK TABLES `am_newsletter_list` WRITE;
/*!40000 ALTER TABLE `am_newsletter_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_newsletter_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_newsletter_user_subscription`
--

DROP TABLE IF EXISTS `am_newsletter_user_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_newsletter_user_subscription` (
  `subscription_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `list_id` int(11) NOT NULL,
  `is_active` smallint(6) NOT NULL DEFAULT '1',
  `type` enum('auto','user','unsubscribed') NOT NULL DEFAULT 'auto',
  PRIMARY KEY (`subscription_id`),
  UNIQUE KEY `user_list` (`user_id`,`list_id`),
  KEY `list` (`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_newsletter_user_subscription`
--

LOCK TABLES `am_newsletter_user_subscription` WRITE;
/*!40000 ALTER TABLE `am_newsletter_user_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_newsletter_user_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_page`
--

DROP TABLE IF EXISTS `am_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text,
  `path` varchar(255) NOT NULL,
  `use_layout` int(11) DEFAULT '0',
  `html` text,
  `dattm` datetime DEFAULT NULL,
  `hide` smallint(6) DEFAULT '0',
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_page`
--

LOCK TABLES `am_page` WRITE;
/*!40000 ALTER TABLE `am_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_product`
--

DROP TABLE IF EXISTS `am_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_product` (
  `img` int(11) DEFAULT NULL,
  `img_path` varchar(255) DEFAULT NULL,
  `cart_description` text,
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `trial_group` varchar(32) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `currency` varchar(12) DEFAULT NULL,
  `tax_group` varchar(255) DEFAULT '-1',
  `sort_order` varchar(32) DEFAULT NULL,
  `renewal_group` varchar(255) DEFAULT NULL,
  `start_date_fixed` date DEFAULT NULL,
  `require_other` text,
  `prevent_if_other` text,
  `paysys_id` varchar(255) DEFAULT NULL,
  `comment` text,
  `default_billing_plan_id` int(11) DEFAULT NULL,
  `is_tangible` tinyint(4) NOT NULL DEFAULT '0',
  `is_disabled` tinyint(4) NOT NULL DEFAULT '0',
  `reward_points_user` int(11) DEFAULT NULL,
  `reward_points_aff` int(11) DEFAULT NULL,
  `subusers_product_id` int(10) unsigned DEFAULT NULL,
  `subusers_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_product`
--

LOCK TABLES `am_product` WRITE;
/*!40000 ALTER TABLE `am_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_product_category`
--

DROP TABLE IF EXISTS `am_product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_product_category` (
  `product_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `parent_id` int(11) DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_category_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_product_category`
--

LOCK TABLES `am_product_category` WRITE;
/*!40000 ALTER TABLE `am_product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_product_product_category`
--

DROP TABLE IF EXISTS `am_product_product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_product_product_category` (
  `product_product_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `product_category_id` int(11) NOT NULL,
  PRIMARY KEY (`product_product_category_id`),
  UNIQUE KEY `product_category` (`product_id`,`product_category_id`),
  KEY `product_category_id` (`product_category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_product_product_category`
--

LOCK TABLES `am_product_product_category` WRITE;
/*!40000 ALTER TABLE `am_product_product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_product_product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_product_upgrade`
--

DROP TABLE IF EXISTS `am_product_upgrade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_product_upgrade` (
  `product_upgrade_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_billing_plan_id` int(11) DEFAULT NULL,
  `to_billing_plan_id` int(11) DEFAULT NULL,
  `surcharge` decimal(12,2) DEFAULT '0.00',
  PRIMARY KEY (`product_upgrade_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_product_upgrade`
--

LOCK TABLES `am_product_upgrade` WRITE;
/*!40000 ALTER TABLE `am_product_upgrade` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_product_upgrade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_rebill_log`
--

DROP TABLE IF EXISTS `am_rebill_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_rebill_log` (
  `rebill_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `added_tm` datetime NOT NULL,
  `payment_date` date NOT NULL,
  `payment_id` int(11) NOT NULL,
  `rebill_payment_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` smallint(6) DEFAULT NULL,
  `status_tm` datetime DEFAULT NULL,
  `status_msg` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rebill_log_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_rebill_log`
--

LOCK TABLES `am_rebill_log` WRITE;
/*!40000 ALTER TABLE `am_rebill_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_rebill_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_resource_access`
--

DROP TABLE IF EXISTS `am_resource_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_resource_access` (
  `resource_access_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) DEFAULT NULL,
  `resource_type` varchar(64) NOT NULL,
  `fn` enum('product_id','product_category_id','free','free_without_login') NOT NULL,
  `id` int(11) NOT NULL,
  `start_days` int(11) DEFAULT NULL,
  `stop_days` int(11) DEFAULT NULL,
  PRIMARY KEY (`resource_access_id`),
  KEY `res` (`resource_type`,`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_resource_access`
--

LOCK TABLES `am_resource_access` WRITE;
/*!40000 ALTER TABLE `am_resource_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_resource_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_resource_access_sort`
--

DROP TABLE IF EXISTS `am_resource_access_sort`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_resource_access_sort` (
  `resource_access_sort_id` int(11) NOT NULL AUTO_INCREMENT,
  `resource_id` int(11) DEFAULT NULL,
  `resource_type` varchar(64) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`resource_access_sort_id`),
  UNIQUE KEY `res` (`resource_type`,`resource_id`),
  KEY `sort_order` (`sort_order`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_resource_access_sort`
--

LOCK TABLES `am_resource_access_sort` WRITE;
/*!40000 ALTER TABLE `am_resource_access_sort` DISABLE KEYS */;
INSERT INTO `am_resource_access_sort` VALUES (1,1,'emailtemplate',1),(2,2,'emailtemplate',2),(3,3,'emailtemplate',3),(4,4,'emailtemplate',4),(5,5,'emailtemplate',5),(6,6,'emailtemplate',6),(7,7,'emailtemplate',7),(8,8,'emailtemplate',8),(9,9,'emailtemplate',9),(10,10,'emailtemplate',10),(11,11,'emailtemplate',11),(12,12,'emailtemplate',12),(13,13,'emailtemplate',13),(14,14,'emailtemplate',14),(15,15,'emailtemplate',15),(16,16,'emailtemplate',16),(17,17,'emailtemplate',17),(18,18,'emailtemplate',18),(19,19,'emailtemplate',19),(20,20,'emailtemplate',20),(21,21,'emailtemplate',21),(22,22,'emailtemplate',22),(23,23,'emailtemplate',23),(24,24,'emailtemplate',24),(25,25,'emailtemplate',25),(26,26,'emailtemplate',26),(27,27,'emailtemplate',27),(28,28,'emailtemplate',28),(29,29,'emailtemplate',29),(30,30,'emailtemplate',30),(31,31,'emailtemplate',31),(32,32,'emailtemplate',32),(33,33,'emailtemplate',33),(34,34,'emailtemplate',34);
/*!40000 ALTER TABLE `am_resource_access_sort` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_reward_point`
--

DROP TABLE IF EXISTS `am_reward_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_reward_point` (
  `history_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('CREDIT','DEBIT') NOT NULL,
  `count` int(11) NOT NULL,
  `dattm` datetime NOT NULL,
  `credit_type` enum('PURCHASE','AFF','ADMIN') DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `user` (`user_id`,`dattm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_reward_point`
--

LOCK TABLES `am_reward_point` WRITE;
/*!40000 ALTER TABLE `am_reward_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_reward_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_saved_form`
--

DROP TABLE IF EXISTS `am_saved_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_saved_form` (
  `saved_form_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `fields` text,
  `tpl` varchar(255) DEFAULT NULL,
  `type` varchar(16) DEFAULT NULL,
  `default_for` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`saved_form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_saved_form`
--

LOCK TABLES `am_saved_form` WRITE;
/*!40000 ALTER TABLE `am_saved_form` DISABLE KEYS */;
INSERT INTO `am_saved_form` VALUES (1,'Signup Form','customer signup/payment form','default','[{\"id\":\"product-0\",\"class\":\"product\"},{\"id\":\"paysystem\",\"class\":\"paysystem\"},{\"id\":\"name\",\"class\":\"name\",\"hide-if-logged-in\":true},{\"id\":\"email\",\"class\":\"email\",\"hide-if-logged-in\":true},{\"id\":\"login\",\"class\":\"login\",\"hide-if-logged-in\":true},{\"id\":\"password\",\"class\":\"password\",\"hide-if-logged-in\":true}]',NULL,'signup','signup,member'),(2,'Create Customer Profile','shopping cart signup form',NULL,'[{\"id\":\"name\",\"class\":\"name\",\"hide-if-logged-in\":true},{\"id\":\"email\",\"class\":\"email\",\"hide-if-logged-in\":true},{\"id\":\"login\",\"class\":\"login\",\"hide-if-logged-in\":true},{\"id\":\"password\",\"class\":\"password\",\"hide-if-logged-in\":true}]',NULL,'cart',NULL),(3,'Customer Profile','customer profile form',NULL,'[{\"id\":\"name\",\"class\":\"name\",\"hide-if-logged-in\":true},{\"id\":\"email\",\"class\":\"email\",\"hide-if-logged-in\":true},{\"id\":\"new-password\",\"class\":\"new-password\"}]',NULL,'profile',NULL);
/*!40000 ALTER TABLE `am_saved_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_saved_pass`
--

DROP TABLE IF EXISTS `am_saved_pass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_saved_pass` (
  `saved_pass_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `format` varchar(32) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`saved_pass_id`),
  UNIQUE KEY `user` (`user_id`,`format`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_saved_pass`
--

LOCK TABLES `am_saved_pass` WRITE;
/*!40000 ALTER TABLE `am_saved_pass` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_saved_pass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_saved_report`
--

DROP TABLE IF EXISTS `am_saved_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_saved_report` (
  `saved_report_id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` varchar(64) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `request` blob,
  `admin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`saved_report_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_saved_report`
--

LOCK TABLES `am_saved_report` WRITE;
/*!40000 ALTER TABLE `am_saved_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_saved_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_saved_search`
--

DROP TABLE IF EXISTS `am_saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_saved_search` (
  `saved_search_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `class` varchar(64) NOT NULL,
  `search` text,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`saved_search_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_saved_search`
--

LOCK TABLES `am_saved_search` WRITE;
/*!40000 ALTER TABLE `am_saved_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_session`
--

DROP TABLE IF EXISTS `am_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_session` (
  `id` char(32) NOT NULL,
  `modified` int(11) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_session`
--

LOCK TABLES `am_session` WRITE;
/*!40000 ALTER TABLE `am_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_softsale_license`
--

DROP TABLE IF EXISTS `am_softsale_license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_softsale_license` (
  `license_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `invoice_id` int(10) unsigned NOT NULL,
  `scheme_id` int(10) unsigned NOT NULL,
  `serial` varchar(255) NOT NULL,
  `started` datetime DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`license_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_softsale_license`
--

LOCK TABLES `am_softsale_license` WRITE;
/*!40000 ALTER TABLE `am_softsale_license` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_softsale_license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_softsale_license_scheme`
--

DROP TABLE IF EXISTS `am_softsale_license_scheme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_softsale_license_scheme` (
  `scheme_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `comment` varchar(1024) DEFAULT NULL,
  `algo_id` varchar(255) NOT NULL,
  `is_disabled` tinyint(4) NOT NULL DEFAULT '0',
  `secret` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`scheme_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_softsale_license_scheme`
--

LOCK TABLES `am_softsale_license_scheme` WRITE;
/*!40000 ALTER TABLE `am_softsale_license_scheme` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_softsale_license_scheme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_state`
--

DROP TABLE IF EXISTS `am_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_state` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `state` char(12) NOT NULL,
  `country` char(2) NOT NULL,
  `title` varchar(64) DEFAULT NULL,
  `status` enum('added','changed') DEFAULT NULL,
  `tag` int(11) DEFAULT '0',
  PRIMARY KEY (`state_id`),
  UNIQUE KEY `state` (`state`),
  KEY `country` (`country`)
) ENGINE=MyISAM AUTO_INCREMENT=4094 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_state`
--

LOCK TABLES `am_state` WRITE;
/*!40000 ALTER TABLE `am_state` DISABLE KEYS */;
INSERT INTO `am_state` VALUES (1,'AD-ALV','AD','Andorra la Vella',NULL,0),(2,'AD-CAN','AD','Canillo',NULL,0),(3,'AD-ENC','AD','Encamp',NULL,0),(4,'AD-ESE','AD','Escaldes-Engordany',NULL,0),(5,'AD-LMA','AD','La Massana',NULL,0),(6,'AD-ORD','AD','Ordino',NULL,0),(7,'AD-SJL','AD','Sant Julia de LOA',NULL,0),(8,'AE-AJ','AE','\'Ajman',NULL,0),(9,'AE-AZ','AE','Abu Zaby',NULL,0),(10,'AE-DU','AE','Dubayy',NULL,0),(11,'AE-FU','AE','Al Fujayrah',NULL,0),(12,'AE-RK','AE','R\'as al Khaymah',NULL,0),(13,'AE-SH','AE','Ash Shariqah',NULL,0),(14,'AE-UQ','AE','Umm al Qaywayn',NULL,0),(15,'AF-BAL','AF','Balkh province',NULL,0),(16,'AF-BAM','AF','Bamian province',NULL,0),(17,'AF-BDG','AF','Badghis province',NULL,0),(18,'AF-BDS','AF','Badakhshan province',NULL,0),(19,'AF-BGL','AF','Baghlan province',NULL,0),(20,'AF-FRA','AF','Farah province',NULL,0),(21,'AF-FYB','AF','Faryab province',NULL,0),(22,'AF-GHA','AF','Ghazni province',NULL,0),(23,'AF-GHO','AF','Ghowr province',NULL,0),(24,'AF-HEL','AF','Helmand province',NULL,0),(25,'AF-HER','AF','Herat province',NULL,0),(26,'AF-JOW','AF','Jowzjan province',NULL,0),(27,'AF-KAB','AF','Kabul province',NULL,0),(28,'AF-KAN','AF','Kandahar province',NULL,0),(29,'AF-KAP','AF','Kapisa province',NULL,0),(30,'AF-KDZ','AF','Kondoz province',NULL,0),(31,'AF-KHO','AF','Khost province',NULL,0),(32,'AF-KNR','AF','Konar province',NULL,0),(33,'AF-LAG','AF','Laghman province',NULL,0),(34,'AF-LOW','AF','Lowgar province',NULL,0),(35,'AF-NAN','AF','Nangrahar province',NULL,0),(36,'AF-NIM','AF','Nimruz province',NULL,0),(37,'AF-NUR','AF','Nurestan province',NULL,0),(38,'AF-ORU','AF','Oruzgan province',NULL,0),(39,'AF-PAR','AF','Parwan province',NULL,0),(40,'AF-PIA','AF','Paktia province',NULL,0),(41,'AF-PKA','AF','Paktika province',NULL,0),(42,'AF-SAM','AF','Samangan province',NULL,0),(43,'AF-SAR','AF','Sar-e Pol province',NULL,0),(44,'AF-TAK','AF','Takhar province',NULL,0),(45,'AF-WAR','AF','Wardak province',NULL,0),(46,'AF-ZAB','AF','Zabol province',NULL,0),(47,'AG-ASG','AG','Saint George',NULL,0),(48,'AG-ASH','AG','Saint Philip',NULL,0),(49,'AG-ASJ','AG','Saint John',NULL,0),(50,'AG-ASL','AG','Saint Paul',NULL,0),(51,'AG-ASM','AG','Saint Mary',NULL,0),(52,'AG-ASR','AG','Saint Peter',NULL,0),(53,'AG-BAR','AG','Barbuda',NULL,0),(54,'AG-RED','AG','Redonda',NULL,0),(55,'AL-BR','AL','Berat',NULL,0),(56,'AL-BU','AL','Bulqize',NULL,0),(57,'AL-DI','AL','Diber',NULL,0),(58,'AL-DL','AL','Delvine',NULL,0),(59,'AL-DR','AL','Durres',NULL,0),(60,'AL-DV','AL','Devoll',NULL,0),(61,'AL-EL','AL','Elbasan',NULL,0),(62,'AL-ER','AL','Kolonje',NULL,0),(63,'AL-FR','AL','Fier',NULL,0),(64,'AL-GJ','AL','Gjirokaster',NULL,0),(65,'AL-GR','AL','Gramsh',NULL,0),(66,'AL-HA','AL','Has',NULL,0),(67,'AL-KA','AL','Kavaje',NULL,0),(68,'AL-KB','AL','Kurbin',NULL,0),(69,'AL-KC','AL','Kucove',NULL,0),(70,'AL-KO','AL','Korce',NULL,0),(71,'AL-KR','AL','Kruje',NULL,0),(72,'AL-KU','AL','Kukes',NULL,0),(73,'AL-LB','AL','Librazhd',NULL,0),(74,'AL-LE','AL','Lezhe',NULL,0),(75,'AL-LU','AL','Lushnje',NULL,0),(76,'AL-MK','AL','Mallakaster',NULL,0),(77,'AL-MM','AL','Malesi e Madhe',NULL,0),(78,'AL-MR','AL','Mirdite',NULL,0),(79,'AL-MT','AL','Mat',NULL,0),(80,'AL-PG','AL','Pogradec',NULL,0),(81,'AL-PQ','AL','Peqin',NULL,0),(82,'AL-PR','AL','Permet',NULL,0),(83,'AL-PU','AL','Puke',NULL,0),(84,'AL-SH','AL','Shkoder',NULL,0),(85,'AL-SK','AL','Skrapar',NULL,0),(86,'AL-SR','AL','Sarande',NULL,0),(87,'AL-TE','AL','Tepelene',NULL,0),(88,'AL-TP','AL','Tropoje',NULL,0),(89,'AL-TR','AL','Tirane',NULL,0),(90,'AL-VL','AL','Vlore',NULL,0),(91,'AM-AGT','AM','Aragatsotn',NULL,0),(92,'AM-ARM','AM','Armavir',NULL,0),(93,'AM-ARR','AM','Ararat',NULL,0),(94,'AM-GEG','AM','Geghark\'unik\'',NULL,0),(95,'AM-KOT','AM','Kotayk\'',NULL,0),(96,'AM-LOR','AM','Lorri',NULL,0),(97,'AM-SHI','AM','Shirak',NULL,0),(98,'AM-SYU','AM','Syunik\'',NULL,0),(99,'AM-TAV','AM','Tavush',NULL,0),(100,'AM-VAY','AM','Vayots\' Dzor',NULL,0),(101,'AM-YER','AM','Yerevan',NULL,0),(102,'AO-BGO','AO','Bengo',NULL,0),(103,'AO-BGU','AO','Benguela province',NULL,0),(104,'AO-BIE','AO','Bie',NULL,0),(105,'AO-CAB','AO','Cabinda',NULL,0),(106,'AO-CCU','AO','Cuando-Cubango',NULL,0),(107,'AO-CNN','AO','Cunene',NULL,0),(108,'AO-CNO','AO','Cuanza Norte',NULL,0),(109,'AO-CUS','AO','Cuanza Sul',NULL,0),(110,'AO-HUA','AO','Huambo province',NULL,0),(111,'AO-HUI','AO','Huila province',NULL,0),(112,'AO-LNO','AO','Lunda Norte',NULL,0),(113,'AO-LSU','AO','Lunda Sul',NULL,0),(114,'AO-LUA','AO','Luanda',NULL,0),(115,'AO-MAL','AO','Malange',NULL,0),(116,'AO-MOX','AO','Moxico',NULL,0),(117,'AO-NAM','AO','Namibe',NULL,0),(118,'AO-UIG','AO','Uige',NULL,0),(119,'AO-ZAI','AO','Zaire',NULL,0),(120,'AR-A','AR','Salta',NULL,0),(121,'AR-B','AR','Buenos Aires Province',NULL,0),(122,'AR-C','AR','Distrito Federal',NULL,0),(123,'AR-D','AR','San Luis',NULL,0),(124,'AR-E','AR','Entre Rios',NULL,0),(125,'AR-F','AR','La Rioja',NULL,0),(126,'AR-G','AR','Santiago del Estero',NULL,0),(127,'AR-H','AR','Chaco',NULL,0),(128,'AR-J','AR','San Juan',NULL,0),(129,'AR-K','AR','Catamarca',NULL,0),(130,'AR-L','AR','La Pampa',NULL,0),(131,'AR-M','AR','Mendoza',NULL,0),(132,'AR-N','AR','Misiones',NULL,0),(133,'AR-P','AR','Formosa',NULL,0),(134,'AR-Q','AR','Neuquen',NULL,0),(135,'AR-R','AR','Rio Negro',NULL,0),(136,'AR-S','AR','Santa Fe',NULL,0),(137,'AR-T','AR','Tucuman',NULL,0),(138,'AR-U','AR','Chubut',NULL,0),(139,'AR-V','AR','Tierra del Fuego',NULL,0),(140,'AR-W','AR','Corrientes',NULL,0),(141,'AR-X','AR','Cordoba',NULL,0),(142,'AR-Y','AR','Jujuy',NULL,0),(143,'AR-Z','AR','Santa Cruz',NULL,0),(144,'AS-E','AS','Eastern',NULL,0),(145,'AS-M','AS','Manu\'a',NULL,0),(146,'AS-R','AS','Rose Island',NULL,0),(147,'AS-S','AS','Swains Island',NULL,0),(148,'AS-W','AS','Western',NULL,0),(149,'AT-BUR','AT','Burgenland',NULL,0),(150,'AT-KAR','AT','Karnten',NULL,0),(151,'AT-NOS','AT','Niederosterreich',NULL,0),(152,'AT-OOS','AT','Oberosterreich',NULL,0),(153,'AT-SAL','AT','Salzburg',NULL,0),(154,'AT-STE','AT','Steiermark',NULL,0),(155,'AT-TIR','AT','Tirol',NULL,0),(156,'AT-VOR','AT','Vorarlberg',NULL,0),(157,'AT-WIE','AT','Wien',NULL,0),(158,'AU-ACT','AU','Australian Capital Territory',NULL,0),(159,'AU-NSW','AU','New South Wales',NULL,0),(160,'AU-NT','AU','Northern Territory',NULL,0),(161,'AU-QLD','AU','Queensland',NULL,0),(162,'AU-SA','AU','South Australia',NULL,0),(163,'AU-TAS','AU','Tasmania',NULL,0),(164,'AU-VIC','AU','Victoria',NULL,0),(165,'AU-WA','AU','Western Australia',NULL,0),(166,'AZ-AB','AZ','Ali Bayramli',NULL,0),(167,'AZ-ABS','AZ','Abseron',NULL,0),(168,'AZ-AGA','AZ','Agstafa',NULL,0),(169,'AZ-AGC','AZ','AgcabAdi',NULL,0),(170,'AZ-AGM','AZ','Agdam',NULL,0),(171,'AZ-AGS','AZ','Agdas',NULL,0),(172,'AZ-AGU','AZ','Agsu',NULL,0),(173,'AZ-AST','AZ','Astara',NULL,0),(174,'AZ-BA','AZ','Baki',NULL,0),(175,'AZ-BAB','AZ','Babak',NULL,0),(176,'AZ-BAL','AZ','Balakan',NULL,0),(177,'AZ-BAR','AZ','Barda',NULL,0),(178,'AZ-BEY','AZ','Beylaqan',NULL,0),(179,'AZ-BIL','AZ','Bilasuvar',NULL,0),(180,'AZ-CAB','AZ','Cabrayil',NULL,0),(181,'AZ-CAL','AZ','Calilabab',NULL,0),(182,'AZ-CUL','AZ','Culfa',NULL,0),(183,'AZ-DAS','AZ','Daskasan',NULL,0),(184,'AZ-DAV','AZ','Davaci',NULL,0),(185,'AZ-FUZ','AZ','Fuzuli',NULL,0),(186,'AZ-GA','AZ','Ganca',NULL,0),(187,'AZ-GAD','AZ','Gadabay',NULL,0),(188,'AZ-GOR','AZ','Goranboy',NULL,0),(189,'AZ-GOY','AZ','Goycay',NULL,0),(190,'AZ-HAC','AZ','Haciqabul',NULL,0),(191,'AZ-IMI','AZ','Imisli',NULL,0),(192,'AZ-ISM','AZ','Ismayilli',NULL,0),(193,'AZ-KAL','AZ','Kalbacar',NULL,0),(194,'AZ-KUR','AZ','Kurdamir',NULL,0),(195,'AZ-LAC','AZ','Lacin',NULL,0),(196,'AZ-LAN','AZ','Lankaran',NULL,0),(197,'AZ-LER','AZ','Lerik',NULL,0),(198,'AZ-MAS','AZ','Masalli',NULL,0),(199,'AZ-MI','AZ','Mingacevir',NULL,0),(200,'AZ-NA','AZ','Naftalan',NULL,0),(201,'AZ-NEF','AZ','Neftcala',NULL,0),(202,'AZ-NX','AZ','Naxcivan',NULL,0),(203,'AZ-OGU','AZ','Oguz',NULL,0),(204,'AZ-ORD','AZ','Ordubad',NULL,0),(205,'AZ-QAB','AZ','Qabala',NULL,0),(206,'AZ-QAX','AZ','Qax',NULL,0),(207,'AZ-QAZ','AZ','Qazax',NULL,0),(208,'AZ-QBA','AZ','Quba',NULL,0),(209,'AZ-QBI','AZ','Qubadli',NULL,0),(210,'AZ-QOB','AZ','Qobustan',NULL,0),(211,'AZ-QUS','AZ','Qusar',NULL,0),(212,'AZ-SA','AZ','Saki',NULL,0),(213,'AZ-SAB','AZ','Sabirabad',NULL,0),(214,'AZ-SAD','AZ','Sadarak',NULL,0),(215,'AZ-SAH','AZ','Sahbuz',NULL,0),(216,'AZ-SAK','AZ','Saki',NULL,0),(217,'AZ-SAL','AZ','Salyan',NULL,0),(218,'AZ-SAR','AZ','Sarur',NULL,0),(219,'AZ-SAT','AZ','Saatli',NULL,0),(220,'AZ-SIY','AZ','Siyazan',NULL,0),(221,'AZ-SKR','AZ','Samkir',NULL,0),(222,'AZ-SM','AZ','Sumqayit',NULL,0),(223,'AZ-SMI','AZ','Samaxi',NULL,0),(224,'AZ-SMX','AZ','Samux',NULL,0),(225,'AZ-SS','AZ','Susa',NULL,0),(226,'AZ-SUS','AZ','Susa',NULL,0),(227,'AZ-TAR','AZ','Tartar',NULL,0),(228,'AZ-TOV','AZ','Tovuz',NULL,0),(229,'AZ-UCA','AZ','Ucar',NULL,0),(230,'AZ-XA','AZ','Xankandi',NULL,0),(231,'AZ-XAC','AZ','Xacmaz',NULL,0),(232,'AZ-XAN','AZ','Xanlar',NULL,0),(233,'AZ-XCI','AZ','Xocali',NULL,0),(234,'AZ-XIZ','AZ','Xizi',NULL,0),(235,'AZ-XVD','AZ','Xocavand',NULL,0),(236,'AZ-YAR','AZ','Yardimli',NULL,0),(237,'AZ-YEV','AZ','Yevlax',NULL,0),(238,'AZ-ZAN','AZ','Zangilan',NULL,0),(239,'AZ-ZAQ','AZ','Zaqatala',NULL,0),(240,'AZ-ZAR','AZ','Zardab',NULL,0),(241,'BA-BRO','BA','Brcko district',NULL,0),(242,'BA-FBP','BA','Bosanskopodrinjski Kanton',NULL,0),(243,'BA-FHN','BA','Hercegovacko-neretvanski Kanton',NULL,0),(244,'BA-FPO','BA','Posavski Kanton',NULL,0),(245,'BA-FSA','BA','Kanton Sarajevo',NULL,0),(246,'BA-FSB','BA','Srednjebosanski Kanton',NULL,0),(247,'BA-FTU','BA','Tuzlanski Kanton',NULL,0),(248,'BA-FUS','BA','Unsko-Sanski Kanton',NULL,0),(249,'BA-FZA','BA','Zapadnobosanska',NULL,0),(250,'BA-FZE','BA','Zenicko-Dobojski Kanton',NULL,0),(251,'BA-FZH','BA','Zapadnohercegovacka Zupanija',NULL,0),(252,'BA-SBI','BA','Bijeljina',NULL,0),(253,'BA-SBL','BA','Banja Luka',NULL,0),(254,'BA-SDO','BA','Doboj',NULL,0),(255,'BA-SFO','BA','Foca',NULL,0),(256,'BA-SSR','BA','Sarajevo-Romanija or Sokolac',NULL,0),(257,'BA-STR','BA','Trebinje',NULL,0),(258,'BA-SVL','BA','Vlasenica',NULL,0),(259,'BB-AND','BB','Saint Andrew',NULL,0),(260,'BB-CC','BB','Christ Church',NULL,0),(261,'BB-GEO','BB','Saint George',NULL,0),(262,'BB-JAM','BB','Saint James',NULL,0),(263,'BB-JOH','BB','Saint John',NULL,0),(264,'BB-JOS','BB','Saint Joseph',NULL,0),(265,'BB-LUC','BB','Saint Lucy',NULL,0),(266,'BB-MIC','BB','Saint Michael',NULL,0),(267,'BB-PET','BB','Saint Peter',NULL,0),(268,'BB-PHI','BB','Saint Philip',NULL,0),(269,'BB-THO','BB','Saint Thomas',NULL,0),(270,'BD-BAR','BD','Barisal',NULL,0),(271,'BD-CHI','BD','Chittagong',NULL,0),(272,'BD-DHA','BD','Dhaka',NULL,0),(273,'BD-KHU','BD','Khulna',NULL,0),(274,'BD-RAJ','BD','Rajshahi',NULL,0),(275,'BD-SYL','BD','Sylhet',NULL,0),(276,'BE-VAN','BE','Antwerpen',NULL,0),(277,'BE-VBR','BE','Vlaams Brabant',NULL,0),(278,'BE-VLI','BE','Limburg',NULL,0),(279,'BE-VOV','BE','Oost-Vlaanderen',NULL,0),(280,'BE-VWV','BE','West-Vlaanderen',NULL,0),(281,'BE-WBR','BE','Brabant Wallon',NULL,0),(282,'BE-WHT','BE','Hainaut',NULL,0),(283,'BE-WLG','BE','Liege',NULL,0),(284,'BE-WLX','BE','Luxembourg',NULL,0),(285,'BE-WNA','BE','Namur',NULL,0),(286,'BF-BAL','BF','Bale',NULL,0),(287,'BF-BAM','BF','Bam',NULL,0),(288,'BF-BAN','BF','Banwa',NULL,0),(289,'BF-BAZ','BF','Bazega',NULL,0),(290,'BF-BLG','BF','Boulgou',NULL,0),(291,'BF-BOK','BF','Boulkiemde',NULL,0),(292,'BF-BOR','BF','Bougouriba',NULL,0),(293,'BF-COM','BF','Comoe',NULL,0),(294,'BF-GAN','BF','Ganzourgou',NULL,0),(295,'BF-GNA','BF','Gnagna',NULL,0),(296,'BF-GOU','BF','Gourma',NULL,0),(297,'BF-HOU','BF','Houet',NULL,0),(298,'BF-IOA','BF','Ioba',NULL,0),(299,'BF-KAD','BF','Kadiogo',NULL,0),(300,'BF-KEN','BF','Kenedougou',NULL,0),(301,'BF-KOD','BF','Komondjari',NULL,0),(302,'BF-KOL','BF','Koulpelogo',NULL,0),(303,'BF-KOP','BF','Kompienga',NULL,0),(304,'BF-KOS','BF','Kossi',NULL,0),(305,'BF-KOT','BF','Kouritenga',NULL,0),(306,'BF-KOW','BF','Kourweogo',NULL,0),(307,'BF-LER','BF','Leraba',NULL,0),(308,'BF-LOR','BF','Loroum',NULL,0),(309,'BF-MOU','BF','Mouhoun',NULL,0),(310,'BF-NAH','BF','Nahouri',NULL,0),(311,'BF-NAM','BF','Namentenga',NULL,0),(312,'BF-NAY','BF','Nayala',NULL,0),(313,'BF-NOU','BF','Noumbiel',NULL,0),(314,'BF-OUB','BF','Oubritenga',NULL,0),(315,'BF-OUD','BF','Oudalan',NULL,0),(316,'BF-PAS','BF','Passore',NULL,0),(317,'BF-PON','BF','Poni',NULL,0),(318,'BF-SAG','BF','Sanguie',NULL,0),(319,'BF-SAM','BF','Sanmatenga',NULL,0),(320,'BF-SEN','BF','Seno',NULL,0),(321,'BF-SIS','BF','Sissili',NULL,0),(322,'BF-SOM','BF','Soum',NULL,0),(323,'BF-SOR','BF','Sourou',NULL,0),(324,'BF-TAP','BF','Tapoa',NULL,0),(325,'BF-TUY','BF','Tuy',NULL,0),(326,'BF-YAG','BF','Yagha',NULL,0),(327,'BF-YAT','BF','Yatenga',NULL,0),(328,'BF-ZIR','BF','Ziro',NULL,0),(329,'BF-ZOD','BF','Zondoma',NULL,0),(330,'BF-ZOW','BF','Zoundweogo',NULL,0),(331,'BG-01','BG','Blagoevgrad',NULL,0),(332,'BG-02','BG','Burgas',NULL,0),(333,'BG-03','BG','Varna',NULL,0),(334,'BG-04','BG','Veliko Turnovo',NULL,0),(335,'BG-05','BG','Vidin',NULL,0),(336,'BG-06','BG','Vratsa',NULL,0),(337,'BG-07','BG','Gabrovo',NULL,0),(338,'BG-08','BG','Dobrich',NULL,0),(339,'BG-09','BG','Kurdzhali',NULL,0),(340,'BG-10','BG','Kyustendil',NULL,0),(341,'BG-11','BG','Lovech',NULL,0),(342,'BG-12','BG','Montana',NULL,0),(343,'BG-13','BG','Pazardzhik',NULL,0),(344,'BG-14','BG','Pernik',NULL,0),(345,'BG-15','BG','Pleven',NULL,0),(346,'BG-16','BG','Plovdiv',NULL,0),(347,'BG-17','BG','Razgrad',NULL,0),(348,'BG-18','BG','Ruse',NULL,0),(349,'BG-19','BG','Silistra',NULL,0),(350,'BG-20','BG','Sliven',NULL,0),(351,'BG-21','BG','Smolyan',NULL,0),(352,'BG-22','BG','Sofia Region',NULL,0),(353,'BG-23','BG','Sofia',NULL,0),(354,'BG-24','BG','Stara Zagora',NULL,0),(355,'BG-25','BG','Turgovishte',NULL,0),(356,'BG-26','BG','Khaskovo',NULL,0),(357,'BG-27','BG','Shumen',NULL,0),(358,'BG-28','BG','Yambol',NULL,0),(359,'BH-CAP','BH','Capital',NULL,0),(360,'BH-CEN','BH','Central',NULL,0),(361,'BH-MUH','BH','Muharraq',NULL,0),(362,'BH-NOR','BH','Northern',NULL,0),(363,'BH-SOU','BH','Southern',NULL,0),(364,'BI-BB','BI','Bubanza',NULL,0),(365,'BI-BJ','BI','Bujumbura',NULL,0),(366,'BI-BR','BI','Bururi',NULL,0),(367,'BI-CA','BI','Cankuzo',NULL,0),(368,'BI-CI','BI','Cibitoke',NULL,0),(369,'BI-GI','BI','Gitega',NULL,0),(370,'BI-KI','BI','Kirundo',NULL,0),(371,'BI-KR','BI','Karuzi',NULL,0),(372,'BI-KY','BI','Kayanza',NULL,0),(373,'BI-MA','BI','Makamba',NULL,0),(374,'BI-MU','BI','Muramvya',NULL,0),(375,'BI-MW','BI','Mwaro',NULL,0),(376,'BI-MY','BI','Muyinga',NULL,0),(377,'BI-NG','BI','Ngozi',NULL,0),(378,'BI-RT','BI','Rutana',NULL,0),(379,'BI-RY','BI','Ruyigi',NULL,0),(380,'BJ-AK','BJ','Atakora',NULL,0),(381,'BJ-AL','BJ','Alibori',NULL,0),(382,'BJ-AQ','BJ','Atlantique',NULL,0),(383,'BJ-BO','BJ','Borgou',NULL,0),(384,'BJ-CO','BJ','Collines',NULL,0),(385,'BJ-DO','BJ','Donga',NULL,0),(386,'BJ-KO','BJ','Kouffo',NULL,0),(387,'BJ-LI','BJ','Littoral',NULL,0),(388,'BJ-MO','BJ','Mono',NULL,0),(389,'BJ-OU','BJ','Oueme',NULL,0),(390,'BJ-PL','BJ','Plateau',NULL,0),(391,'BJ-ZO','BJ','Zou',NULL,0),(392,'BM-DS','BM','Devonshire',NULL,0),(393,'BM-GC','BM','Saint George City',NULL,0),(394,'BM-HA','BM','Hamilton',NULL,0),(395,'BM-HC','BM','Hamilton City',NULL,0),(396,'BM-PB','BM','Pembroke',NULL,0),(397,'BM-PG','BM','Paget',NULL,0),(398,'BM-SA','BM','Sandys',NULL,0),(399,'BM-SG','BM','Saint George\'s',NULL,0),(400,'BM-SH','BM','Southampton',NULL,0),(401,'BM-SM','BM','Smith\'s',NULL,0),(402,'BM-WA','BM','Warwick',NULL,0),(403,'BN-BEL','BN','Belait',NULL,0),(404,'BN-BRM','BN','Brunei and Muara',NULL,0),(405,'BN-TEM','BN','Temburong',NULL,0),(406,'BN-TUT','BN','Tutong',NULL,0),(407,'BO-BEN','BO','Departmento Beni',NULL,0),(408,'BO-CHU','BO','Departmento Chuquisaca',NULL,0),(409,'BO-COC','BO','Departmento Cochabamba',NULL,0),(410,'BO-LPZ','BO','Departmento La Paz',NULL,0),(411,'BO-ORU','BO','Departmento Oruro',NULL,0),(412,'BO-PAN','BO','Departmento Pando',NULL,0),(413,'BO-POT','BO','Departmento Potosi',NULL,0),(414,'BO-SCZ','BO','Departmento Santa Cruz',NULL,0),(415,'BO-TAR','BO','Departmento Tarija',NULL,0),(416,'BR-AC','BR','Acre',NULL,0),(417,'BR-AL','BR','Alagoas',NULL,0),(418,'BR-AM','BR','Amazonas',NULL,0),(419,'BR-AP','BR','Amapa',NULL,0),(420,'BR-BA','BR','Bahia',NULL,0),(421,'BR-CE','BR','Ceara',NULL,0),(422,'BR-DF','BR','Distrito Federal',NULL,0),(423,'BR-ES','BR','Espirito Santo',NULL,0),(424,'BR-GO','BR','Goias',NULL,0),(425,'BR-MA','BR','Maranhao',NULL,0),(426,'BR-MG','BR','Minas Gerais',NULL,0),(427,'BR-MS','BR','Mato Grosso do Sul',NULL,0),(428,'BR-MT','BR','Mato Grosso',NULL,0),(429,'BR-PA','BR','Para',NULL,0),(430,'BR-PB','BR','Paraiba',NULL,0),(431,'BR-PE','BR','Pernambuco',NULL,0),(432,'BR-PI','BR','Piaui',NULL,0),(433,'BR-PR','BR','Parana',NULL,0),(434,'BR-RJ','BR','Rio de Janeiro',NULL,0),(435,'BR-RN','BR','Rio Grande do Norte',NULL,0),(436,'BR-RO','BR','Rondonia',NULL,0),(437,'BR-RR','BR','Roraima',NULL,0),(438,'BR-RS','BR','Rio Grande do Sul',NULL,0),(439,'BR-SC','BR','Santa Catarina',NULL,0),(440,'BR-SE','BR','Sergipe',NULL,0),(441,'BR-SP','BR','Sao Paulo',NULL,0),(442,'BR-TO','BR','Tocantins',NULL,0),(443,'BS-ACK','BS','Acklins',NULL,0),(444,'BS-BER','BS','Berry Islands',NULL,0),(445,'BS-BIM','BS','Bimini',NULL,0),(446,'BS-BLK','BS','Black Point',NULL,0),(447,'BS-CAB','BS','Central Abaco',NULL,0),(448,'BS-CAN','BS','Central Andros',NULL,0),(449,'BS-CAT','BS','Cat Island',NULL,0),(450,'BS-CEL','BS','Central Eleuthera',NULL,0),(451,'BS-CRO','BS','Crooked Island',NULL,0),(452,'BS-EGB','BS','East Grand Bahama',NULL,0),(453,'BS-EXU','BS','Exuma',NULL,0),(454,'BS-FRE','BS','City of Freeport',NULL,0),(455,'BS-GRD','BS','Grand Cay',NULL,0),(456,'BS-HAR','BS','Harbour Island',NULL,0),(457,'BS-HOP','BS','Hope Town',NULL,0),(458,'BS-INA','BS','Inagua',NULL,0),(459,'BS-LNG','BS','Long Island',NULL,0),(460,'BS-MAN','BS','Mangrove Cay',NULL,0),(461,'BS-MAY','BS','Mayaguana',NULL,0),(462,'BS-MOO','BS','Moore\'s Island',NULL,0),(463,'BS-NAB','BS','North Abaco',NULL,0),(464,'BS-NAN','BS','North Andros',NULL,0),(465,'BS-NEL','BS','North Eleuthera',NULL,0),(466,'BS-RAG','BS','Ragged Island',NULL,0),(467,'BS-RUM','BS','Rum Cay',NULL,0),(468,'BS-SAB','BS','South Abaco',NULL,0),(469,'BS-SAL','BS','San Salvador',NULL,0),(470,'BS-SAN','BS','South Andros',NULL,0),(471,'BS-SEL','BS','South Eleuthera',NULL,0),(472,'BS-SWE','BS','Spanish Wells',NULL,0),(473,'BS-WGB','BS','West Grand Bahama',NULL,0),(474,'BT-BUM','BT','Bumthang',NULL,0),(475,'BT-CHU','BT','Chukha',NULL,0),(476,'BT-DAG','BT','Dagana',NULL,0),(477,'BT-GAS','BT','Gasa',NULL,0),(478,'BT-HAA','BT','Haa',NULL,0),(479,'BT-LHU','BT','Lhuntse',NULL,0),(480,'BT-MON','BT','Mongar',NULL,0),(481,'BT-PAR','BT','Paro',NULL,0),(482,'BT-PEM','BT','Pemagatshel',NULL,0),(483,'BT-PUN','BT','Punakha',NULL,0),(484,'BT-SAR','BT','Sarpang',NULL,0),(485,'BT-SAT','BT','Samtse',NULL,0),(486,'BT-SJO','BT','Samdrup Jongkhar',NULL,0),(487,'BT-THI','BT','Thimphu',NULL,0),(488,'BT-TRG','BT','Trashigang',NULL,0),(489,'BT-TRO','BT','Trongsa',NULL,0),(490,'BT-TRY','BT','Trashiyangste',NULL,0),(491,'BT-TSI','BT','Tsirang',NULL,0),(492,'BT-WPH','BT','Wangdue Phodrang',NULL,0),(493,'BT-ZHE','BT','Zhemgang',NULL,0),(494,'BW-CE','BW','Central',NULL,0),(495,'BW-GH','BW','Ghanzi',NULL,0),(496,'BW-KD','BW','Kgalagadi',NULL,0),(497,'BW-KT','BW','Kgatleng',NULL,0),(498,'BW-KW','BW','Kweneng',NULL,0),(499,'BW-NE','BW','North East',NULL,0),(500,'BW-NG','BW','Ngamiland',NULL,0),(501,'BW-NW','BW','North West',NULL,0),(502,'BW-SE','BW','South East',NULL,0),(503,'BW-SO','BW','Southern',NULL,0),(504,'BY-BR','BY','Brest voblast',NULL,0),(505,'BY-HO','BY','Homyel voblast',NULL,0),(506,'BY-HR','BY','Hrodna voblast',NULL,0),(507,'BY-MA','BY','Mahilyow voblast',NULL,0),(508,'BY-MI','BY','Minsk voblast',NULL,0),(509,'BY-VI','BY','Vitsebsk voblast',NULL,0),(510,'BZ-BZ','BZ','Belize District',NULL,0),(511,'BZ-CR','BZ','Corozal District',NULL,0),(512,'BZ-CY','BZ','Cayo District',NULL,0),(513,'BZ-OW','BZ','Orange Walk District',NULL,0),(514,'BZ-SC','BZ','Stann Creek District',NULL,0),(515,'BZ-TO','BZ','Toledo District',NULL,0),(516,'AB','CA','Alberta',NULL,0),(517,'BC','CA','British Columbia',NULL,0),(518,'MB','CA','Manitoba',NULL,0),(519,'NB','CA','New Brunswick',NULL,0),(520,'NL','CA','Newfoundland and Labrador',NULL,0),(521,'NS','CA','Nova Scotia',NULL,0),(522,'NT','CA','Northwest Territories',NULL,0),(523,'NU','CA','Nunavut',NULL,0),(524,'ON','CA','Ontario',NULL,0),(525,'PE','CA','Prince Edward Island',NULL,0),(526,'QC','CA','Quebec',NULL,0),(527,'SK','CA','Saskatchewan',NULL,0),(528,'YT','CA','Yukon Territory',NULL,0),(529,'CC-D','CC','Direction Island',NULL,0),(530,'CC-H','CC','Home Island',NULL,0),(531,'CC-O','CC','Horsburgh Island',NULL,0),(532,'CC-S','CC','South Island',NULL,0),(533,'CC-W','CC','West Island',NULL,0),(534,'CD-BC','CD','Bas-Congo',NULL,0),(535,'CD-BN','CD','Bandundu',NULL,0),(536,'CD-EQ','CD','Equateur',NULL,0),(537,'CD-KA','CD','Katanga',NULL,0),(538,'CD-KE','CD','Kasai-Oriental',NULL,0),(539,'CD-KN','CD','Kinshasa',NULL,0),(540,'CD-KW','CD','Kasai-Occidental',NULL,0),(541,'CD-MA','CD','Maniema',NULL,0),(542,'CD-NK','CD','Nord-Kivu',NULL,0),(543,'CD-OR','CD','Orientale',NULL,0),(544,'CD-SK','CD','Sud-Kivu',NULL,0),(545,'CF-BAN','CF','Bangui',NULL,0),(546,'CF-BBA','CF','Bamingui-Bangoran',NULL,0),(547,'CF-BKO','CF','Basse-Kotto',NULL,0),(548,'CF-HKO','CF','Haute-Kotto',NULL,0),(549,'CF-HMB','CF','Haut-Mbomou',NULL,0),(550,'CF-KEM','CF','Kemo',NULL,0),(551,'CF-LOB','CF','Lobaye',NULL,0),(552,'CF-MBO','CF','Mbomou',NULL,0),(553,'CF-MKD','CF','Mambere-KadeO?                                      C',NULL,0),(554,'CF-NGR','CF','Nana-Grebizi',NULL,0),(555,'CF-NMM','CF','Nana-Mambere',NULL,0),(556,'CF-OMP','CF','Ombella-M\'Poko',NULL,0),(557,'CF-OPE','CF','Ouham-Pende',NULL,0),(558,'CF-OUH','CF','Ouham',NULL,0),(559,'CF-OUK','CF','Ouaka',NULL,0),(560,'CF-SMB','CF','Sangha-Mbaere',NULL,0),(561,'CF-VAK','CF','Vakaga',NULL,0),(562,'CG-BO','CG','Bouenza',NULL,0),(563,'CG-BR','CG','Brazzaville',NULL,0),(564,'CG-CO','CG','Cuvette-Ouest',NULL,0),(565,'CG-CU','CG','Cuvette',NULL,0),(566,'CG-KO','CG','Kouilou',NULL,0),(567,'CG-LE','CG','Lekoumou',NULL,0),(568,'CG-LI','CG','Likouala',NULL,0),(569,'CG-NI','CG','Niari',NULL,0),(570,'CG-PL','CG','Plateaux',NULL,0),(571,'CG-PO','CG','Pool',NULL,0),(572,'CG-SA','CG','Sangha',NULL,0),(573,'CH-AG','CH','Aargau',NULL,0),(574,'CH-AI','CH','Appenzell Innerhoden',NULL,0),(575,'CH-AR','CH','Appenzell Ausserrhoden',NULL,0),(576,'CH-BE','CH','Bern',NULL,0),(577,'CH-BL','CH','Basel-Landschaft',NULL,0),(578,'CH-BS','CH','Basel-Stadt',NULL,0),(579,'CH-FR','CH','Fribourg',NULL,0),(580,'CH-GE','CH','Geneva',NULL,0),(581,'CH-GL','CH','Glarus',NULL,0),(582,'CH-GR','CH','Graubunden',NULL,0),(583,'CH-JU','CH','Jura',NULL,0),(584,'CH-LU','CH','Lucerne',NULL,0),(585,'CH-NE','CH','NeuchO?l                                            S',NULL,0),(586,'CH-NW','CH','Nidwalden',NULL,0),(587,'CH-OW','CH','Obwalden',NULL,0),(588,'CH-SG','CH','St. Gallen',NULL,0),(589,'CH-SH','CH','Schaffhausen',NULL,0),(590,'CH-SO','CH','Solothurn',NULL,0),(591,'CH-SZ','CH','Schwyz',NULL,0),(592,'CH-TG','CH','Thurgau',NULL,0),(593,'CH-TI','CH','Ticino',NULL,0),(594,'CH-UR','CH','Uri',NULL,0),(595,'CH-VD','CH','Vaud',NULL,0),(596,'CH-VS','CH','Valais',NULL,0),(597,'CH-ZG','CH','Zug',NULL,0),(598,'CH-ZH','CH','Zurich',NULL,0),(599,'CI-ABE','CI','Abengourou',NULL,0),(600,'CI-ABI','CI','Abidjan',NULL,0),(601,'CI-ABO','CI','Aboisso',NULL,0),(602,'CI-ADI','CI','Adiake',NULL,0),(603,'CI-ADZ','CI','Adzope',NULL,0),(604,'CI-AGB','CI','Agboville',NULL,0),(605,'CI-AGN','CI','Agnibilekrou',NULL,0),(606,'CI-ALE','CI','Alepe',NULL,0),(607,'CI-BAN','CI','Bangolo',NULL,0),(608,'CI-BDK','CI','Bondoukou',NULL,0),(609,'CI-BDL','CI','Boundiali',NULL,0),(610,'CI-BEO','CI','Beoumi',NULL,0),(611,'CI-BFL','CI','Bouafle',NULL,0),(612,'CI-BGN','CI','Bongouanou',NULL,0),(613,'CI-BIA','CI','Biankouma',NULL,0),(614,'CI-BKE','CI','Bouake',NULL,0),(615,'CI-BNA','CI','Bouna',NULL,0),(616,'CI-BOC','CI','Bocanda',NULL,0),(617,'CI-DAL','CI','Daloa',NULL,0),(618,'CI-DAN','CI','Danane',NULL,0),(619,'CI-DAO','CI','Daoukro',NULL,0),(620,'CI-DBU','CI','Dabou',NULL,0),(621,'CI-DIM','CI','Dimbokro',NULL,0),(622,'CI-DIV','CI','Divo',NULL,0),(623,'CI-DKL','CI','Dabakala',NULL,0),(624,'CI-DUE','CI','Duekoue',NULL,0),(625,'CI-FER','CI','Ferkessedougou',NULL,0),(626,'CI-GAG','CI','Gagnoa',NULL,0),(627,'CI-GBA','CI','Grand-Bassam',NULL,0),(628,'CI-GLA','CI','Grand-Lahou',NULL,0),(629,'CI-GUI','CI','Guiglo',NULL,0),(630,'CI-ISS','CI','Issia',NULL,0),(631,'CI-JAC','CI','Jacqueville',NULL,0),(632,'CI-KAT','CI','Katiola',NULL,0),(633,'CI-KOR','CI','Korhogo',NULL,0),(634,'CI-LAK','CI','Lakota',NULL,0),(635,'CI-MAN','CI','Man',NULL,0),(636,'CI-MBA','CI','Mbahiakro',NULL,0),(637,'CI-MKN','CI','Mankono',NULL,0),(638,'CI-ODI','CI','Odienne',NULL,0),(639,'CI-OUM','CI','Oume',NULL,0),(640,'CI-SAK','CI','Sakassou',NULL,0),(641,'CI-SAS','CI','Sassandra',NULL,0),(642,'CI-SEG','CI','Seguela',NULL,0),(643,'CI-SIN','CI','Sinfra',NULL,0),(644,'CI-SOU','CI','Soubre',NULL,0),(645,'CI-SPE','CI','San-Pedro',NULL,0),(646,'CI-TAB','CI','Tabou',NULL,0),(647,'CI-TAN','CI','Tanda',NULL,0),(648,'CI-TBA','CI','Touba',NULL,0),(649,'CI-TIA','CI','Tiassale',NULL,0),(650,'CI-TIE','CI','Tiebissou',NULL,0),(651,'CI-TIN','CI','Tingrela',NULL,0),(652,'CI-TLP','CI','Toulepleu',NULL,0),(653,'CI-TMD','CI','Toumodi',NULL,0),(654,'CI-VAV','CI','Vavoua',NULL,0),(655,'CI-YAM','CI','Yamoussoukro',NULL,0),(656,'CI-ZUE','CI','Zuenoula',NULL,0),(657,'CK-AI','CK','Aitutaki',NULL,0),(658,'CK-AT','CK','Atiu',NULL,0),(659,'CK-MA','CK','Manuae',NULL,0),(660,'CK-MG','CK','Mangaia',NULL,0),(661,'CK-MK','CK','Manihiki',NULL,0),(662,'CK-MT','CK','Mitiaro',NULL,0),(663,'CK-MU','CK','Mauke',NULL,0),(664,'CK-NI','CK','Nassau Island',NULL,0),(665,'CK-PA','CK','Palmerston',NULL,0),(666,'CK-PE','CK','Penrhyn',NULL,0),(667,'CK-PU','CK','Pukapuka',NULL,0),(668,'CK-RK','CK','Rakahanga',NULL,0),(669,'CK-RR','CK','Rarotonga',NULL,0),(670,'CK-SU','CK','Surwarrow',NULL,0),(671,'CK-TA','CK','Takutea',NULL,0),(672,'CL-AI','CL','Aisen del General Carlos Ibanez del Campo (XI)',NULL,0),(673,'CL-AN','CL','Antofagasta (II)',NULL,0),(674,'CL-AR','CL','Araucania (IX)',NULL,0),(675,'CL-AT','CL','Atacama (III)',NULL,0),(676,'CL-BI','CL','Bio-Bio (VIII)',NULL,0),(677,'CL-CO','CL','Coquimbo (IV)',NULL,0),(678,'CL-LI','CL','Libertador General Bernardo O\'Higgins (VI)',NULL,0),(679,'CL-LL','CL','Los Lagos (X)',NULL,0),(680,'CL-MA','CL','Magallanes (XII)',NULL,0),(681,'CL-ML','CL','Maule (VII)',NULL,0),(682,'CL-RM','CL','Region Metropolitana (RM)',NULL,0),(683,'CL-TA','CL','Tarapaca (I)',NULL,0),(684,'CL-VS','CL','Valparaiso (V)',NULL,0),(685,'CM-ADA','CM','Adamawa Province (Adamaoua)',NULL,0),(686,'CM-CEN','CM','Centre Province',NULL,0),(687,'CM-EST','CM','East Province (Est)',NULL,0),(688,'CM-EXN','CM','Extreme North Province (ExtrO?-Nord)                C',NULL,0),(689,'CM-LIT','CM','Littoral Province',NULL,0),(690,'CM-NOR','CM','North Province (Nord)',NULL,0),(691,'CM-NOT','CM','Northwest Province (Nord-Ouest)',NULL,0),(692,'CM-OUE','CM','West Province (Ouest)',NULL,0),(693,'CM-SOU','CM','Southwest Province (Sud-Ouest).',NULL,0),(694,'CM-SUD','CM','South Province (Sud)',NULL,0),(695,'CN-11','CN','Beijing',NULL,0),(696,'CN-12','CN','Tianjin',NULL,0),(697,'CN-13','CN','Hebei',NULL,0),(698,'CN-14','CN','Shanxi',NULL,0),(699,'CN-15','CN','Nei Mongol',NULL,0),(700,'CN-21','CN','Liaoning',NULL,0),(701,'CN-22','CN','Jilin',NULL,0),(702,'CN-23','CN','Heilongjiang',NULL,0),(703,'CN-31','CN','Shanghai',NULL,0),(704,'CN-32','CN','Jiangsu',NULL,0),(705,'CN-33','CN','Zhejiang',NULL,0),(706,'CN-34','CN','Anhui',NULL,0),(707,'CN-35','CN','Fujian',NULL,0),(708,'CN-36','CN','Jiangxi',NULL,0),(709,'CN-37','CN','Shandong',NULL,0),(710,'CN-41','CN','Henan',NULL,0),(711,'CN-42','CN','Hubei',NULL,0),(712,'CN-43','CN','Hunan',NULL,0),(713,'CN-44','CN','Guangdong',NULL,0),(714,'CN-45','CN','Guangxi',NULL,0),(715,'CN-46','CN','Hainan',NULL,0),(716,'CN-51','CN','Sichuan',NULL,0),(717,'CN-52','CN','Guizhou',NULL,0),(718,'CN-53','CN','Yunnan',NULL,0),(719,'CN-54','CN','Xizang ZO?O? (Tibet)                               CH',NULL,0),(720,'CN-61','CN','Shaanxi',NULL,0),(721,'CN-62','CN','Gansu',NULL,0),(722,'CN-63','CN','Qinghai',NULL,0),(723,'CN-64','CN','Ningxia',NULL,0),(724,'CN-65','CN','Xinjiang',NULL,0),(725,'CN-71','CN','Taiwan',NULL,0),(726,'CN-91','CN','Xianggang',NULL,0),(727,'CN-92','CN','Aomen',NULL,0),(728,'CN-97','CN','ChongqO?                                            C',NULL,0),(729,'CN-98','CN','Gaoxiong',NULL,0),(730,'CN-99','CN','Taibei',NULL,0),(731,'CO-AMZ','CO','Amazonas',NULL,0),(732,'CO-ANT','CO','Antioquia',NULL,0),(733,'CO-ARA','CO','Arauca',NULL,0),(734,'CO-ATL','CO','Atlantico',NULL,0),(735,'CO-BDC','CO','Bogota D.C.',NULL,0),(736,'CO-BOL','CO','Bolivar',NULL,0),(737,'CO-BOY','CO','Boyaca',NULL,0),(738,'CO-CAL','CO','Caldas',NULL,0),(739,'CO-CAM','CO','Cundinamarca',NULL,0),(740,'CO-CAQ','CO','Caqueta',NULL,0),(741,'CO-CAS','CO','Casanare',NULL,0),(742,'CO-CAU','CO','Cauca',NULL,0),(743,'CO-CES','CO','Cesar',NULL,0),(744,'CO-CHO','CO','Choco',NULL,0),(745,'CO-COR','CO','Cordoba',NULL,0),(746,'CO-GJR','CO','Guajira',NULL,0),(747,'CO-GNA','CO','Guainia',NULL,0),(748,'CO-GVR','CO','Guaviare',NULL,0),(749,'CO-HUI','CO','Huila',NULL,0),(750,'CO-MAG','CO','Magdalena',NULL,0),(751,'CO-MET','CO','Meta',NULL,0),(752,'CO-NAR','CO','Narino',NULL,0),(753,'CO-NDS','CO','Norte de Santander',NULL,0),(754,'CO-PUT','CO','Putumayo',NULL,0),(755,'CO-QUI','CO','Quindio',NULL,0),(756,'CO-RIS','CO','Risaralda',NULL,0),(757,'CO-SAN','CO','Santander',NULL,0),(758,'CO-SAP','CO','San Andres y Providencia',NULL,0),(759,'CO-SUC','CO','Sucre',NULL,0),(760,'CO-TOL','CO','Tolima',NULL,0),(761,'CO-VAU','CO','Vaupes',NULL,0),(762,'CO-VDC','CO','Valle del Cauca',NULL,0),(763,'CO-VIC','CO','Vichada',NULL,0),(764,'CR-AL','CR','Alajuela',NULL,0),(765,'CR-CA','CR','Cartago',NULL,0),(766,'CR-GU','CR','Guanacaste',NULL,0),(767,'CR-HE','CR','Heredia',NULL,0),(768,'CR-LI','CR','Limon',NULL,0),(769,'CR-PU','CR','Puntarenas',NULL,0),(770,'CR-SJ','CR','San Jose',NULL,0),(771,'CU-CAM','CU','Camaguey',NULL,0),(772,'CU-CAV','CU','Ciego de Avila',NULL,0),(773,'CU-CFU','CU','Cienfuegos',NULL,0),(774,'CU-CLH','CU','Ciudad de La Habana',NULL,0),(775,'CU-GRA','CU','Granma',NULL,0),(776,'CU-GUA','CU','Guantanamo',NULL,0),(777,'CU-HOL','CU','Holguin',NULL,0),(778,'CU-IJU','CU','Isla de la Juventud',NULL,0),(779,'CU-LHA','CU','La Habana',NULL,0),(780,'CU-LTU','CU','Las Tunas',NULL,0),(781,'CU-MAT','CU','Matanzas',NULL,0),(782,'CU-PRI','CU','Pinar del Rio',NULL,0),(783,'CU-SCU','CU','Santiago de Cuba',NULL,0),(784,'CU-SSP','CU','Sancti Spiritus',NULL,0),(785,'CU-VCL','CU','Villa Clara',NULL,0),(786,'CV-BR','CV','Brava',NULL,0),(787,'CV-BV','CV','Boa Vista',NULL,0),(788,'CV-CA','CV','Santa Catarina',NULL,0),(789,'CV-CR','CV','Santa Cruz',NULL,0),(790,'CV-CS','CV','Calheta de Sao Miguel',NULL,0),(791,'CV-MA','CV','Maio',NULL,0),(792,'CV-MO','CV','Mosteiros',NULL,0),(793,'CV-PA','CV','Paul',NULL,0),(794,'CV-PN','CV','Porto Novo',NULL,0),(795,'CV-PR','CV','Praia',NULL,0),(796,'CV-RG','CV','Ribeira Grande',NULL,0),(797,'CV-SD','CV','Sao Domingos',NULL,0),(798,'CV-SF','CV','Sao Filipe',NULL,0),(799,'CV-SL','CV','Sal',NULL,0),(800,'CV-SN','CV','Sao Nicolau',NULL,0),(801,'CV-SV','CV','Sao Vicente',NULL,0),(802,'CV-TA','CV','Tarrafal',NULL,0),(803,'CY-A','CY','Larnaca',NULL,0),(804,'CY-F','CY','Famagusta',NULL,0),(805,'CY-I','CY','Limassol',NULL,0),(806,'CY-K','CY','Kyrenia',NULL,0),(807,'CY-N','CY','Nicosia',NULL,0),(808,'CY-P','CY','Paphos',NULL,0),(809,'CZ-JC','CZ','South Bohemian Region (Jihocesky kraj)',NULL,0),(810,'CZ-JM','CZ','South Moravian Region (Jihomoravsky kraj)',NULL,0),(811,'CZ-KA','CZ','Carlsbad Region  (Karlovarsky kraj)',NULL,0),(812,'CZ-KR','CZ','Hradec Kralove Region (Kralovehradecky kraj)',NULL,0),(813,'CZ-LI','CZ','Liberec Region (Liberecky kraj)',NULL,0),(814,'CZ-MO','CZ','Moravian-Silesian Region (Moravskoslezsky kraj)',NULL,0),(815,'CZ-OL','CZ','Olomouc Region (Olomoucky kraj)',NULL,0),(816,'CZ-PA','CZ','Pardubice Region (Pardubicky kraj)',NULL,0),(817,'CZ-PL','CZ','Plzen( Region Plzensky kraj)',NULL,0),(818,'CZ-PR','CZ','Prague - the Capital (Praha - hlavni mesto)',NULL,0),(819,'CZ-ST','CZ','Central Bohemian Region (Stredocesky kraj)',NULL,0),(820,'CZ-US','CZ','Usti nad Labem Region (Ustecky kraj)',NULL,0),(821,'CZ-VY','CZ','Vysoc(ina Region (kraj Vysoc(ina)',NULL,0),(822,'CZ-ZL','CZ','Zlin Region (Zlinsky kraj)',NULL,0),(823,'DE-BE','DE','Berlin',NULL,0),(824,'DE-BR','DE','Brandenburg',NULL,0),(825,'DE-BW','DE','Baden-Wurttemberg',NULL,0),(826,'DE-BY','DE','Bayern',NULL,0),(827,'DE-HB','DE','Bremen',NULL,0),(828,'DE-HE','DE','Hessen',NULL,0),(829,'DE-HH','DE','Hamburg',NULL,0),(830,'DE-MV','DE','Mecklenburg-Vorpommern',NULL,0),(831,'DE-NI','DE','Niedersachsen',NULL,0),(832,'DE-NW','DE','Nordrhein-Westfalen',NULL,0),(833,'DE-RP','DE','Rheinland-Pfalz',NULL,0),(834,'DE-SH','DE','Schleswig-Holstein',NULL,0),(835,'DE-SL','DE','Saarland',NULL,0),(836,'DE-SN','DE','Sachsen',NULL,0),(837,'DE-ST','DE','Sachsen-Anhalt',NULL,0),(838,'DE-TH','DE','Thuringen',NULL,0),(839,'DJ-J','DJ','Djibouti',NULL,0),(840,'DJ-K','DJ','Dikhil',NULL,0),(841,'DJ-O','DJ','Obock',NULL,0),(842,'DJ-S','DJ','\'Ali Sabih',NULL,0),(843,'DJ-T','DJ','Tadjoura',NULL,0),(844,'DK-AR','DK','Arhus',NULL,0),(845,'DK-BH','DK','Bornholm',NULL,0),(846,'DK-CC','DK','Copenhagen (municipality)',NULL,0),(847,'DK-CO','DK','Copenhagen',NULL,0),(848,'DK-FC','DK','Frederiksberg (municipality)',NULL,0),(849,'DK-FO','DK','Faroe Islands',NULL,0),(850,'DK-FR','DK','Frederiksborg',NULL,0),(851,'DK-FU','DK','Funen',NULL,0),(852,'DK-GL','DK','Greenland',NULL,0),(853,'DK-NJ','DK','North Jutland',NULL,0),(854,'DK-RB','DK','Ribe',NULL,0),(855,'DK-RK','DK','Ringkjobing',NULL,0),(856,'DK-RO','DK','Roskilde',NULL,0),(857,'DK-SJ','DK','South Jutland',NULL,0),(858,'DK-ST','DK','Storstrom',NULL,0),(859,'DK-VB','DK','Viborg',NULL,0),(860,'DK-VK','DK','Vejle',NULL,0),(861,'DK-WZ','DK','West Zealand',NULL,0),(862,'DM-AND','DM','Saint Andrew Parish',NULL,0),(863,'DM-DAV','DM','Saint David Parish',NULL,0),(864,'DM-GEO','DM','Saint George Parish',NULL,0),(865,'DM-JOH','DM','Saint John Parish',NULL,0),(866,'DM-JOS','DM','Saint Joseph Parish',NULL,0),(867,'DM-LUK','DM','Saint Luke Parish',NULL,0),(868,'DM-MAR','DM','Saint Mark Parish',NULL,0),(869,'DM-PAT','DM','Saint Patrick Parish',NULL,0),(870,'DM-PAU','DM','Saint Paul Parish',NULL,0),(871,'DM-PET','DM','Saint Peter Parish',NULL,0),(872,'DO-AL','DO','La Altagracia',NULL,0),(873,'DO-AZ','DO','Azua',NULL,0),(874,'DO-BC','DO','Baoruco',NULL,0),(875,'DO-BH','DO','Barahona',NULL,0),(876,'DO-DJ','DO','Dajabon',NULL,0),(877,'DO-DN','DO','Distrito Nacional',NULL,0),(878,'DO-DU','DO','Duarte',NULL,0),(879,'DO-EL','DO','Elias Pina',NULL,0),(880,'DO-ET','DO','Espaillat',NULL,0),(881,'DO-HM','DO','Hato Mayor',NULL,0),(882,'DO-IN','DO','Independencia',NULL,0),(883,'DO-JO','DO','San Jose de Ocoa',NULL,0),(884,'DO-MC','DO','Monte Cristi',NULL,0),(885,'DO-MN','DO','Monsenor Nouel',NULL,0),(886,'DO-MP','DO','Monte Plata',NULL,0),(887,'DO-MT','DO','Maria Trinidad Sanchez',NULL,0),(888,'DO-PD','DO','Pedernales',NULL,0),(889,'DO-PM','DO','San Pedro de Macoris',NULL,0),(890,'DO-PP','DO','Puerto Plata',NULL,0),(891,'DO-PR','DO','Peravia (Bani)',NULL,0),(892,'DO-RO','DO','La Romana',NULL,0),(893,'DO-SA','DO','Santiago',NULL,0),(894,'DO-SC','DO','San Cristobal',NULL,0),(895,'DO-SD','DO','Santo Domingo',NULL,0),(896,'DO-SH','DO','Sanchez Ramirez',NULL,0),(897,'DO-SJ','DO','San Juan',NULL,0),(898,'DO-SL','DO','Salcedo',NULL,0),(899,'DO-SM','DO','Samana',NULL,0),(900,'DO-ST','DO','Santiago Rodriguez',NULL,0),(901,'DO-SY','DO','El Seybo',NULL,0),(902,'DO-VA','DO','Valverde',NULL,0),(903,'DO-VE','DO','La Vega',NULL,0),(904,'DZ-ADE','DZ','Ain Defla',NULL,0),(905,'DZ-ADR','DZ','Adrar',NULL,0),(906,'DZ-ALG','DZ','Alger',NULL,0),(907,'DZ-ANN','DZ','Annaba',NULL,0),(908,'DZ-ATE','DZ','Ain Temouchent',NULL,0),(909,'DZ-BAT','DZ','Batna',NULL,0),(910,'DZ-BBA','DZ','Bordj Bou Arreridj',NULL,0),(911,'DZ-BEC','DZ','Bechar',NULL,0),(912,'DZ-BEJ','DZ','Bejaia',NULL,0),(913,'DZ-BIS','DZ','Biskra',NULL,0),(914,'DZ-BLI','DZ','Blida',NULL,0),(915,'DZ-BMD','DZ','Boumerdes',NULL,0),(916,'DZ-BOA','DZ','Bouira',NULL,0),(917,'DZ-CHL','DZ','Chlef',NULL,0),(918,'DZ-CON','DZ','Constantine',NULL,0),(919,'DZ-DJE','DZ','Djelfa',NULL,0),(920,'DZ-EBA','DZ','El Bayadh',NULL,0),(921,'DZ-EOU','DZ','El Oued',NULL,0),(922,'DZ-ETA','DZ','El Tarf',NULL,0),(923,'DZ-GHA','DZ','Ghardaia',NULL,0),(924,'DZ-GUE','DZ','Guelma',NULL,0),(925,'DZ-ILL','DZ','Illizi',NULL,0),(926,'DZ-JIJ','DZ','Jijel',NULL,0),(927,'DZ-KHE','DZ','Khenchela',NULL,0),(928,'DZ-LAG','DZ','Laghouat',NULL,0),(929,'DZ-MED','DZ','Medea',NULL,0),(930,'DZ-MIL','DZ','Mila',NULL,0),(931,'DZ-MOS','DZ','Mostaganem',NULL,0),(932,'DZ-MSI','DZ','M\'Sila',NULL,0),(933,'DZ-MUA','DZ','Muaskar',NULL,0),(934,'DZ-NAA','DZ','Naama',NULL,0),(935,'DZ-OEB','DZ','Oum el-Bouaghi',NULL,0),(936,'DZ-ORA','DZ','Oran',NULL,0),(937,'DZ-OUA','DZ','Ouargla',NULL,0),(938,'DZ-REL','DZ','Relizane',NULL,0),(939,'DZ-SAH','DZ','Souk Ahras',NULL,0),(940,'DZ-SAI','DZ','Saida',NULL,0),(941,'DZ-SBA','DZ','Sidi Bel Abbes',NULL,0),(942,'DZ-SET','DZ','Setif',NULL,0),(943,'DZ-SKI','DZ','Skikda',NULL,0),(944,'DZ-TAM','DZ','Tamanghasset',NULL,0),(945,'DZ-TEB','DZ','Tebessa',NULL,0),(946,'DZ-TIA','DZ','Tiaret',NULL,0),(947,'DZ-TIN','DZ','Tindouf',NULL,0),(948,'DZ-TIP','DZ','Tipaza',NULL,0),(949,'DZ-TIS','DZ','Tissemsilt',NULL,0),(950,'DZ-TLE','DZ','Tlemcen',NULL,0),(951,'DZ-TOU','DZ','Tizi Ouzou',NULL,0),(952,'EC-A','EC','Azuay',NULL,0),(953,'EC-B','EC','Bolivar',NULL,0),(954,'EC-C','EC','Carchi',NULL,0),(955,'EC-D','EC','Orellana',NULL,0),(956,'EC-E','EC','Esmeraldas',NULL,0),(957,'EC-F','EC','Canar',NULL,0),(958,'EC-G','EC','Guayas',NULL,0),(959,'EC-H','EC','Chimborazo',NULL,0),(960,'EC-I','EC','Imbabura',NULL,0),(961,'EC-L','EC','Loja',NULL,0),(962,'EC-M','EC','Manabi',NULL,0),(963,'EC-N','EC','Napo',NULL,0),(964,'EC-O','EC','El Oro',NULL,0),(965,'EC-P','EC','Pichincha',NULL,0),(966,'EC-R','EC','Los Rios',NULL,0),(967,'EC-S','EC','Morona-Santiago',NULL,0),(968,'EC-T','EC','Tungurahua',NULL,0),(969,'EC-U','EC','Sucumbios',NULL,0),(970,'EC-W','EC','Galapagos',NULL,0),(971,'EC-X','EC','Cotopaxi',NULL,0),(972,'EC-Y','EC','Pastaza',NULL,0),(973,'EC-Z','EC','Zamora-Chinchipe',NULL,0),(974,'EE-37','EE','Harju County',NULL,0),(975,'EE-39','EE','Hiiu County',NULL,0),(976,'EE-44','EE','Ida-Viru County',NULL,0),(977,'EE-49','EE','JOAa County',NULL,0),(978,'EE-51','EE','JArva County',NULL,0),(979,'EE-57','EE','LAAne County',NULL,0),(980,'EE-59','EE','LAAne-Viru County',NULL,0),(981,'EE-65','EE','POA County',NULL,0),(982,'EE-67','EE','PArnu County',NULL,0),(983,'EE-70','EE','Rapla County',NULL,0),(984,'EE-74','EE','Saare County',NULL,0),(985,'EE-78','EE','Tartu County',NULL,0),(986,'EE-82','EE','Valga County',NULL,0),(987,'EE-84','EE','Viljandi County',NULL,0),(988,'EE-86','EE','VOACounty',NULL,0),(989,'EG-ASW','EG','Aswan',NULL,0),(990,'EG-ASY','EG','Asyut',NULL,0),(991,'EG-BAM','EG','Al Bahr al Ahmar',NULL,0),(992,'EG-BHY','EG','Al Buhayrah',NULL,0),(993,'EG-BSD','EG','Bur Sa\'id',NULL,0),(994,'EG-BSW','EG','Bani Suwayf',NULL,0),(995,'EG-DHY','EG','Ad Daqahliyah',NULL,0),(996,'EG-DMY','EG','Dumyat',NULL,0),(997,'EG-FYM','EG','Al Fayyum',NULL,0),(998,'EG-GBY','EG','Al Gharbiyah',NULL,0),(999,'EG-IDR','EG','Al Iskandariyah',NULL,0),(1000,'EG-IML','EG','Al Isma\'iliyah',NULL,0),(1001,'EG-JNS','EG','Janub Sina\'',NULL,0),(1002,'EG-JZH','EG','Al Jizah',NULL,0),(1003,'EG-KSH','EG','Kafr ash Shaykh',NULL,0),(1004,'EG-MAT','EG','Matruh',NULL,0),(1005,'EG-MFY','EG','Al Minufiyah',NULL,0),(1006,'EG-MNY','EG','Al Minya',NULL,0),(1007,'EG-QHR','EG','Al Qahirah',NULL,0),(1008,'EG-QIN','EG','Qina',NULL,0),(1009,'EG-QLY','EG','Al Qalyubiyah',NULL,0),(1010,'EG-SHQ','EG','Ash Sharqiyah',NULL,0),(1011,'EG-SHS','EG','Shamal Sina\'',NULL,0),(1012,'EG-SUH','EG','Suhaj',NULL,0),(1013,'EG-SWY','EG','As Suways',NULL,0),(1014,'EG-WJD','EG','Al Wadi al Jadid',NULL,0),(1015,'ER-BR','ER','Gash-Barka (Barentu)',NULL,0),(1016,'ER-DE','ER','Southern (Debub)',NULL,0),(1017,'ER-DK','ER','Southern Red Sea (Debub-Keih-Bahri)',NULL,0),(1018,'ER-KE','ER','Anseba (Keren)',NULL,0),(1019,'ER-MA','ER','Central (Maekel)',NULL,0),(1020,'ER-SK','ER','Northern Red Sea (Semien-Keih-Bahri)',NULL,0),(1021,'ES-AB','ES','Albacete',NULL,0),(1022,'ES-AC','ES','Alicante',NULL,0),(1023,'ES-AL','ES','Alava',NULL,0),(1024,'ES-AM','ES','Almeria',NULL,0),(1025,'ES-AS','ES','Asturias',NULL,0),(1026,'ES-AV','ES','Avila',NULL,0),(1027,'ES-BA','ES','Barcelona',NULL,0),(1028,'ES-BJ','ES','Badajoz',NULL,0),(1029,'ES-BU','ES','Burgos',NULL,0),(1030,'ES-CA','ES','A Coruna',NULL,0),(1031,'ES-CC','ES','Caceres',NULL,0),(1032,'ES-CD','ES','Cordoba',NULL,0),(1033,'ES-CL','ES','Castellon',NULL,0),(1034,'ES-CR','ES','Ciudad Real',NULL,0),(1035,'ES-CT','ES','Cantabria',NULL,0),(1036,'ES-CU','ES','Cuenca',NULL,0),(1037,'ES-CZ','ES','Cadiz',NULL,0),(1038,'ES-GD','ES','Granada',NULL,0),(1039,'ES-GI','ES','Girona',NULL,0),(1040,'ES-GJ','ES','Guadalajara',NULL,0),(1041,'ES-GP','ES','Guipuzcoa',NULL,0),(1042,'ES-HL','ES','Huelva',NULL,0),(1043,'ES-HS','ES','Huesca',NULL,0),(1044,'ES-IB','ES','Illes Balears',NULL,0),(1045,'ES-JN','ES','Jaen',NULL,0),(1046,'ES-LE','ES','Leon',NULL,0),(1047,'ES-LG','ES','Lugo',NULL,0),(1048,'ES-LL','ES','Lleida',NULL,0),(1049,'ES-MD','ES','Madrid',NULL,0),(1050,'ES-ML','ES','Malaga',NULL,0),(1051,'ES-MU','ES','Mucria',NULL,0),(1052,'ES-NV','ES','Navarra',NULL,0),(1053,'ES-OU','ES','Ourense',NULL,0),(1054,'ES-PL','ES','Palencia',NULL,0),(1055,'ES-PM','ES','Las Palmas',NULL,0),(1056,'ES-PO','ES','Pontevedra',NULL,0),(1057,'ES-RJ','ES','La Rioja',NULL,0),(1058,'ES-SC','ES','Santa Cruz de Tererife',NULL,0),(1059,'ES-SG','ES','Segovia',NULL,0),(1060,'ES-SL','ES','Salamanca',NULL,0),(1061,'ES-SO','ES','Soria',NULL,0),(1062,'ES-SV','ES','Sevilla',NULL,0),(1063,'ES-TA','ES','Tarragona',NULL,0),(1064,'ES-TE','ES','Teruel',NULL,0),(1065,'ES-TO','ES','Toledo',NULL,0),(1066,'ES-VC','ES','Valencia',NULL,0),(1067,'ES-VD','ES','Valladolid',NULL,0),(1068,'ES-VZ','ES','Vizcaya',NULL,0),(1069,'ES-ZM','ES','Zamora',NULL,0),(1070,'ES-ZR','ES','Zaragoza',NULL,0),(1071,'ET-AA','ET','Addis Ababa',NULL,0),(1072,'ET-AF','ET','Afar',NULL,0),(1073,'ET-AH','ET','Amhara',NULL,0),(1074,'ET-BG','ET','Benishangul-Gumaz',NULL,0),(1075,'ET-DD','ET','Dire Dawa',NULL,0),(1076,'ET-GB','ET','Gambela',NULL,0),(1077,'ET-HR','ET','Hariai',NULL,0),(1078,'ET-OR','ET','Oromia',NULL,0),(1079,'ET-SM','ET','Somali',NULL,0),(1080,'ET-SN','ET','Southern Nations - Nationalities and Peoples Region',NULL,0),(1081,'ET-TG','ET','Tigray',NULL,0),(1082,'FI-AH','FI','Ahvenanmaan laani',NULL,0),(1083,'FI-ES','FI','Etela-Suomen laani',NULL,0),(1084,'FI-IS','FI','Ita-Suomen laani',NULL,0),(1085,'FI-LL','FI','Lapin laani',NULL,0),(1086,'FI-LS','FI','Lansi-Suomen laani',NULL,0),(1087,'FI-OU','FI','Oulun laani',NULL,0),(1088,'FJ-C','FJ','Central Division',NULL,0),(1089,'FJ-E','FJ','Eastern Division',NULL,0),(1090,'FJ-N','FJ','Northern Division',NULL,0),(1091,'FJ-R','FJ','Rotuma',NULL,0),(1092,'FJ-W','FJ','Western Division',NULL,0),(1093,'FM-C','FM','Chuuk',NULL,0),(1094,'FM-K','FM','Kosrae',NULL,0),(1095,'FM-P','FM','Pohnpei',NULL,0),(1096,'FM-Y','FM','Yap',NULL,0),(1097,'FR-V01','FR','Ain',NULL,0),(1098,'FR-S02','FR','Aisne',NULL,0),(1099,'FR-C03','FR','Allier',NULL,0),(1100,'FR-U04','FR','Alpes-de-Haute-Provence',NULL,0),(1101,'FR-U05','FR','Hautes-Alpes',NULL,0),(1102,'FR-U06','FR','Alpes-Maritimes',NULL,0),(1103,'FR-V07','FR','Ardèche',NULL,0),(1104,'FR-G08','FR','Ardennes',NULL,0),(1105,'FR-N09','FR','Ariège',NULL,0),(1106,'FR-G10','FR','Aube',NULL,0),(1107,'FR-K11','FR','Aude',NULL,0),(1108,'FR-N12','FR','Aveyron',NULL,0),(1109,'FR-U13','FR','Bouches-du-Rhône',NULL,0),(1110,'FR-P14','FR','Calvados',NULL,0),(1111,'FR-C15','FR','Cantal',NULL,0),(1112,'FR-T16','FR','Charente',NULL,0),(1113,'FR-T17','FR','Charente-Maritime',NULL,0),(1114,'FR-F18','FR','Cher',NULL,0),(1115,'FR-L19','FR','Corrèze',NULL,0),(1116,'FR-H2A','FR','Corse-du-Sud',NULL,0),(1117,'FR-H2B','FR','Haute-Corse',NULL,0),(1118,'FR-D21','FR','Côte-d\'Or',NULL,0),(1119,'FR-E22','FR','Côtes-d\'Armor',NULL,0),(1120,'FR-L23','FR','Creuse',NULL,0),(1121,'FR-B24','FR','Dordogne',NULL,0),(1122,'FR-I25','FR','Doubs',NULL,0),(1123,'FR-V26','FR','Drôme',NULL,0),(1124,'FR-Q27','FR','Eure',NULL,0),(1125,'FR-F28','FR','Eure-et-Loir',NULL,0),(1126,'FR-E29','FR','Finistère',NULL,0),(1127,'FR-K30','FR','Gard',NULL,0),(1128,'FR-N31','FR','Haute-Garonne',NULL,0),(1129,'FR-N32','FR','Gers',NULL,0),(1130,'FR-B33','FR','Gironde',NULL,0),(1131,'FR-K34','FR','Hérault',NULL,0),(1132,'FR-E35','FR','Ille-et-Vilaine',NULL,0),(1133,'FR-F36','FR','Indre',NULL,0),(1134,'FR-F37','FR','Indre-et-Loire',NULL,0),(1135,'FR-V38','FR','Isère',NULL,0),(1136,'FR-I39','FR','Jura',NULL,0),(1137,'FR-B40','FR','Landes',NULL,0),(1138,'FR-F41','FR','Loir-et-Cher',NULL,0),(1139,'FR-V42','FR','Loire',NULL,0),(1140,'FR-C43','FR','Haute-Loire',NULL,0),(1141,'FR-R44','FR','Loire-Atlantique',NULL,0),(1142,'FR-F45','FR','Loiret',NULL,0),(1143,'FR-N46','FR','Lot',NULL,0),(1144,'FR-B47','FR','Lot-et-Garonne',NULL,0),(1145,'FR-K48','FR','Lozère',NULL,0),(1146,'FR-R49','FR','Maine-et-Loire',NULL,0),(1147,'FR-P50','FR','Manche',NULL,0),(1148,'FR-G51','FR','Marne',NULL,0),(1149,'FR-G52','FR','Haute-Marne',NULL,0),(1150,'FR-R53','FR','Mayenne',NULL,0),(1151,'FR-M54','FR','Meurthe-et-Moselle',NULL,0),(1152,'FR-M55','FR','Meuse',NULL,0),(1153,'FR-E56','FR','Morbihan',NULL,0),(1154,'FR-M57','FR','Moselle',NULL,0),(1155,'FR-D58','FR','Nièvre',NULL,0),(1156,'FR-O59','FR','Nord',NULL,0),(1157,'FR-S60','FR','Oise',NULL,0),(1158,'FR-P61','FR','Orne',NULL,0),(1159,'FR-O62','FR','Pas-de-Calais',NULL,0),(1160,'FR-C63','FR','Puy-de-Dôme',NULL,0),(1161,'FR-B64','FR','Pyrénées-Atlantiques',NULL,0),(1162,'FR-N65','FR','Hautes-Pyrénées',NULL,0),(1163,'FR-K66','FR','Pyrénées-Orientales',NULL,0),(1164,'FR-A67','FR','Bas-Rhin',NULL,0),(1165,'FR-A68','FR','Haut-Rhin',NULL,0),(1166,'FR-V69','FR','Rhône',NULL,0),(1167,'FR-I70','FR','Haute-Saône',NULL,0),(1168,'FR-D71','FR','Saône-et-Loire',NULL,0),(1169,'FR-R72','FR','Sarthe',NULL,0),(1170,'FR-V73','FR','Savoie',NULL,0),(1171,'FR-V74','FR','Haute-Savoie',NULL,0),(1172,'FR-J75','FR','Paris',NULL,0),(1173,'FR-Q76','FR','Seine-Maritime',NULL,0),(1174,'FR-J77','FR','Seine-et-Marne',NULL,0),(1175,'FR-J78','FR','Yvelines',NULL,0),(1176,'FR-T79','FR','Deux-Sèvres',NULL,0),(1177,'FR-S80','FR','Somme',NULL,0),(1178,'FR-N81','FR','Tarn',NULL,0),(1179,'FR-N82','FR','Tarn-et-Garonne',NULL,0),(1180,'FR-U83','FR','Var',NULL,0),(1181,'FR-U84','FR','Vaucluse',NULL,0),(1182,'FR-R85','FR','Vendée',NULL,0),(1183,'FR-T86','FR','Vienne',NULL,0),(1184,'FR-L87','FR','Haute-Vienne',NULL,0),(1185,'FR-M88','FR','Vosges',NULL,0),(1186,'FR-D89','FR','Yonne',NULL,0),(1187,'FR-I90','FR','Territoire de Belfort',NULL,0),(1188,'FR-J91','FR','Essonne',NULL,0),(1189,'FR-J92','FR','Hauts-de-Seine',NULL,0),(1190,'FR-J93','FR','Seine-Saint-Denis',NULL,0),(1191,'FR-J94','FR','Val-de-Marne',NULL,0),(1192,'FR-J95','FR','Val-d\'Oise',NULL,0),(1193,'GA-ES','GA','Estuaire',NULL,0),(1194,'GA-HO','GA','Haut-Ogooue',NULL,0),(1195,'GA-MO','GA','Moyen-Ogooue',NULL,0),(1196,'GA-NG','GA','Ngounie',NULL,0),(1197,'GA-NY','GA','Nyanga',NULL,0),(1198,'GA-OI','GA','Ogooue-Ivindo',NULL,0),(1199,'GA-OL','GA','Ogooue-Lolo',NULL,0),(1200,'GA-OM','GA','Ogooue-Maritime',NULL,0),(1201,'GA-WN','GA','Woleu-Ntem',NULL,0),(1202,'GB-ABD','GB','Aberdeenshire',NULL,0),(1203,'GB-ABE','GB','Aberdeen',NULL,0),(1204,'GB-AGB','GB','Argyll and Bute',NULL,0),(1205,'GB-AGY','GB','Anglesey',NULL,0),(1206,'GB-ANS','GB','Angus',NULL,0),(1207,'GB-ANT','GB','County Antrim',NULL,0),(1208,'GB-ARD','GB','Ards',NULL,0),(1209,'GB-ARM','GB','County Armagh',NULL,0),(1210,'GB-AVN','GB','Avon',NULL,0),(1211,'GB-AYR','GB','Ayrshire',NULL,0),(1212,'GB-BAS','GB','Bath and North East Somerset',NULL,0),(1213,'GB-BBD','GB','Blackburn with Darwen',NULL,0),(1214,'GB-BDF','GB','Bedfordshire',NULL,0),(1215,'GB-BRK','GB','Berkshire',NULL,0),(1216,'GB-BDG','GB','Barking and Dagenham',NULL,0),(1217,'GB-BEN','GB','Brent',NULL,0),(1218,'GB-BEX','GB','Bexley',NULL,0),(1219,'GB-BFS','GB','Belfast',NULL,0),(1220,'GB-BGE','GB','Bridgend',NULL,0),(1221,'GB-BGW','GB','Blaenau Gwent',NULL,0),(1222,'GB-BIR','GB','Birmingham',NULL,0),(1223,'GB-BKM','GB','Buckinghamshire',NULL,0),(1224,'GB-BLA','GB','Ballymena',NULL,0),(1225,'GB-BLY','GB','Ballymoney',NULL,0),(1226,'GB-BMH','GB','Bournemouth',NULL,0),(1227,'GB-BNB','GB','Banbridge',NULL,0),(1228,'GB-BNE','GB','Barnet',NULL,0),(1229,'GB-BNH','GB','Brighton and Hove',NULL,0),(1230,'GB-BNS','GB','Barnsley',NULL,0),(1231,'GB-BOL','GB','Bolton',NULL,0),(1232,'GB-BPL','GB','Blackpool',NULL,0),(1233,'GB-BRC','GB','Bracknell Forest',NULL,0),(1234,'GB-BRD','GB','Bradford',NULL,0),(1235,'GB-BRY','GB','Bromley',NULL,0),(1236,'GB-BST','GB','City of Bristol',NULL,0),(1237,'GB-BUR','GB','Bury',NULL,0),(1238,'GB-CAI','GB','Caithness',NULL,0),(1239,'GB-CAM','GB','Cambridgeshire',NULL,0),(1240,'GB-CAY','GB','Caerphilly',NULL,0),(1241,'GB-CGN','GB','Ceredigion',NULL,0),(1242,'GB-CGV','GB','Craigavon',NULL,0),(1243,'GB-CHS','GB','Cheshire',NULL,0),(1244,'GB-CKF','GB','Carrickfergus',NULL,0),(1245,'GB-CKT','GB','Cookstown',NULL,0),(1246,'GB-CLD','GB','Calderdale',NULL,0),(1247,'GB-CLK','GB','Clackmannanshire',NULL,0),(1248,'GB-CWD','GB','Clwyd',NULL,0),(1249,'GB-CLR','GB','Coleraine',NULL,0),(1250,'GB-CMA','GB','Cumbria',NULL,0),(1251,'GB-CMD','GB','Camden',NULL,0),(1252,'GB-CMN','GB','Carmarthenshire',NULL,0),(1253,'GB-CON','GB','Cornwall',NULL,0),(1254,'GB-COV','GB','Coventry (West Midlands district)',NULL,0),(1255,'GB-CRF','GB','Cardiff',NULL,0),(1256,'GB-CRY','GB','Croydon',NULL,0),(1257,'GB-CSR','GB','Castlereagh',NULL,0),(1258,'GB-CWY','GB','Conwy',NULL,0),(1259,'GB-DAL','GB','Darlington',NULL,0),(1260,'GB-DBY','GB','Derbyshire',NULL,0),(1261,'GB-DEN','GB','Denbighshire',NULL,0),(1262,'GB-DER','GB','Derby',NULL,0),(1263,'GB-DEV','GB','Devon',NULL,0),(1264,'GB-DGN','GB','Dungannon and South Tyrone',NULL,0),(1265,'GB-DGY','GB','Dumfries and Galloway',NULL,0),(1266,'GB-DNC','GB','Doncaster',NULL,0),(1267,'GB-DND','GB','Dundee',NULL,0),(1268,'GB-DOR','GB','Dorset',NULL,0),(1269,'GB-DOW','GB','County Down',NULL,0),(1270,'GB-DRY','GB','Derry',NULL,0),(1271,'GB-DUD','GB','Dudley (West Midlands district)',NULL,0),(1272,'GB-DUR','GB','County Durham',NULL,0),(1273,'GB-EAL','GB','Ealing',NULL,0),(1274,'GB-EAY','GB','East Ayrshire',NULL,0),(1275,'GB-EDH','GB','City of Edinburgh',NULL,0),(1276,'GB-EDU','GB','East Dunbartonshire',NULL,0),(1277,'GB-ELN','GB','East Lothian',NULL,0),(1278,'GB-ELS','GB','Eilean Siar',NULL,0),(1279,'GB-ENF','GB','Enfield',NULL,0),(1280,'GB-ERW','GB','East Renfrewshire',NULL,0),(1281,'GB-ERY','GB','East Riding of Yorkshire',NULL,0),(1282,'GB-ESS','GB','Essex',NULL,0),(1283,'GB-ESX','GB','East Sussex',NULL,0),(1284,'GB-FAL','GB','Falkirk',NULL,0),(1285,'GB-FER','GB','Fermanagh',NULL,0),(1286,'GB-FIF','GB','Fife',NULL,0),(1287,'GB-FLN','GB','Flintshire',NULL,0),(1288,'GB-GLG','GB','Glasgow City',NULL,0),(1289,'GB-GLS','GB','Gloucestershire',NULL,0),(1290,'GB-GNT','GB','Gwent',NULL,0),(1291,'GB-GRE','GB','Greenwich',NULL,0),(1292,'GB-GSY','GB','Guernsey',NULL,0),(1293,'GB-GWN','GB','Gwynedd',NULL,0),(1294,'GB-HAL','GB','Halton',NULL,0),(1295,'GB-HAM','GB','Hampshire',NULL,0),(1296,'GB-HAV','GB','Havering',NULL,0),(1297,'GB-HCK','GB','Hackney',NULL,0),(1298,'GB-HEF','GB','Herefordshire',NULL,0),(1299,'GB-HIL','GB','Hillingdon',NULL,0),(1300,'GB-HLD','GB','Scottish Highlands',NULL,0),(1301,'GB-HMF','GB','Hammersmith and Fulham',NULL,0),(1302,'GB-HNS','GB','Hounslow',NULL,0),(1303,'GB-HPL','GB','Hartlepool',NULL,0),(1304,'GB-HRT','GB','Hertfordshire',NULL,0),(1305,'GB-HRW','GB','Harrow',NULL,0),(1306,'GB-HRY','GB','Haringey',NULL,0),(1307,'GB-IOS','GB','Isles of Scilly',NULL,0),(1308,'GB-IOW','GB','Isle of Wight',NULL,0),(1309,'GB-ISL','GB','Islington',NULL,0),(1310,'GB-IVC','GB','Inverclyde',NULL,0),(1311,'GB-JSY','GB','Jersey',NULL,0),(1312,'GB-KEC','GB','Kensington and Chelsea',NULL,0),(1313,'GB-KEN','GB','Kent',NULL,0),(1314,'GB-KCD','GB','Kincardineshire',NULL,0),(1315,'GB-KHL','GB','Kingston upon Hull City of',NULL,0),(1316,'GB-KIR','GB','Kirklees',NULL,0),(1317,'GB-KTT','GB','Kingston upon Thames',NULL,0),(1318,'GB-KWL','GB','Knowsley',NULL,0),(1319,'GB-LAN','GB','Lancashire',NULL,0),(1320,'GB-LBH','GB','Lambeth',NULL,0),(1321,'GB-LCE','GB','Leicester',NULL,0),(1322,'GB-LDS','GB','Leeds',NULL,0),(1323,'GB-LEC','GB','Leicestershire',NULL,0),(1324,'GB-LEW','GB','Lewisham',NULL,0),(1325,'GB-LIN','GB','Lincolnshire',NULL,0),(1326,'GB-LIV','GB','Liverpool',NULL,0),(1327,'GB-LMV','GB','Limavady',NULL,0),(1328,'GB-LND','GB','Greater London',NULL,0),(1329,'GB-LRN','GB','Larne',NULL,0),(1330,'GB-LSB','GB','Lisburn',NULL,0),(1331,'GB-LUT','GB','Luton',NULL,0),(1332,'GB-MAN','GB','Greater Manchester',NULL,0),(1333,'GB-MDB','GB','Middlesbrough',NULL,0),(1334,'GB-MDW','GB','Medway',NULL,0),(1335,'GB-MFT','GB','Magherafelt',NULL,0),(1336,'GB-MIK','GB','Milton Keynes',NULL,0),(1337,'GB-MLN','GB','Midlothian',NULL,0),(1338,'GB-MON','GB','Monmouthshire',NULL,0),(1339,'GB-MSY','GB','Merseyside',NULL,0),(1340,'GB-MRT','GB','Merton',NULL,0),(1341,'GB-MGM','GB','Mid Glamorgan',NULL,0),(1342,'GB-MDX','GB','Middlesex',NULL,0),(1343,'GB-MRY','GB','Moray',NULL,0),(1344,'GB-MTY','GB','Merthyr Tydfil',NULL,0),(1345,'GB-MYL','GB','Moyle',NULL,0),(1346,'GB-NAY','GB','North Ayrshire',NULL,0),(1347,'GB-NBL','GB','Northumberland',NULL,0),(1348,'GB-NDN','GB','North Down',NULL,0),(1349,'GB-NEL','GB','North East Lincolnshire',NULL,0),(1350,'GB-NET','GB','Newcastle upon Tyne',NULL,0),(1351,'GB-NFK','GB','Norfolk',NULL,0),(1352,'GB-NGM','GB','Nottingham',NULL,0),(1353,'GB-NLK','GB','North Lanarkshire',NULL,0),(1354,'GB-NLN','GB','North Lincolnshire',NULL,0),(1355,'GB-NSM','GB','North Somerset',NULL,0),(1356,'GB-NTA','GB','Newtownabbey',NULL,0),(1357,'GB-NTH','GB','Northamptonshire',NULL,0),(1358,'GB-NTL','GB','Neath Port Talbot',NULL,0),(1359,'GB-NTT','GB','Nottinghamshire',NULL,0),(1360,'GB-NTY','GB','North Tyneside',NULL,0),(1361,'GB-NWM','GB','Newham',NULL,0),(1362,'GB-NWP','GB','Newport',NULL,0),(1363,'GB-NYK','GB','North Yorkshire',NULL,0),(1364,'GB-NYM','GB','Newry and Mourne',NULL,0),(1365,'GB-OLD','GB','Oldham',NULL,0),(1366,'GB-OMH','GB','Omagh',NULL,0),(1367,'GB-ORK','GB','Orkney Islands',NULL,0),(1368,'GB-OXF','GB','Oxfordshire',NULL,0),(1369,'GB-PEM','GB','Pembrokeshire',NULL,0),(1370,'GB-PKN','GB','Perth and Kinross',NULL,0),(1371,'GB-PLY','GB','Plymouth',NULL,0),(1372,'GB-POL','GB','Poole',NULL,0),(1373,'GB-POR','GB','Portsmouth',NULL,0),(1374,'GB-POW','GB','Powys',NULL,0),(1375,'GB-PTE','GB','Peterborough',NULL,0),(1376,'GB-RCC','GB','Redcar and Cleveland',NULL,0),(1377,'GB-RCH','GB','Rochdale',NULL,0),(1378,'GB-RCT','GB','Rhondda Cynon Taf',NULL,0),(1379,'GB-RDB','GB','Redbridge',NULL,0),(1380,'GB-RDG','GB','Reading',NULL,0),(1381,'GB-RFW','GB','Renfrewshire',NULL,0),(1382,'GB-RIC','GB','Richmond upon Thames',NULL,0),(1383,'GB-ROT','GB','Rotherham',NULL,0),(1384,'GB-RUT','GB','Rutland',NULL,0),(1385,'GB-SAW','GB','Sandwell',NULL,0),(1386,'GB-SAY','GB','South Ayrshire',NULL,0),(1387,'GB-SCB','GB','Scottish Borders',NULL,0),(1388,'GB-SFK','GB','Suffolk',NULL,0),(1389,'GB-SFT','GB','Sefton',NULL,0),(1390,'GB-SGC','GB','South Gloucestershire',NULL,0),(1391,'GB-SHF','GB','Sheffield',NULL,0),(1392,'GB-SHN','GB','St Helens',NULL,0),(1393,'GB-SHR','GB','Shropshire',NULL,0),(1394,'GB-SKP','GB','Stockport',NULL,0),(1395,'GB-SLF','GB','Salford',NULL,0),(1396,'GB-SLG','GB','Slough',NULL,0),(1397,'GB-SLK','GB','South Lanarkshire',NULL,0),(1398,'GB-SGM','GB','South Glamorgan',NULL,0),(1399,'GB-SYK','GB','South Yorkshire',NULL,0),(1400,'GB-SND','GB','Sunderland',NULL,0),(1401,'GB-SOL','GB','Solihull',NULL,0),(1402,'GB-SOM','GB','Somerset',NULL,0),(1403,'GB-SOS','GB','Southend-on-Sea',NULL,0),(1404,'GB-SRY','GB','Surrey',NULL,0),(1405,'GB-STB','GB','Strabane',NULL,0),(1406,'GB-STE','GB','Stoke-on-Trent',NULL,0),(1407,'GB-STG','GB','Stirling',NULL,0),(1408,'GB-STH','GB','Southampton',NULL,0),(1409,'GB-STN','GB','Sutton',NULL,0),(1410,'GB-STS','GB','Staffordshire',NULL,0),(1411,'GB-STT','GB','Stockton-on-Tees',NULL,0),(1412,'GB-STY','GB','South Tyneside',NULL,0),(1413,'GB-SWA','GB','Swansea',NULL,0),(1414,'GB-SWD','GB','Swindon',NULL,0),(1415,'GB-SWK','GB','Southwark',NULL,0),(1416,'GB-TAM','GB','Tameside',NULL,0),(1417,'GB-TFW','GB','Telford and Wrekin',NULL,0),(1418,'GB-THR','GB','Thurrock',NULL,0),(1419,'GB-TOB','GB','Torbay',NULL,0),(1420,'GB-TOF','GB','Torfaen',NULL,0),(1421,'GB-TRF','GB','Trafford',NULL,0),(1422,'GB-TWH','GB','Tower Hamlets',NULL,0),(1423,'GB-TWR','GB','Tyne and Wear',NULL,0),(1424,'GB-VGL','GB','Vale of Glamorgan',NULL,0),(1425,'GB-WAR','GB','Warwickshire',NULL,0),(1426,'GB-WBK','GB','West Berkshire',NULL,0),(1427,'GB-WDU','GB','West Dunbartonshire',NULL,0),(1428,'GB-WFT','GB','Waltham Forest',NULL,0),(1429,'GB-WGN','GB','Wigan',NULL,0),(1430,'GB-WIL','GB','Wiltshire',NULL,0),(1431,'GB-WKF','GB','Wakefield',NULL,0),(1432,'GB-WLL','GB','Walsall',NULL,0),(1433,'GB-WLN','GB','West Lothian',NULL,0),(1434,'GB-WGM','GB','West Glamorgan',NULL,0),(1435,'GB-WMD','GB','West Midlands',NULL,0),(1436,'GB-WYK','GB','West Yorkshire',NULL,0),(1437,'GB-WLV','GB','Wolverhampton',NULL,0),(1438,'GB-WND','GB','Wandsworth',NULL,0),(1439,'GB-WNM','GB','Windsor and Maidenhead',NULL,0),(1440,'GB-WOK','GB','Wokingham',NULL,0),(1441,'GB-WOR','GB','Worcestershire',NULL,0),(1442,'GB-WRL','GB','Wirral',NULL,0),(1443,'GB-WRT','GB','Warrington',NULL,0),(1444,'GB-WRX','GB','Wrexham',NULL,0),(1445,'GB-WSM','GB','Westminster',NULL,0),(1446,'GB-WSX','GB','West Sussex',NULL,0),(1447,'GB-YOR','GB','York',NULL,0),(1448,'GB-ZET','GB','Shetland Islands',NULL,0),(1449,'GD-A','GD','Saint Andrew',NULL,0),(1450,'GD-C','GD','Carriacou',NULL,0),(1451,'GD-D','GD','Saint David',NULL,0),(1452,'GD-G','GD','Saint George',NULL,0),(1453,'GD-J','GD','Saint John',NULL,0),(1454,'GD-M','GD','Saint Mark',NULL,0),(1455,'GD-P','GD','Saint Patrick',NULL,0),(1456,'GD-Q','GD','Petit Martinique',NULL,0),(1457,'GE-AB','GE','Abkhazia',NULL,0),(1458,'GE-AJ','GE','Ajaria',NULL,0),(1459,'GE-GU','GE','Guria',NULL,0),(1460,'GE-IM','GE','Imereti',NULL,0),(1461,'GE-KA','GE','Kakheti',NULL,0),(1462,'GE-KK','GE','Kvemo Kartli',NULL,0),(1463,'GE-MM','GE','Mtskheta-Mtianeti',NULL,0),(1464,'GE-RL','GE','Racha Lechkhumi and Kvemo Svaneti',NULL,0),(1465,'GE-SJ','GE','Samtskhe-Javakheti',NULL,0),(1466,'GE-SK','GE','Shida Kartli',NULL,0),(1467,'GE-SZ','GE','Samegrelo-Zemo Svaneti',NULL,0),(1468,'GE-TB','GE','Tbilisi',NULL,0),(1469,'GH-AS','GH','Ashanti Region',NULL,0),(1470,'GH-BA','GH','Brong-Ahafo Region',NULL,0),(1471,'GH-CE','GH','Central Region',NULL,0),(1472,'GH-EA','GH','Eastern Region',NULL,0),(1473,'GH-GA','GH','Greater Accra Region',NULL,0),(1474,'GH-NO','GH','Northern Region',NULL,0),(1475,'GH-UE','GH','Upper East Region',NULL,0),(1476,'GH-UW','GH','Upper West Region',NULL,0),(1477,'GH-VO','GH','Volta Region',NULL,0),(1478,'GH-WE','GH','Western Region',NULL,0),(1479,'GL-A','GL','Avannaa',NULL,0),(1480,'GL-K','GL','Kitaa',NULL,0),(1481,'GL-T','GL','Tunu',NULL,0),(1482,'GM-BJ','GM','Banjul',NULL,0),(1483,'GM-BR','GM','Brikama',NULL,0),(1484,'GM-BS','GM','Basse',NULL,0),(1485,'GM-CR','GM','Central River',NULL,0),(1486,'GM-JA','GM','Janjangbure',NULL,0),(1487,'GM-KA','GM','Kanifeng',NULL,0),(1488,'GM-KE','GM','Kerewan',NULL,0),(1489,'GM-KU','GM','Kuntaur',NULL,0),(1490,'GM-LR','GM','Lower River',NULL,0),(1491,'GM-MA','GM','Mansakonko',NULL,0),(1492,'GM-NB','GM','North Bank',NULL,0),(1493,'GM-UR','GM','Upper River',NULL,0),(1494,'GM-WE','GM','Western',NULL,0),(1495,'GN-BFA','GN','Boffa',NULL,0),(1496,'GN-BOK','GN','Boke',NULL,0),(1497,'GN-BYL','GN','Beyla',NULL,0),(1498,'GN-CNK','GN','Conakry',NULL,0),(1499,'GN-COY','GN','Coyah',NULL,0),(1500,'GN-DBL','GN','Dabola',NULL,0),(1501,'GN-DBR','GN','Dubreka',NULL,0),(1502,'GN-DGR','GN','Dinguiraye',NULL,0),(1503,'GN-DLB','GN','Dalaba',NULL,0),(1504,'GN-FRC','GN','Forecariah',NULL,0),(1505,'GN-FRI','GN','Fria',NULL,0),(1506,'GN-FRN','GN','Faranah',NULL,0),(1507,'GN-GAO','GN','Gaoual',NULL,0),(1508,'GN-GCD','GN','Gueckedou',NULL,0),(1509,'GN-KBA','GN','Koubia',NULL,0),(1510,'GN-KDA','GN','Koundara',NULL,0),(1511,'GN-KND','GN','Kindia',NULL,0),(1512,'GN-KNK','GN','Kankan',NULL,0),(1513,'GN-KRA','GN','Kouroussa',NULL,0),(1514,'GN-KRN','GN','Kerouane',NULL,0),(1515,'GN-KSD','GN','Kissidougou',NULL,0),(1516,'GN-LAB','GN','Labe',NULL,0),(1517,'GN-LLM','GN','Lelouma',NULL,0),(1518,'GN-LOL','GN','Lola',NULL,0),(1519,'GN-MAL','GN','Mali',NULL,0),(1520,'GN-MAM','GN','Mamou',NULL,0),(1521,'GN-MAN','GN','Mandiana',NULL,0),(1522,'GN-MCT','GN','Macenta',NULL,0),(1523,'GN-NZR','GN','Nzerekore',NULL,0),(1524,'GN-PIT','GN','Pita',NULL,0),(1525,'GN-SIG','GN','Siguiri',NULL,0),(1526,'GN-TLM','GN','Telimele',NULL,0),(1527,'GN-TOG','GN','Tougue',NULL,0),(1528,'GN-YOM','GN','Yomou',NULL,0),(1529,'GQ-AN','GQ','Provincia Annobon',NULL,0),(1530,'GQ-BN','GQ','Provincia Bioko Norte',NULL,0),(1531,'GQ-BS','GQ','Provincia Bioko Sur',NULL,0),(1532,'GQ-CS','GQ','Provincia Centro Sur',NULL,0),(1533,'GQ-KN','GQ','Provincia Kie-Ntem',NULL,0),(1534,'GQ-LI','GQ','Provincia Litoral',NULL,0),(1535,'GQ-WN','GQ','Provincia Wele-Nzas',NULL,0),(1536,'GR-AT','GR','Attica',NULL,0),(1537,'GR-CM','GR','Central Macedonia',NULL,0),(1538,'GR-CN','GR','Central Greece',NULL,0),(1539,'GR-CR','GR','Crete',NULL,0),(1540,'GR-EM','GR','East Macedonia and Thrace',NULL,0),(1541,'GR-EP','GR','Epirus',NULL,0),(1542,'GR-II','GR','Ionian Islands',NULL,0),(1543,'GR-NA','GR','North Aegean',NULL,0),(1544,'GR-PP','GR','Peloponnesos',NULL,0),(1545,'GR-SA','GR','South Aegean',NULL,0),(1546,'GR-TH','GR','Thessaly',NULL,0),(1547,'GR-WG','GR','West Greece',NULL,0),(1548,'GR-WM','GR','West Macedonia',NULL,0),(1549,'GT-AV','GT','Alta Verapaz',NULL,0),(1550,'GT-BV','GT','Baja Verapaz',NULL,0),(1551,'GT-CM','GT','Chimaltenango',NULL,0),(1552,'GT-CQ','GT','Chiquimula',NULL,0),(1553,'GT-ES','GT','Escuintla',NULL,0),(1554,'GT-GU','GT','Guatemala',NULL,0),(1555,'GT-HU','GT','Huehuetenango',NULL,0),(1556,'GT-IZ','GT','Izabal',NULL,0),(1557,'GT-JA','GT','Jalapa',NULL,0),(1558,'GT-JU','GT','Jutiapa',NULL,0),(1559,'GT-PE','GT','El Peten',NULL,0),(1560,'GT-PR','GT','El Progreso',NULL,0),(1561,'GT-QC','GT','El Quiche',NULL,0),(1562,'GT-QZ','GT','Quetzaltenango',NULL,0),(1563,'GT-RE','GT','Retalhuleu',NULL,0),(1564,'GT-SM','GT','San Marcos',NULL,0),(1565,'GT-SO','GT','Solola',NULL,0),(1566,'GT-SR','GT','Santa Rosa',NULL,0),(1567,'GT-ST','GT','Sacatepequez',NULL,0),(1568,'GT-SU','GT','Suchitepequez',NULL,0),(1569,'GT-TO','GT','Totonicapan',NULL,0),(1570,'GT-ZA','GT','Zacapa',NULL,0),(1571,'GW-BB','GW','Biombo Region',NULL,0),(1572,'GW-BF','GW','Bafata Region',NULL,0),(1573,'GW-BL','GW','Bolama Region',NULL,0),(1574,'GW-BS','GW','Bissau Region',NULL,0),(1575,'GW-CA','GW','Cacheu Region',NULL,0),(1576,'GW-GA','GW','Gabu Region',NULL,0),(1577,'GW-OI','GW','Oio Region',NULL,0),(1578,'GW-QU','GW','Quinara Region',NULL,0),(1579,'GW-TO','GW','Tombali Region',NULL,0),(1580,'GY-BW','GY','Barima-Waini',NULL,0),(1581,'GY-CM','GY','Cuyuni-Mazaruni',NULL,0),(1582,'GY-DM','GY','Demerara-Mahaica',NULL,0),(1583,'GY-EC','GY','East Berbice-Corentyne',NULL,0),(1584,'GY-EW','GY','Essequibo Islands-West Demerara',NULL,0),(1585,'GY-MB','GY','Mahaica-Berbice',NULL,0),(1586,'GY-PI','GY','Potaro-Siparuni',NULL,0),(1587,'GY-PM','GY','Pomeroon-Supenaam',NULL,0),(1588,'GY-UD','GY','Upper Demerara-Berbice',NULL,0),(1589,'GY-UT','GY','Upper Takutu-Upper Essequibo',NULL,0),(1590,'HK-HCW','HK','Central and Western Hong Kong Island',NULL,0),(1591,'HK-HEA','HK','Eastern Hong Kong Island',NULL,0),(1592,'HK-HSO','HK','Southern Hong Kong Island',NULL,0),(1593,'HK-HWC','HK','Wan Chai Hong Kong Island',NULL,0),(1594,'HK-KKC','HK','Kowloon City Kowloon',NULL,0),(1595,'HK-KKT','HK','Kwun Tong Kowloon',NULL,0),(1596,'HK-KSS','HK','Sham Shui Po Kowloon',NULL,0),(1597,'HK-KWT','HK','Wong Tai Sin Kowloon',NULL,0),(1598,'HK-KYT','HK','Yau Tsim Mong Kowloon',NULL,0),(1599,'HK-NIS','HK','Islands New Territories',NULL,0),(1600,'HK-NKT','HK','Kwai Tsing New Territories',NULL,0),(1601,'HK-NNO','HK','North New Territories',NULL,0),(1602,'HK-NSK','HK','Sai Kung New Territories',NULL,0),(1603,'HK-NST','HK','Sha Tin New Territories',NULL,0),(1604,'HK-NTM','HK','Tuen Mun New Territories',NULL,0),(1605,'HK-NTP','HK','Tai Po New Territories',NULL,0),(1606,'HK-NTW','HK','Tsuen Wan New Territories',NULL,0),(1607,'HK-NYL','HK','Yuen Long New Territories',NULL,0),(1608,'HM-F','HM','Flat Island',NULL,0),(1609,'HM-H','HM','Heard Island',NULL,0),(1610,'HM-M','HM','McDonald Island',NULL,0),(1611,'HM-S','HM','Shag Island',NULL,0),(1612,'HN-AT','HN','Atlantida',NULL,0),(1613,'HN-CH','HN','Choluteca',NULL,0),(1614,'HN-CL','HN','Colon',NULL,0),(1615,'HN-CM','HN','Comayagua',NULL,0),(1616,'HN-CP','HN','Copan',NULL,0),(1617,'HN-CR','HN','Cortes',NULL,0),(1618,'HN-FM','HN','Francisco Morazan',NULL,0),(1619,'HN-GD','HN','Gracias a Dios',NULL,0),(1620,'HN-IB','HN','Islas de la Bahia (Bay Islands)',NULL,0),(1621,'HN-IN','HN','Intibuca',NULL,0),(1622,'HN-LE','HN','Lempira',NULL,0),(1623,'HN-OC','HN','Ocotepeque',NULL,0),(1624,'HN-OL','HN','Olancho',NULL,0),(1625,'HN-PA','HN','El Paraiso',NULL,0),(1626,'HN-PZ','HN','La Paz',NULL,0),(1627,'HN-SB','HN','Santa Barbara',NULL,0),(1628,'HN-VA','HN','Valle',NULL,0),(1629,'HN-YO','HN','Yoro',NULL,0),(1630,'HR-01','HR','Zagreb county',NULL,0),(1631,'HR-02','HR','Krapina-Zagorje county',NULL,0),(1632,'HR-03','HR','Sisak-Moslavina county',NULL,0),(1633,'HR-04','HR','Karlovac county',NULL,0),(1634,'HR-05','HR','Varazdin county',NULL,0),(1635,'HR-06','HR','Koprivnica-Krizevci county',NULL,0),(1636,'HR-07','HR','Bjelovar-Bilogora county',NULL,0),(1637,'HR-08','HR','Primorje-Gorski Kotar county',NULL,0),(1638,'HR-09','HR','Lika-Senj county',NULL,0),(1639,'HR-10','HR','Virovitica-Podravina county',NULL,0),(1640,'HR-11','HR','Pozega-Slavonia county',NULL,0),(1641,'HR-12','HR','Brod-Posavina county',NULL,0),(1642,'HR-13','HR','Zadar county',NULL,0),(1643,'HR-14','HR','Osijek-Baranja county',NULL,0),(1644,'HR-15','HR','Sibenik-Knin county',NULL,0),(1645,'HR-16','HR','Vukovar-Srijem county',NULL,0),(1646,'HR-17','HR','Split-Dalmatia county',NULL,0),(1647,'HR-18','HR','Istria county',NULL,0),(1648,'HR-19','HR','Dubrovnik-Neretva county',NULL,0),(1649,'HR-20','HR','Medjimurje county',NULL,0),(1650,'HR-21','HR','Zagreb (city)',NULL,0),(1651,'HT-AR','HT','Artibonite',NULL,0),(1652,'HT-CE','HT','Centre',NULL,0),(1653,'HT-GA','HT','Grand\'Anse',NULL,0),(1654,'HT-ND','HT','Nord',NULL,0),(1655,'HT-NE','HT','Nord-Est',NULL,0),(1656,'HT-NO','HT','Nord-Ouest',NULL,0),(1657,'HT-OU','HT','Ouest',NULL,0),(1658,'HT-SD','HT','Sud',NULL,0),(1659,'HT-SE','HT','Sud-Est',NULL,0),(1660,'HU-BA','HU','Borsod-Abauj-Zemplen',NULL,0),(1661,'HU-BC','HU','Bekescsaba',NULL,0),(1662,'HU-BK','HU','Bacs-Kiskun',NULL,0),(1663,'HU-BR','HU','Baranya',NULL,0),(1664,'HU-BS','HU','Bekes',NULL,0),(1665,'HU-BU','HU','Budapest',NULL,0),(1666,'HU-CG','HU','Csongrad',NULL,0),(1667,'HU-DB','HU','Debrecen',NULL,0),(1668,'HU-DJ','HU','Dunaujvaros',NULL,0),(1669,'HU-EG','HU','Eger',NULL,0),(1670,'HU-FJ','HU','Fejer',NULL,0),(1671,'HU-GM','HU','Gyor-Moson-Sopron',NULL,0),(1672,'HU-GY','HU','Gyor',NULL,0),(1673,'HU-HB','HU','Hajdu-Bihar',NULL,0),(1674,'HU-HM','HU','Hodmezovasarhely',NULL,0),(1675,'HU-HV','HU','Heves',NULL,0),(1676,'HU-JN','HU','Jasz-Nagykun-Szolnok',NULL,0),(1677,'HU-KC','HU','Kecskemet',NULL,0),(1678,'HU-KE','HU','Komarom-Esztergom',NULL,0),(1679,'HU-KP','HU','Kaposvar',NULL,0),(1680,'HU-MK','HU','Miskolc',NULL,0),(1681,'HU-NG','HU','Nograd',NULL,0),(1682,'HU-NK','HU','Nagykanizsa',NULL,0),(1683,'HU-NY','HU','Nyiregyhaza',NULL,0),(1684,'HU-PC','HU','Pecs',NULL,0),(1685,'HU-PE','HU','Pest',NULL,0),(1686,'HU-SB','HU','Szombathely',NULL,0),(1687,'HU-SG','HU','Szeged',NULL,0),(1688,'HU-SK','HU','Szekesfehervar',NULL,0),(1689,'HU-SL','HU','Szolnok',NULL,0),(1690,'HU-SM','HU','Somogy',NULL,0),(1691,'HU-SO','HU','Sopron',NULL,0),(1692,'HU-SS','HU','Szabolcs-Szatmar-Bereg',NULL,0),(1693,'HU-TB','HU','Tatabanya',NULL,0),(1694,'HU-TO','HU','Tolna',NULL,0),(1695,'HU-VA','HU','Vas',NULL,0),(1696,'HU-VZ','HU','Veszprem',NULL,0),(1697,'HU-ZA','HU','Zala',NULL,0),(1698,'HU-ZG','HU','Zalaegerszeg',NULL,0),(1699,'ID-AC','ID','Aceh',NULL,0),(1700,'ID-BA','ID','Bali',NULL,0),(1701,'ID-BB','ID','Bangka-Belitung',NULL,0),(1702,'ID-BE','ID','Bengkulu',NULL,0),(1703,'ID-BT','ID','Banten',NULL,0),(1704,'ID-GO','ID','Gorontalo',NULL,0),(1705,'ID-IJ','ID','Papua',NULL,0),(1706,'ID-JA','ID','Jambi',NULL,0),(1707,'ID-JI','ID','Jawa Timur',NULL,0),(1708,'ID-JK','ID','Jakarta Raya',NULL,0),(1709,'ID-JR','ID','Jawa Barat',NULL,0),(1710,'ID-JT','ID','Jawa Tengah',NULL,0),(1711,'ID-KB','ID','Kalimantan Barat',NULL,0),(1712,'ID-KI','ID','Kalimantan Timur',NULL,0),(1713,'ID-KS','ID','Kalimantan Selatan',NULL,0),(1714,'ID-KT','ID','Kalimantan Tengah',NULL,0),(1715,'ID-LA','ID','Lampung',NULL,0),(1716,'ID-MA','ID','Maluku',NULL,0),(1717,'ID-MU','ID','Maluku Utara',NULL,0),(1718,'ID-NB','ID','Nusa Tenggara Barat',NULL,0),(1719,'ID-NT','ID','Nusa Tenggara Timur',NULL,0),(1720,'ID-RI','ID','Riau',NULL,0),(1721,'ID-SB','ID','Sumatera Barat',NULL,0),(1722,'ID-SG','ID','Sulawesi Tenggara',NULL,0),(1723,'ID-SL','ID','Sumatera Selatan',NULL,0),(1724,'ID-SN','ID','Sulawesi Selatan',NULL,0),(1725,'ID-ST','ID','Sulawesi Tengah',NULL,0),(1726,'ID-SU','ID','Sumatera Utara',NULL,0),(1727,'ID-SW','ID','Sulawesi Utara',NULL,0),(1728,'ID-YO','ID','Yogyakarta',NULL,0),(1729,'IE-CK','IE','Cork',NULL,0),(1730,'IE-CL','IE','Clare',NULL,0),(1731,'IE-CV','IE','Cavan',NULL,0),(1732,'IE-CW','IE','Carlow',NULL,0),(1733,'IE-DB','IE','Dublin',NULL,0),(1734,'IE-DG','IE','Donegal',NULL,0),(1735,'IE-GW','IE','Galway',NULL,0),(1736,'IE-KD','IE','Kildare',NULL,0),(1737,'IE-KK','IE','Kilkenny',NULL,0),(1738,'IE-KR','IE','Kerry',NULL,0),(1739,'IE-LA','IE','Laois',NULL,0),(1740,'IE-LF','IE','Longford',NULL,0),(1741,'IE-LM','IE','Limerick',NULL,0),(1742,'IE-LR','IE','Leitrim',NULL,0),(1743,'IE-LT','IE','Louth',NULL,0),(1744,'IE-MG','IE','Monaghan',NULL,0),(1745,'IE-MT','IE','Meath',NULL,0),(1746,'IE-MY','IE','Mayo',NULL,0),(1747,'IE-OF','IE','Offaly',NULL,0),(1748,'IE-RC','IE','Roscommon',NULL,0),(1749,'IE-SL','IE','Sligo',NULL,0),(1750,'IE-TP','IE','Tipperary',NULL,0),(1751,'IE-WF','IE','Waterford',NULL,0),(1752,'IE-WK','IE','Wicklow',NULL,0),(1753,'IE-WM','IE','Westmeath',NULL,0),(1754,'IE-WX','IE','Wexford',NULL,0),(1755,'IL-C','IL','Central',NULL,0),(1756,'IL-H','IL','Haifa',NULL,0),(1757,'IL-J','IL','Jerusalem',NULL,0),(1758,'IL-N','IL','Northern',NULL,0),(1759,'IL-S','IL','Southern',NULL,0),(1760,'IL-T','IL','Tel Aviv',NULL,0),(1761,'IN-AN','IN','Andaman and Nicobar Islands',NULL,0),(1762,'IN-AP','IN','Andhra Pradesh',NULL,0),(1763,'IN-AR','IN','Arunachal Pradesh',NULL,0),(1764,'IN-AS','IN','Assam',NULL,0),(1765,'IN-BR','IN','Bihar',NULL,0),(1766,'IN-CH','IN','Chandigarh',NULL,0),(1767,'IN-CT','IN','Chhattisgarh',NULL,0),(1768,'IN-DD','IN','Daman and Diu',NULL,0),(1769,'IN-DL','IN','Delhi',NULL,0),(1770,'IN-DN','IN','Dadra and Nagar Haveli',NULL,0),(1771,'IN-GA','IN','Goa',NULL,0),(1772,'IN-GJ','IN','Gujarat',NULL,0),(1773,'IN-HP','IN','Himachal Pradesh',NULL,0),(1774,'IN-HR','IN','Haryana',NULL,0),(1775,'IN-JH','IN','Jharkhand',NULL,0),(1776,'IN-JK','IN','Jammu and Kashmir',NULL,0),(1777,'IN-KA','IN','Karnataka',NULL,0),(1778,'IN-KL','IN','Kerala',NULL,0),(1779,'IN-LD','IN','Lakshadweep',NULL,0),(1780,'IN-ML','IN','Meghalaya',NULL,0),(1781,'IN-MM','IN','Maharashtra',NULL,0),(1782,'IN-MN','IN','Manipur',NULL,0),(1783,'IN-MP','IN','Madhya Pradesh',NULL,0),(1784,'IN-MZ','IN','Mizoram',NULL,0),(1785,'IN-NL','IN','Nagaland',NULL,0),(1786,'IN-OR','IN','Orissa',NULL,0),(1787,'IN-PB','IN','Punjab',NULL,0),(1788,'IN-PY','IN','Pondicherry',NULL,0),(1789,'IN-RJ','IN','Rajasthan',NULL,0),(1790,'IN-SK','IN','Sikkim',NULL,0),(1791,'IN-TN','IN','Tamil Nadu',NULL,0),(1792,'IN-TR','IN','Tripura',NULL,0),(1793,'IN-UL','IN','Uttaranchal',NULL,0),(1794,'IN-UP','IN','Uttar Pradesh',NULL,0),(1795,'IN-WB','IN','West Bengal',NULL,0),(1796,'IO-DG','IO','Diego Garcia',NULL,0),(1797,'IO-DI','IO','Danger Island',NULL,0),(1798,'IO-EA','IO','Eagle Islands',NULL,0),(1799,'IO-EG','IO','Egmont Islands',NULL,0),(1800,'IO-NI','IO','Nelsons Island',NULL,0),(1801,'IO-PB','IO','Peros Banhos',NULL,0),(1802,'IO-SI','IO','Salomon Islands',NULL,0),(1803,'IO-TB','IO','Three Brothers',NULL,0),(1804,'IQ-AB','IQ','Al Anbar',NULL,0),(1805,'IQ-AL','IQ','Arbil',NULL,0),(1806,'IQ-BA','IQ','Al Basrah',NULL,0),(1807,'IQ-BB','IQ','Babil',NULL,0),(1808,'IQ-BD','IQ','Baghdad',NULL,0),(1809,'IQ-DH','IQ','Dahuk',NULL,0),(1810,'IQ-DQ','IQ','Dhi Qar',NULL,0),(1811,'IQ-DY','IQ','Diyala',NULL,0),(1812,'IQ-KB','IQ','Al Karbala',NULL,0),(1813,'IQ-MU','IQ','Al Muthanna',NULL,0),(1814,'IQ-MY','IQ','Maysan',NULL,0),(1815,'IQ-NJ','IQ','An Najaf',NULL,0),(1816,'IQ-NN','IQ','Ninawa',NULL,0),(1817,'IQ-QA','IQ','Al Qadisyah',NULL,0),(1818,'IQ-SD','IQ','Salah ad Din',NULL,0),(1819,'IQ-SL','IQ','As Sulaymaniyah',NULL,0),(1820,'IQ-TM','IQ','At Ta\'mim',NULL,0),(1821,'IQ-WS','IQ','Wasit',NULL,0),(1822,'IR-ARD','IR','Ardabil',NULL,0),(1823,'IR-BSH','IR','Bushehr',NULL,0),(1824,'IR-CMB','IR','Chahar Mahaal and Bakhtiari',NULL,0),(1825,'IR-EAZ','IR','East Azarbaijan',NULL,0),(1826,'IR-EFH','IR','Esfahan',NULL,0),(1827,'IR-FAR','IR','Fars',NULL,0),(1828,'IR-GIL','IR','Gilan',NULL,0),(1829,'IR-GLS','IR','Golestan',NULL,0),(1830,'IR-HMD','IR','Hamadan',NULL,0),(1831,'IR-HRM','IR','Hormozgan',NULL,0),(1832,'IR-ILM','IR','Ilam',NULL,0),(1833,'IR-KBA','IR','Kohkiluyeh and Buyer Ahmad',NULL,0),(1834,'IR-KRB','IR','Kerman',NULL,0),(1835,'IR-KRD','IR','Kurdistan',NULL,0),(1836,'IR-KRM','IR','Kermanshah',NULL,0),(1837,'IR-KZT','IR','Khuzestan',NULL,0),(1838,'IR-LRS','IR','Lorestan',NULL,0),(1839,'IR-MKZ','IR','Markazi',NULL,0),(1840,'IR-MZD','IR','Mazandaran',NULL,0),(1841,'IR-NKH','IR','North Khorasan',NULL,0),(1842,'IR-QAZ','IR','Qazvin',NULL,0),(1843,'IR-QOM','IR','Qom',NULL,0),(1844,'IR-RKH','IR','Razavi Khorasan',NULL,0),(1845,'IR-SBL','IR','Sistan and Baluchistan',NULL,0),(1846,'IR-SKH','IR','South Khorasan',NULL,0),(1847,'IR-SMN','IR','Semnan',NULL,0),(1848,'IR-TEH','IR','Tehran',NULL,0),(1849,'IR-WEZ','IR','West Azarbaijan',NULL,0),(1850,'IR-YZD','IR','Yazd',NULL,0),(1851,'IR-ZAN','IR','Zanjan',NULL,0),(1852,'IS-AL','IS','Austurland',NULL,0),(1853,'IS-HF','IS','Hofuoborgarsvaeoi',NULL,0),(1854,'IS-NE','IS','Norourland eystra',NULL,0),(1855,'IS-NV','IS','Norourland vestra',NULL,0),(1856,'IS-SL','IS','Suourland',NULL,0),(1857,'IS-SN','IS','Suournes',NULL,0),(1858,'IS-VF','IS','Vestfiroir',NULL,0),(1859,'IS-VL','IS','Vesturland',NULL,0),(1860,'IT-AG','IT','Agrigento',NULL,0),(1861,'IT-AL','IT','Alessandria',NULL,0),(1862,'IT-AN','IT','Ancona',NULL,0),(1863,'IT-AO','IT','Aosta',NULL,0),(1864,'IT-AR','IT','Arezzo',NULL,0),(1865,'IT-AP','IT','Ascoli Piceno',NULL,0),(1866,'IT-AT','IT','Asti',NULL,0),(1867,'IT-AV','IT','Avellino',NULL,0),(1868,'IT-BA','IT','Bari',NULL,0),(1869,'IT-BT','IT','Barletta-Andria-Trani',NULL,0),(1870,'IT-BL','IT','Belluno',NULL,0),(1871,'IT-BN','IT','Benevento',NULL,0),(1872,'IT-BG','IT','Bergamo',NULL,0),(1873,'IT-BI','IT','Biella',NULL,0),(1874,'IT-BO','IT','Bologna',NULL,0),(1875,'IT-BZ','IT','Bolzano',NULL,0),(1876,'IT-BS','IT','Brescia',NULL,0),(1877,'IT-BR','IT','Brindisi',NULL,0),(1878,'IT-CA','IT','Cagliari',NULL,0),(1879,'IT-CL','IT','Caltanissetta',NULL,0),(1880,'IT-CB','IT','Campobasso',NULL,0),(1881,'IT-CI','IT','Carbonia-Iglesias',NULL,0),(1882,'IT-CE','IT','Caserta',NULL,0),(1883,'IT-CT','IT','Catania',NULL,0),(1884,'IT-CZ','IT','Catanzaro',NULL,0),(1885,'IT-CH','IT','Chieti',NULL,0),(1886,'IT-CO','IT','Como',NULL,0),(1887,'IT-CS','IT','Cosenza',NULL,0),(1888,'IT-CR','IT','Cremona',NULL,0),(1889,'IT-KR','IT','Crotone',NULL,0),(1890,'IT-CN','IT','Cuneo',NULL,0),(1891,'IT-EN','IT','Enna',NULL,0),(1892,'IT-FM','IT','Fermo',NULL,0),(1893,'IT-FE','IT','Ferrara',NULL,0),(1894,'IT-FI','IT','Firenze',NULL,0),(1895,'IT-FG','IT','Foggia',NULL,0),(1896,'IT-FC','IT','Forlì-Cesena',NULL,0),(1897,'IT-FR','IT','Frosinone',NULL,0),(1898,'IT-GE','IT','Genova',NULL,0),(1899,'IT-GO','IT','Gorizia',NULL,0),(1900,'IT-GR','IT','Grosseto',NULL,0),(1901,'IT-IM','IT','Imperia',NULL,0),(1902,'IT-IS','IT','Isernia',NULL,0),(1903,'IT-SP','IT','La Spezia',NULL,0),(1904,'IT-AQ','IT','L\'Aquila',NULL,0),(1905,'IT-LT','IT','Latina',NULL,0),(1906,'IT-LE','IT','Lecce',NULL,0),(1907,'IT-LC','IT','Lecco',NULL,0),(1908,'IT-LI','IT','Livorno',NULL,0),(1909,'IT-LO','IT','Lodi',NULL,0),(1910,'IT-LU','IT','Lucca',NULL,0),(1911,'IT-MC','IT','Macerata',NULL,0),(1912,'IT-MN','IT','Mantova',NULL,0),(1913,'IT-MS','IT','Massa-Carrara',NULL,0),(1914,'IT-MT','IT','Matera',NULL,0),(1915,'IT-ME','IT','Messina',NULL,0),(1916,'IT-MI','IT','Milano',NULL,0),(1917,'IT-MO','IT','Modena',NULL,0),(1918,'IT-MB','IT','Monza e della Brianza',NULL,0),(1919,'IT-NA','IT','Napoli',NULL,0),(1920,'IT-NO','IT','Novara',NULL,0),(1921,'IT-NU','IT','Nuoro',NULL,0),(1922,'IT-OT','IT','Olbia-Tempio',NULL,0),(1923,'IT-OR','IT','Oristano',NULL,0),(1924,'IT-PD','IT','Padova',NULL,0),(1925,'IT-PA','IT','Palermo',NULL,0),(1926,'IT-PR','IT','Parma',NULL,0),(1927,'IT-PV','IT','Pavia',NULL,0),(1928,'IT-PG','IT','Perugia',NULL,0),(1929,'IT-PU','IT','Pesaro e Urbino',NULL,0),(1930,'IT-PE','IT','Pescara',NULL,0),(1931,'IT-PC','IT','Piacenza',NULL,0),(1932,'IT-PI','IT','Pisa',NULL,0),(1933,'IT-PT','IT','Pistoia',NULL,0),(1934,'IT-PN','IT','Pordenone',NULL,0),(1935,'IT-PZ','IT','Potenza',NULL,0),(1936,'IT-PO','IT','Prato',NULL,0),(1937,'IT-RG','IT','Ragusa',NULL,0),(1938,'IT-RA','IT','Ravenna',NULL,0),(1939,'IT-RC','IT','Reggio Calabria',NULL,0),(1940,'IT-RE','IT','Reggio Emilia',NULL,0),(1941,'IT-RI','IT','Rieti',NULL,0),(1942,'IT-RN','IT','Rimini',NULL,0),(1943,'IT-RM','IT','Roma',NULL,0),(1944,'IT-RO','IT','Rovigo',NULL,0),(1945,'IT-SA','IT','Salerno',NULL,0),(1946,'IT-VS','IT','Medio Campidano',NULL,0),(1947,'IT-SS','IT','Sassari',NULL,0),(1948,'IT-SV','IT','Savona',NULL,0),(1949,'IT-SI','IT','Siena',NULL,0),(1950,'IT-SR','IT','Siracusa',NULL,0),(1951,'IT-SO','IT','Sondrio',NULL,0),(1952,'IT-TA','IT','Taranto',NULL,0),(1953,'IT-TE','IT','Teramo',NULL,0),(1954,'IT-TR','IT','Terni',NULL,0),(1955,'IT-TO','IT','Torino',NULL,0),(1956,'IT-OG','IT','Ogliastra',NULL,0),(1957,'IT-TP','IT','Trapani',NULL,0),(1958,'IT-TN','IT','Trento',NULL,0),(1959,'IT-TV','IT','Treviso',NULL,0),(1960,'IT-TS','IT','Trieste',NULL,0),(1961,'IT-UD','IT','Udine',NULL,0),(1962,'IT-VA','IT','Varese',NULL,0),(1963,'IT-VE','IT','Venezia',NULL,0),(1964,'IT-VB','IT','Verbano-Cusio-Ossola',NULL,0),(1965,'IT-VC','IT','Vercelli',NULL,0),(1966,'IT-VR','IT','Verona',NULL,0),(1967,'IT-VV','IT','Vibo Valentia',NULL,0),(1968,'IT-VI','IT','Vicenza',NULL,0),(1969,'IT-VT','IT','Viterbo',NULL,0),(1970,'JM-AND','JM','Saint Andrew Parish',NULL,0),(1971,'JM-ANN','JM','Saint Ann Parish',NULL,0),(1972,'JM-CAT','JM','Saint Catherine Parish',NULL,0),(1973,'JM-CLA','JM','Clarendon Parish',NULL,0),(1974,'JM-ELI','JM','Saint Elizabeth Parish',NULL,0),(1975,'JM-HAN','JM','Hanover Parish',NULL,0),(1976,'JM-JAM','JM','Saint James Parish',NULL,0),(1977,'JM-KIN','JM','Kingston Parish',NULL,0),(1978,'JM-MAN','JM','Manchester Parish',NULL,0),(1979,'JM-MAR','JM','Saint Mary Parish',NULL,0),(1980,'JM-POR','JM','Portland Parish',NULL,0),(1981,'JM-THO','JM','Saint Thomas Parish',NULL,0),(1982,'JM-TRL','JM','Trelawny Parish',NULL,0),(1983,'JM-WML','JM','Westmoreland Parish',NULL,0),(1984,'JO-AJ','JO','Ajlun',NULL,0),(1985,'JO-AM','JO','\'Amman',NULL,0),(1986,'JO-AQ','JO','Al \'Aqabah',NULL,0),(1987,'JO-BA','JO','Al Balqa\'',NULL,0),(1988,'JO-IR','JO','Irbid',NULL,0),(1989,'JO-JA','JO','Jarash',NULL,0),(1990,'JO-KA','JO','Al Karak',NULL,0),(1991,'JO-MD','JO','Madaba',NULL,0),(1992,'JO-MF','JO','Al Mafraq',NULL,0),(1993,'JO-MN','JO','Ma\'an',NULL,0),(1994,'JO-TA','JO','At Tafilah',NULL,0),(1995,'JO-ZA','JO','Az Zarqa\'',NULL,0),(1996,'JP-01','JP','Hokkaido',NULL,0),(1997,'JP-02','JP','Aomori',NULL,0),(1998,'JP-03','JP','Iwate',NULL,0),(1999,'JP-04','JP','Miyagi',NULL,0),(2000,'JP-05','JP','Akita',NULL,0),(2001,'JP-06','JP','Yamagata',NULL,0),(2002,'JP-07','JP','Hukusima (Fukushima)',NULL,0),(2003,'JP-08','JP','Ibaraki',NULL,0),(2004,'JP-09','JP','Totigi (Tochigi)',NULL,0),(2005,'JP-10','JP','Gunma',NULL,0),(2006,'JP-11','JP','Saitama',NULL,0),(2007,'JP-12','JP','Tiba (Chiba)',NULL,0),(2008,'JP-13','JP','Tokyo',NULL,0),(2009,'JP-14','JP','Kanagawa',NULL,0),(2010,'JP-15','JP','Niigata',NULL,0),(2011,'JP-16','JP','Toyama',NULL,0),(2012,'JP-17','JP','Isikawa (Ishikawa)',NULL,0),(2013,'JP-18','JP','Hukui (Fukui)',NULL,0),(2014,'JP-19','JP','Yamanasi (Yamanashi)',NULL,0),(2015,'JP-20','JP','Nagano',NULL,0),(2016,'JP-21','JP','Gihu  (Gifu)',NULL,0),(2017,'JP-22','JP','Sizuoka (Shizuoka)',NULL,0),(2018,'JP-23','JP','Aiti (Aichi)',NULL,0),(2019,'JP-24','JP','Mie',NULL,0),(2020,'JP-25','JP','Siga (Shiga)',NULL,0),(2021,'JP-26','JP','Kyoto',NULL,0),(2022,'JP-27','JP','Osaka',NULL,0),(2023,'JP-28','JP','Hyogo',NULL,0),(2024,'JP-29','JP','Nara',NULL,0),(2025,'JP-30','JP','Wakayama',NULL,0),(2026,'JP-31','JP','Tottori',NULL,0),(2027,'JP-32','JP','Simane (Shimane)',NULL,0),(2028,'JP-33','JP','Okayama',NULL,0),(2029,'JP-34','JP','Hirosima (Hiroshima)',NULL,0),(2030,'JP-35','JP','Yamaguti (Yamaguchi)',NULL,0),(2031,'JP-36','JP','Tokusima (Tokushima)',NULL,0),(2032,'JP-37','JP','Kagawa',NULL,0),(2033,'JP-38','JP','Ehime',NULL,0),(2034,'JP-39','JP','Koti (Kochi)',NULL,0),(2035,'JP-40','JP','Hukuoka (Fukuoka)',NULL,0),(2036,'JP-41','JP','Saga',NULL,0),(2037,'JP-42','JP','Nagasaki',NULL,0),(2038,'JP-43','JP','Kumamoto',NULL,0),(2039,'JP-44','JP','Oita',NULL,0),(2040,'JP-45','JP','Miyazaki',NULL,0),(2041,'JP-46','JP','Kagosima (Kagoshima)',NULL,0),(2042,'JP-47','JP','Okinawa',NULL,0),(2043,'KE-CE','KE','Central',NULL,0),(2044,'KE-CO','KE','Coast',NULL,0),(2045,'KE-EA','KE','Eastern',NULL,0),(2046,'KE-NA','KE','Nairobi Area',NULL,0),(2047,'KE-NE','KE','North Eastern',NULL,0),(2048,'KE-NY','KE','Nyanza',NULL,0),(2049,'KE-RV','KE','Rift Valley',NULL,0),(2050,'KE-WE','KE','Western',NULL,0),(2051,'KG-B','KG','Batken',NULL,0),(2052,'KG-C','KG','Chu',NULL,0),(2053,'KG-GB','KG','Bishkek',NULL,0),(2054,'KG-J','KG','Jalal-Abad',NULL,0),(2055,'KG-N','KG','Naryn',NULL,0),(2056,'KG-O','KG','Osh',NULL,0),(2057,'KG-T','KG','Talas',NULL,0),(2058,'KG-Y','KG','Ysyk-Kol',NULL,0),(2059,'KH-BA','KH','Battambang',NULL,0),(2060,'KH-BM','KH','Banteay Meanchey',NULL,0),(2061,'KH-KB','KH','Keb',NULL,0),(2062,'KH-KK','KH','Kaoh Kong',NULL,0),(2063,'KH-KL','KH','Kandal',NULL,0),(2064,'KH-KM','KH','Kampong Cham',NULL,0),(2065,'KH-KN','KH','Kampong Chhnang',NULL,0),(2066,'KH-KO','KH','Kampong Som',NULL,0),(2067,'KH-KP','KH','Kampot',NULL,0),(2068,'KH-KR','KH','Kratie',NULL,0),(2069,'KH-KT','KH','Kampong Thom',NULL,0),(2070,'KH-KU','KH','Kampong Speu',NULL,0),(2071,'KH-MK','KH','Mondul Kiri',NULL,0),(2072,'KH-OM','KH','Oddar Meancheay',NULL,0),(2073,'KH-PA','KH','Pailin',NULL,0),(2074,'KH-PG','KH','Prey Veng',NULL,0),(2075,'KH-PP','KH','Phnom Penh',NULL,0),(2076,'KH-PR','KH','Preah Vihear',NULL,0),(2077,'KH-PS','KH','Preah Seihanu (Kompong Som or Sihanoukville)',NULL,0),(2078,'KH-PU','KH','Pursat',NULL,0),(2079,'KH-RK','KH','Ratanak Kiri',NULL,0),(2080,'KH-SI','KH','Siemreap',NULL,0),(2081,'KH-SR','KH','Svay Rieng',NULL,0),(2082,'KH-ST','KH','Stung Treng',NULL,0),(2083,'KH-TK','KH','Takeo',NULL,0),(2084,'KI-AG','KI','Abaiang',NULL,0),(2085,'KI-AK','KI','Aranuka',NULL,0),(2086,'KI-AM','KI','Abemama',NULL,0),(2087,'KI-AO','KI','Arorae',NULL,0),(2088,'KI-BA','KI','Banaba',NULL,0),(2089,'KI-BE','KI','Beru',NULL,0),(2090,'KI-KA','KI','Kanton',NULL,0),(2091,'KI-KR','KI','Kiritimati',NULL,0),(2092,'KI-KU','KI','Kuria',NULL,0),(2093,'KI-ME','KI','Marakei',NULL,0),(2094,'KI-MI','KI','Maiana',NULL,0),(2095,'KI-MN','KI','Makin',NULL,0),(2096,'KI-NI','KI','Nikunau',NULL,0),(2097,'KI-NO','KI','Nonouti',NULL,0),(2098,'KI-ON','KI','Onotoa',NULL,0),(2099,'KI-TE','KI','Teraina',NULL,0),(2100,'KI-TM','KI','Tamana',NULL,0),(2101,'KI-TR','KI','Tabuaeran',NULL,0),(2102,'KI-TT','KI','Tabiteuea',NULL,0),(2103,'KI-TW','KI','Tarawa',NULL,0),(2104,'KI-bT','KI','Butaritari',NULL,0),(2105,'KM-A','KM','Anjouan',NULL,0),(2106,'KM-G','KM','Grande Comore',NULL,0),(2107,'KM-M','KM','Moheli',NULL,0),(2108,'KN-CAP','KN','Saint Paul Capesterre',NULL,0),(2109,'KN-CCN','KN','Christ Church Nichola Town',NULL,0),(2110,'KN-CHA','KN','Saint Paul Charlestown',NULL,0),(2111,'KN-SAS','KN','Saint Anne Sandy Point',NULL,0),(2112,'KN-SGB','KN','Saint George Basseterre',NULL,0),(2113,'KN-SGG','KN','Saint George Gingerland',NULL,0),(2114,'KN-SJC','KN','Saint John Capesterre',NULL,0),(2115,'KN-SJF','KN','Saint John Figtree',NULL,0),(2116,'KN-SJW','KN','Saint James Windward',NULL,0),(2117,'KN-SMC','KN','Saint Mary Cayon',NULL,0),(2118,'KN-SPB','KN','Saint Peter Basseterre',NULL,0),(2119,'KN-STL','KN','Saint Thomas Lowland',NULL,0),(2120,'KN-STM','KN','Saint Thomas Middle Island',NULL,0),(2121,'KN-TPP','KN','Trinity Palmetto Point',NULL,0),(2122,'KP-CHA','KP','Chagang-do',NULL,0),(2123,'KP-HAB','KP','Hamgyong-bukto',NULL,0),(2124,'KP-HAN','KP','Hamgyong-namdo',NULL,0),(2125,'KP-HWB','KP','Hwanghae-bukto',NULL,0),(2126,'KP-HWN','KP','Hwanghae-namdo',NULL,0),(2127,'KP-KAN','KP','Kangwon-do',NULL,0),(2128,'KP-NAJ','KP','Rason Directly Governed City',NULL,0),(2129,'KP-PYB','KP','P\'yongan-bukto',NULL,0),(2130,'KP-PYN','KP','P\'yongan-namdo',NULL,0),(2131,'KP-PYO','KP','P\'yongyang Special City',NULL,0),(2132,'KP-YAN','KP','Ryanggang-do (Yanggang-do)',NULL,0),(2133,'KR-11','KR','Seoul Special City',NULL,0),(2134,'KR-26','KR','Busan Metropolitan City',NULL,0),(2135,'KR-27','KR','Daegu Metropolitan City',NULL,0),(2136,'KR-28','KR','Incheon Metropolitan City',NULL,0),(2137,'KR-29','KR','Gwangju Metropolitan City',NULL,0),(2138,'KR-30','KR','Daejeon Metropolitan City',NULL,0),(2139,'KR-31','KR','Ulsan Metropolitan City',NULL,0),(2140,'KR-41','KR','Gyeonggi-do',NULL,0),(2141,'KR-42','KR','Gangwon-do',NULL,0),(2142,'KR-43','KR','Chungcheongbuk-do',NULL,0),(2143,'KR-44','KR','Chungcheongnam-do',NULL,0),(2144,'KR-45','KR','Jeollabuk-do',NULL,0),(2145,'KR-46','KR','Jeollanam-do',NULL,0),(2146,'KR-47','KR','Gyeongsangbuk-do',NULL,0),(2147,'KR-48','KR','Gyeongsangnam-do',NULL,0),(2148,'KR-49','KR','Jeju-do',NULL,0),(2149,'KW-D','KW','Al Ahmadi',NULL,0),(2150,'KW-F','KW','Al Farwaniyah',NULL,0),(2151,'KW-H','KW','Hawalli',NULL,0),(2152,'KW-J','KW','Al Jahra',NULL,0),(2153,'KW-S','KW','Al Asimah',NULL,0),(2154,'KY-CR','KY','Creek',NULL,0),(2155,'KY-EA','KY','Eastern',NULL,0),(2156,'KY-ML','KY','Midland',NULL,0),(2157,'KY-SK','KY','Stake Bay',NULL,0),(2158,'KY-SP','KY','Spot Bay',NULL,0),(2159,'KY-ST','KY','South Town',NULL,0),(2160,'KY-WD','KY','West End',NULL,0),(2161,'KY-WN','KY','Western',NULL,0),(2162,'KZ-AKM','KZ','Aqmola',NULL,0),(2163,'KZ-AKT','KZ','Aqtobe',NULL,0),(2164,'KZ-ALA','KZ','Almaty',NULL,0),(2165,'KZ-ALM','KZ','Almaty',NULL,0),(2166,'KZ-AST','KZ','Astana',NULL,0),(2167,'KZ-ATY','KZ','Atyrau',NULL,0),(2168,'KZ-KAR','KZ','Qaraghandy',NULL,0),(2169,'KZ-KUS','KZ','Qustanay',NULL,0),(2170,'KZ-KZY','KZ','Qyzylorda',NULL,0),(2171,'KZ-MAN','KZ','Mangghystau',NULL,0),(2172,'KZ-PAV','KZ','Paylodar',NULL,0),(2173,'KZ-SEV','KZ','Soltustik Qazaqstan',NULL,0),(2174,'KZ-VOS','KZ','Shyghys Qazaqstan',NULL,0),(2175,'KZ-YUZ','KZ','Ongtustik Qazaqstan',NULL,0),(2176,'KZ-ZAP','KZ','Baty Qazaqstan',NULL,0),(2177,'KZ-ZHA','KZ','Zhambyl',NULL,0),(2178,'LA-AT','LA','Attapu',NULL,0),(2179,'LA-BK','LA','Bokeo',NULL,0),(2180,'LA-BL','LA','Bolikhamxai',NULL,0),(2181,'LA-CH','LA','Champasak',NULL,0),(2182,'LA-HO','LA','Houaphan',NULL,0),(2183,'LA-KH','LA','Khammouan',NULL,0),(2184,'LA-LM','LA','Louang Namtha',NULL,0),(2185,'LA-LP','LA','Louangphabang',NULL,0),(2186,'LA-OU','LA','Oudomxai',NULL,0),(2187,'LA-PH','LA','Phongsali',NULL,0),(2188,'LA-SL','LA','Salavan',NULL,0),(2189,'LA-SV','LA','Savannakhet',NULL,0),(2190,'LA-VI','LA','Vientiane',NULL,0),(2191,'LA-VT','LA','Vientiane',NULL,0),(2192,'LA-XA','LA','Xaignabouli',NULL,0),(2193,'LA-XE','LA','Xekong',NULL,0),(2194,'LA-XI','LA','Xiangkhoang',NULL,0),(2195,'LA-XN','LA','Xaisomboun',NULL,0),(2196,'LC-AR','LC','Anse-la-Raye',NULL,0),(2197,'LC-CA','LC','Castries',NULL,0),(2198,'LC-CH','LC','Choiseul',NULL,0),(2199,'LC-DA','LC','Dauphin',NULL,0),(2200,'LC-DE','LC','Dennery',NULL,0),(2201,'LC-GI','LC','Gros-Islet',NULL,0),(2202,'LC-LA','LC','Laborie',NULL,0),(2203,'LC-MI','LC','Micoud',NULL,0),(2204,'LC-PR','LC','Praslin',NULL,0),(2205,'LC-SO','LC','Soufriere',NULL,0),(2206,'LC-VF','LC','Vieux-Fort',NULL,0),(2207,'LI-A','LI','Schaan',NULL,0),(2208,'LI-B','LI','Balzers',NULL,0),(2209,'LI-E','LI','Eschen',NULL,0),(2210,'LI-G','LI','Gamprin',NULL,0),(2211,'LI-M','LI','Mauren',NULL,0),(2212,'LI-N','LI','Triesen',NULL,0),(2213,'LI-P','LI','Planken',NULL,0),(2214,'LI-R','LI','Ruggell',NULL,0),(2215,'LI-T','LI','Triesenberg',NULL,0),(2216,'LI-V','LI','Vaduz',NULL,0),(2217,'Li-L','LI','Schellenberg',NULL,0),(2218,'LK-CE','LK','Central',NULL,0),(2219,'LK-EA','LK','Eastern',NULL,0),(2220,'LK-NC','LK','North Central',NULL,0),(2221,'LK-NO','LK','Northern',NULL,0),(2222,'LK-NW','LK','North Western',NULL,0),(2223,'LK-SA','LK','Sabaragamuwa',NULL,0),(2224,'LK-SO','LK','Southern',NULL,0),(2225,'LK-UV','LK','Uva',NULL,0),(2226,'LK-WE','LK','Western',NULL,0),(2227,'LR-BG','LR','Bong',NULL,0),(2228,'LR-BI','LR','Bomi',NULL,0),(2229,'LR-CM','LR','Grand Cape Mount',NULL,0),(2230,'LR-GB','LR','Grand Bassa',NULL,0),(2231,'LR-GG','LR','Grand Gedeh',NULL,0),(2232,'LR-GK','LR','Grand Kru',NULL,0),(2233,'LR-LO','LR','Lofa',NULL,0),(2234,'LR-MG','LR','Margibi',NULL,0),(2235,'LR-ML','LR','Maryland',NULL,0),(2236,'LR-MS','LR','Montserrado',NULL,0),(2237,'LR-NB','LR','Nimba',NULL,0),(2238,'LR-RC','LR','River Cess',NULL,0),(2239,'LR-SN','LR','Sinoe',NULL,0),(2240,'LS-BB','LS','Butha-Buthe',NULL,0),(2241,'LS-BE','LS','Berea',NULL,0),(2242,'LS-LE','LS','Leribe',NULL,0),(2243,'LS-MF','LS','Mafeteng',NULL,0),(2244,'LS-MH','LS','Mohale\'s Hoek',NULL,0),(2245,'LS-MK','LS','Mokhotlong',NULL,0),(2246,'LS-MS','LS','Maseru',NULL,0),(2247,'LS-QN','LS','Qacha\'s Nek',NULL,0),(2248,'LS-QT','LS','Quthing',NULL,0),(2249,'LS-TT','LS','Thaba-Tseka',NULL,0),(2250,'LT-AL','LT','Alytus',NULL,0),(2251,'LT-KA','LT','Kaunas',NULL,0),(2252,'LT-KL','LT','Klaipeda',NULL,0),(2253,'LT-MA','LT','Marijampole',NULL,0),(2254,'LT-PA','LT','Panevezys',NULL,0),(2255,'LT-SI','LT','Siauliai',NULL,0),(2256,'LT-TA','LT','Taurage',NULL,0),(2257,'LT-TE','LT','Telsiai',NULL,0),(2258,'LT-UT','LT','Utena',NULL,0),(2259,'LT-VI','LT','Vilnius',NULL,0),(2260,'LU-DC','LU','Clervaux',NULL,0),(2261,'LU-DD','LU','Diekirch',NULL,0),(2262,'LU-DR','LU','Redange',NULL,0),(2263,'LU-DV','LU','Vianden',NULL,0),(2264,'LU-DW','LU','Wiltz',NULL,0),(2265,'LU-GE','LU','Echternach',NULL,0),(2266,'LU-GG','LU','Grevenmacher',NULL,0),(2267,'LU-GR','LU','Remich',NULL,0),(2268,'LU-LC','LU','Capellen',NULL,0),(2269,'LU-LE','LU','Esch-sur-Alzette',NULL,0),(2270,'LU-LL','LU','Luxembourg',NULL,0),(2271,'LU-LM','LU','Mersch',NULL,0),(2272,'LV-AIZ','LV','Aizkraukles Rajons',NULL,0),(2273,'LV-ALU','LV','Aluksnes Rajons',NULL,0),(2274,'LV-BAL','LV','Balvu Rajons',NULL,0),(2275,'LV-BAU','LV','Bauskas Rajons',NULL,0),(2276,'LV-CES','LV','Cesu Rajons',NULL,0),(2277,'LV-DGR','LV','Daugavpils Rajons',NULL,0),(2278,'LV-DGV','LV','Daugavpils',NULL,0),(2279,'LV-DOB','LV','Dobeles Rajons',NULL,0),(2280,'LV-GUL','LV','Gulbenes Rajons',NULL,0),(2281,'LV-JEK','LV','Jekabpils Rajons',NULL,0),(2282,'LV-JGR','LV','Jelgavas Rajons',NULL,0),(2283,'LV-JGV','LV','Jelgava',NULL,0),(2284,'LV-JUR','LV','Jurmala',NULL,0),(2285,'LV-KRA','LV','Kraslavas Rajons',NULL,0),(2286,'LV-KUL','LV','Kuldigas Rajons',NULL,0),(2287,'LV-LIM','LV','Limbazu Rajons',NULL,0),(2288,'LV-LPK','LV','Liepaja',NULL,0),(2289,'LV-LPR','LV','Liepajas Rajons',NULL,0),(2290,'LV-LUD','LV','Ludzas Rajons',NULL,0),(2291,'LV-MAD','LV','Madonas Rajons',NULL,0),(2292,'LV-OGR','LV','Ogres Rajons',NULL,0),(2293,'LV-PRE','LV','Preilu Rajons',NULL,0),(2294,'LV-RGA','LV','Riga',NULL,0),(2295,'LV-RGR','LV','Rigas Rajons',NULL,0),(2296,'LV-RZK','LV','Rezekne',NULL,0),(2297,'LV-RZR','LV','Rezeknes Rajons',NULL,0),(2298,'LV-SAL','LV','Saldus Rajons',NULL,0),(2299,'LV-TAL','LV','Talsu Rajons',NULL,0),(2300,'LV-TUK','LV','Tukuma Rajons',NULL,0),(2301,'LV-VLK','LV','Valkas Rajons',NULL,0),(2302,'LV-VLM','LV','Valmieras Rajons',NULL,0),(2303,'LV-VSL','LV','Ventspils',NULL,0),(2304,'LV-VSR','LV','Ventspils Rajons',NULL,0),(2305,'LY-AJ','LY','Ajdabiya',NULL,0),(2306,'LY-AS','LY','Ash Shati\'',NULL,0),(2307,'LY-AW','LY','Awbari',NULL,0),(2308,'LY-AZ','LY','Al \'Aziziyah',NULL,0),(2309,'LY-BA','LY','Banghazi',NULL,0),(2310,'LY-DA','LY','Darnah',NULL,0),(2311,'LY-FA','LY','Al Fatih',NULL,0),(2312,'LY-GD','LY','Ghadamis',NULL,0),(2313,'LY-GY','LY','Gharyan',NULL,0),(2314,'LY-JA','LY','Al Jabal al Akhdar',NULL,0),(2315,'LY-JU','LY','Al Jufrah',NULL,0),(2316,'LY-KH','LY','Al Khums',NULL,0),(2317,'LY-KU','LY','Al Kufrah',NULL,0),(2318,'LY-MI','LY','Misratah',NULL,0),(2319,'LY-MZ','LY','Murzuq',NULL,0),(2320,'LY-NK','LY','An Nuqat al Khams',NULL,0),(2321,'LY-SB','LY','Sabha',NULL,0),(2322,'LY-SU','LY','Surt',NULL,0),(2323,'LY-SW','LY','Sawfajjin',NULL,0),(2324,'LY-TH','LY','Tarhunah',NULL,0),(2325,'LY-TL','LY','Tarabulus (Tripoli)',NULL,0),(2326,'LY-TU','LY','Tubruq',NULL,0),(2327,'LY-YA','LY','Yafran',NULL,0),(2328,'LY-ZA','LY','Az Zawiyah',NULL,0),(2329,'LY-ZL','LY','Zlitan',NULL,0),(2330,'MA-ADK','MA','Ad Dakhla',NULL,0),(2331,'MA-AGD','MA','Agadir',NULL,0),(2332,'MA-AZI','MA','Azilal',NULL,0),(2333,'MA-BJD','MA','Boujdour',NULL,0),(2334,'MA-BLM','MA','Boulemane',NULL,0),(2335,'MA-BME','MA','Beni Mellal',NULL,0),(2336,'MA-BSL','MA','Ben Slimane',NULL,0),(2337,'MA-CBL','MA','Casablanca',NULL,0),(2338,'MA-CHA','MA','Chaouen',NULL,0),(2339,'MA-EJA','MA','El Jadida',NULL,0),(2340,'MA-EKS','MA','El Kelaa des Sraghna',NULL,0),(2341,'MA-ERA','MA','Er Rachidia',NULL,0),(2342,'MA-ESM','MA','Es Smara',NULL,0),(2343,'MA-ESS','MA','Essaouira',NULL,0),(2344,'MA-FES','MA','Fes',NULL,0),(2345,'MA-FIG','MA','Figuig',NULL,0),(2346,'MA-GLM','MA','Guelmim',NULL,0),(2347,'MA-HOC','MA','Al Hoceima',NULL,0),(2348,'MA-IFR','MA','Ifrane',NULL,0),(2349,'MA-KEN','MA','Kenitra',NULL,0),(2350,'MA-KHM','MA','Khemisset',NULL,0),(2351,'MA-KHN','MA','Khenifra',NULL,0),(2352,'MA-KHO','MA','Khouribga',NULL,0),(2353,'MA-LAR','MA','Larache',NULL,0),(2354,'MA-LYN','MA','Laayoune',NULL,0),(2355,'MA-MKN','MA','Meknes',NULL,0),(2356,'MA-MRK','MA','Marrakech',NULL,0),(2357,'MA-NAD','MA','Nador',NULL,0),(2358,'MA-ORZ','MA','Ouarzazate',NULL,0),(2359,'MA-OUJ','MA','Oujda',NULL,0),(2360,'MA-RSA','MA','Rabat-Sale',NULL,0),(2361,'MA-SAF','MA','Safi',NULL,0),(2362,'MA-SET','MA','Settat',NULL,0),(2363,'MA-SKA','MA','Sidi Kacem',NULL,0),(2364,'MA-TAN','MA','Tan-Tan',NULL,0),(2365,'MA-TAO','MA','Taounate',NULL,0),(2366,'MA-TAT','MA','Tata',NULL,0),(2367,'MA-TAZ','MA','Taza',NULL,0),(2368,'MA-TET','MA','Tetouan',NULL,0),(2369,'MA-TGR','MA','Tangier',NULL,0),(2370,'MA-TIZ','MA','Tiznit',NULL,0),(2371,'MA-TRD','MA','Taroudannt',NULL,0),(2372,'MC-FV','MC','Fontvieille',NULL,0),(2373,'MC-LC','MC','La Condamine',NULL,0),(2374,'MC-MC','MC','Monte-Carlo',NULL,0),(2375,'MC-MV','MC','Monaco-Ville',NULL,0),(2376,'MD-BA','MD','Balti',NULL,0),(2377,'MD-CA','MD','Cahul',NULL,0),(2378,'MD-CU','MD','Chisinau',NULL,0),(2379,'MD-ED','MD','Edinet',NULL,0),(2380,'MD-GA','MD','Gagauzia',NULL,0),(2381,'MD-LA','MD','Lapusna',NULL,0),(2382,'MD-OR','MD','Orhei',NULL,0),(2383,'MD-SN','MD','StO?a Nistrului',NULL,0),(2384,'MD-SO','MD','Soroca',NULL,0),(2385,'MD-TI','MD','Tighina',NULL,0),(2386,'MD-UN','MD','Ungheni',NULL,0),(2387,'ME-01','ME','Andrijevica',NULL,0),(2388,'ME-02','ME','Bar',NULL,0),(2389,'ME-03','ME','Berane',NULL,0),(2390,'ME-04','ME','Bijelo Polje',NULL,0),(2391,'ME-05','ME','Budva',NULL,0),(2392,'ME-06','ME','Cetinje',NULL,0),(2393,'ME-07','ME','Danilovgrad',NULL,0),(2394,'ME-08','ME','Herceg-Novi',NULL,0),(2395,'ME-09','ME','Kolašin',NULL,0),(2396,'ME-10','ME','Kotor',NULL,0),(2397,'ME-11','ME','Mojkovac',NULL,0),(2398,'ME-12','ME','Nikšic',NULL,0),(2399,'ME-13','ME','Plav',NULL,0),(2400,'ME-14','ME','Pljevlja',NULL,0),(2401,'ME-15','ME','Plužine',NULL,0),(2402,'ME-16','ME','Podgorica',NULL,0),(2403,'ME-17','ME','Rožaje',NULL,0),(2404,'ME-19','ME','Tivat',NULL,0),(2405,'ME-20','ME','Ulcinj',NULL,0),(2406,'ME-18','ME','Šavnik',NULL,0),(2407,'ME-21','ME','Žabljak',NULL,0),(2408,'MG-AN','MG','Antananarivo province',NULL,0),(2409,'MG-AS','MG','Antsiranana province',NULL,0),(2410,'MG-FN','MG','Fianarantsoa province',NULL,0),(2411,'MG-MJ','MG','Mahajanga province',NULL,0),(2412,'MG-TL','MG','Toliara province',NULL,0),(2413,'MG-TM','MG','Toamasina province',NULL,0),(2414,'MH-ALG','MH','Ailinginae',NULL,0),(2415,'MH-ALK','MH','Ailuk',NULL,0),(2416,'MH-ALL','MH','Ailinglaplap',NULL,0),(2417,'MH-ARN','MH','Arno',NULL,0),(2418,'MH-AUR','MH','Aur',NULL,0),(2419,'MH-BKK','MH','Bokak',NULL,0),(2420,'MH-BKN','MH','Bikini',NULL,0),(2421,'MH-BKR','MH','Bikar',NULL,0),(2422,'MH-EBN','MH','Ebon',NULL,0),(2423,'MH-EKB','MH','Erikub',NULL,0),(2424,'MH-ENT','MH','Enewetak',NULL,0),(2425,'MH-JBT','MH','Jabat',NULL,0),(2426,'MH-JEM','MH','Jemo',NULL,0),(2427,'MH-JLT','MH','Jaluit',NULL,0),(2428,'MH-KIL','MH','Kili',NULL,0),(2429,'MH-KWJ','MH','Kwajalein',NULL,0),(2430,'MH-LAE','MH','Lae',NULL,0),(2431,'MH-LIB','MH','Lib',NULL,0),(2432,'MH-LKP','MH','Likiep',NULL,0),(2433,'MH-MIL','MH','Mili',NULL,0),(2434,'MH-MJR','MH','Majuro',NULL,0),(2435,'MH-MJT','MH','Mejit',NULL,0),(2436,'MH-MLP','MH','Maloelap',NULL,0),(2437,'MH-NAM','MH','Namu',NULL,0),(2438,'MH-NMK','MH','Namorik',NULL,0),(2439,'MH-RGK','MH','Rongrik',NULL,0),(2440,'MH-RGL','MH','Rongelap',NULL,0),(2441,'MH-TOK','MH','Toke',NULL,0),(2442,'MH-UJA','MH','Ujae',NULL,0),(2443,'MH-UJL','MH','Ujelang',NULL,0),(2444,'MH-UTK','MH','Utirik',NULL,0),(2445,'MH-WTH','MH','Wotho',NULL,0),(2446,'MH-WTJ','MH','Wotje',NULL,0),(2447,'ML-CD','ML','Bamako Capital District',NULL,0),(2448,'ML-GA','ML','Gao',NULL,0),(2449,'ML-KD','ML','Kidal',NULL,0),(2450,'ML-KL','ML','Koulikoro',NULL,0),(2451,'ML-KY','ML','Kayes',NULL,0),(2452,'ML-MP','ML','Mopti',NULL,0),(2453,'ML-SG','ML','Segou',NULL,0),(2454,'ML-SK','ML','Sikasso',NULL,0),(2455,'ML-TB','ML','Tombouctou',NULL,0),(2456,'MM-AY','MM','Ayeyarwady',NULL,0),(2457,'MM-BG','MM','Bago',NULL,0),(2458,'MM-CH','MM','Chin State',NULL,0),(2459,'MM-KC','MM','Kachin State',NULL,0),(2460,'MM-KH','MM','Kayah State',NULL,0),(2461,'MM-KN','MM','Kayin State',NULL,0),(2462,'MM-MD','MM','Mandalay',NULL,0),(2463,'MM-MG','MM','Magway',NULL,0),(2464,'MM-MN','MM','Mon State',NULL,0),(2465,'MM-RK','MM','Rakhine State',NULL,0),(2466,'MM-SG','MM','Sagaing',NULL,0),(2467,'MM-SH','MM','Shan State',NULL,0),(2468,'MM-TN','MM','Tanintharyi',NULL,0),(2469,'MM-YG','MM','Yangon',NULL,0),(2470,'MN-035','MN','Orhon',NULL,0),(2471,'MN-037','MN','Darhan uul',NULL,0),(2472,'MN-039','MN','Hentiy',NULL,0),(2473,'MN-041','MN','Hovsgol',NULL,0),(2474,'MN-043','MN','Hovd',NULL,0),(2475,'MN-046','MN','Uvs',NULL,0),(2476,'MN-047','MN','Tov',NULL,0),(2477,'MN-049','MN','Selenge',NULL,0),(2478,'MN-051','MN','Suhbaatar',NULL,0),(2479,'MN-053','MN','Omnogovi',NULL,0),(2480,'MN-055','MN','Ovorhangay',NULL,0),(2481,'MN-057','MN','Dzavhan',NULL,0),(2482,'MN-059','MN','DundgovL',NULL,0),(2483,'MN-061','MN','Dornod',NULL,0),(2484,'MN-063','MN','Dornogov',NULL,0),(2485,'MN-064','MN','Govi-Sumber',NULL,0),(2486,'MN-065','MN','Govi-Altay',NULL,0),(2487,'MN-067','MN','Bulgan',NULL,0),(2488,'MN-069','MN','Bayanhongor',NULL,0),(2489,'MN-071','MN','Bayan-Olgiy',NULL,0),(2490,'MN-073','MN','Arhangay',NULL,0),(2491,'MN-1','MN','Ulanbaatar',NULL,0),(2492,'MO-ANT','MO','St. Anthony Parish',NULL,0),(2493,'MO-CAT','MO','Cathedral Parish',NULL,0),(2494,'MO-LAW','MO','St. Lawrence Parish',NULL,0),(2495,'MO-LAZ','MO','St. Lazarus Parish',NULL,0),(2496,'MO-OLF','MO','Our Lady Fatima Parish',NULL,0),(2497,'MP-N','MP','Northern Islands',NULL,0),(2498,'MP-R','MP','Rota',NULL,0),(2499,'MP-S','MP','Saipan',NULL,0),(2500,'MP-T','MP','Tinian',NULL,0),(2501,'MR-AD','MR','Adrar',NULL,0),(2502,'MR-AS','MR','Assaba',NULL,0),(2503,'MR-BR','MR','Brakna',NULL,0),(2504,'MR-DN','MR','Dakhlet Nouadhibou',NULL,0),(2505,'MR-GM','MR','Guidimaka',NULL,0),(2506,'MR-GO','MR','Gorgol',NULL,0),(2507,'MR-HC','MR','Hodh Ech Chargui',NULL,0),(2508,'MR-HG','MR','Hodh El Gharbi',NULL,0),(2509,'MR-IN','MR','Inchiri',NULL,0),(2510,'MR-NO','MR','Nouakchott',NULL,0),(2511,'MR-TA','MR','Tagant',NULL,0),(2512,'MR-TR','MR','Trarza',NULL,0),(2513,'MR-TZ','MR','Tiris Zemmour',NULL,0),(2514,'MS-A','MS','Saint Anthony',NULL,0),(2515,'MS-G','MS','Saint Georges',NULL,0),(2516,'MS-P','MS','Saint Peter',NULL,0),(2517,'MT-ATT','MT','Attard',NULL,0),(2518,'MT-BAL','MT','Balzan',NULL,0),(2519,'MT-BGU','MT','Birgu',NULL,0),(2520,'MT-BKK','MT','Birkirkara',NULL,0),(2521,'MT-BOR','MT','Bormla',NULL,0),(2522,'MT-BRZ','MT','Birzebbuga',NULL,0),(2523,'MT-DIN','MT','Dingli',NULL,0),(2524,'MT-FGU','MT','Fgura',NULL,0),(2525,'MT-FLO','MT','Floriana',NULL,0),(2526,'MT-FNT','MT','Fontana',NULL,0),(2527,'MT-GDJ','MT','Gudja',NULL,0),(2528,'MT-GHJ','MT','Ghajnsielem',NULL,0),(2529,'MT-GHR','MT','Gharb',NULL,0),(2530,'MT-GHS','MT','Ghasri',NULL,0),(2531,'MT-GRG','MT','Gargur',NULL,0),(2532,'MT-GXQ','MT','Gaxaq',NULL,0),(2533,'MT-GZR','MT','Gzira',NULL,0),(2534,'MT-HMR','MT','Hamrun',NULL,0),(2535,'MT-IKL','MT','Iklin',NULL,0),(2536,'MT-ISL','MT','Isla',NULL,0),(2537,'MT-KLK','MT','Kalkara',NULL,0),(2538,'MT-KRC','MT','Kercem',NULL,0),(2539,'MT-KRK','MT','Kirkop',NULL,0),(2540,'MT-LIJ','MT','Lija',NULL,0),(2541,'MT-LUQ','MT','Luqa',NULL,0),(2542,'MT-MDN','MT','Mdina',NULL,0),(2543,'MT-MEL','MT','Melliea',NULL,0),(2544,'MT-MGR','MT','Mgarr',NULL,0),(2545,'MT-MKL','MT','Marsaskala',NULL,0),(2546,'MT-MQA','MT','Mqabba',NULL,0),(2547,'MT-MRS','MT','Marsa',NULL,0),(2548,'MT-MSI','MT','Msida',NULL,0),(2549,'MT-MST','MT','Mosta',NULL,0),(2550,'MT-MTF','MT','Mtarfa',NULL,0),(2551,'MT-MUN','MT','Munxar',NULL,0),(2552,'MT-MXL','MT','Marsaxlokk',NULL,0),(2553,'MT-NAD','MT','Nadur',NULL,0),(2554,'MT-NAX','MT','Naxxar',NULL,0),(2555,'MT-PAO','MT','Paola',NULL,0),(2556,'MT-PEM','MT','Pembroke',NULL,0),(2557,'MT-PIE','MT','Pieta',NULL,0),(2558,'MT-QAL','MT','Qala',NULL,0),(2559,'MT-QOR','MT','Qormi',NULL,0),(2560,'MT-QRE','MT','Qrendi',NULL,0),(2561,'MT-RAB','MT','Rabat',NULL,0),(2562,'MT-SAF','MT','Safi',NULL,0),(2563,'MT-SGI','MT','San Giljan',NULL,0),(2564,'MT-SGW','MT','San Gwann',NULL,0),(2565,'MT-SIG','MT','Siggiewi',NULL,0),(2566,'MT-SLA','MT','San Lawrenz',NULL,0),(2567,'MT-SLM','MT','Sliema',NULL,0),(2568,'MT-SLU','MT','Santa Lucija',NULL,0),(2569,'MT-SNT','MT','Sannat',NULL,0),(2570,'MT-SPB','MT','San Pawl il-Bahar',NULL,0),(2571,'MT-SVE','MT','Santa Venera',NULL,0),(2572,'MT-SWQ','MT','Swieqi',NULL,0),(2573,'MT-TRX','MT','Tarxien',NULL,0),(2574,'MT-TXB','MT','Ta Xbiex',NULL,0),(2575,'MT-VIC','MT','Victoria',NULL,0),(2576,'MT-VLT','MT','Valletta',NULL,0),(2577,'MT-XEW','MT','Xewkija',NULL,0),(2578,'MT-XGJ','MT','Xgajra',NULL,0),(2579,'MT-ZAG','MT','Xagra',NULL,0),(2580,'MT-ZBG','MT','Zebbug',NULL,0),(2581,'MT-ZBR','MT','Zabbar',NULL,0),(2582,'MT-ZEB','MT','Zebbug',NULL,0),(2583,'MT-ZJT','MT','Zejtun',NULL,0),(2584,'MT-ZRQ','MT','Zurrieq',NULL,0),(2585,'MU-AG','MU','Agalega Islands',NULL,0),(2586,'MU-BL','MU','Black River',NULL,0),(2587,'MU-BR','MU','Beau Bassin-Rose Hill',NULL,0),(2588,'MU-CC','MU','Cargados Carajos Shoals (Saint Brandon Islands)',NULL,0),(2589,'MU-CU','MU','Curepipe',NULL,0),(2590,'MU-FL','MU','Flacq',NULL,0),(2591,'MU-GP','MU','Grand Port',NULL,0),(2592,'MU-MO','MU','Moka',NULL,0),(2593,'MU-PA','MU','Pamplemousses',NULL,0),(2594,'MU-PL','MU','Port Louis',NULL,0),(2595,'MU-PU','MU','Port Louis',NULL,0),(2596,'MU-PW','MU','Plaines Wilhems',NULL,0),(2597,'MU-QB','MU','Quatre Bornes',NULL,0),(2598,'MU-RO','MU','Rodrigues',NULL,0),(2599,'MU-RR','MU','Riviere du Rempart',NULL,0),(2600,'MU-SA','MU','Savanne',NULL,0),(2601,'MU-VP','MU','Vacoas-Phoenix',NULL,0),(2602,'MV-AAD','MV','Ari Atoll Dheknu',NULL,0),(2603,'MV-AAU','MV','Ari Atoll Uthuru',NULL,0),(2604,'MV-ADD','MV','Addu',NULL,0),(2605,'MV-FAA','MV','Faadhippolhu',NULL,0),(2606,'MV-FEA','MV','Felidhe Atoll',NULL,0),(2607,'MV-FMU','MV','Fua Mulaku',NULL,0),(2608,'MV-HAD','MV','Huvadhu Atoll Dhekunu',NULL,0),(2609,'MV-HAU','MV','Huvadhu Atoll Uthuru',NULL,0),(2610,'MV-HDH','MV','Hadhdhunmathi',NULL,0),(2611,'MV-KLH','MV','Kolhumadulu',NULL,0),(2612,'MV-MAA','MV','Male Atoll',NULL,0),(2613,'MV-MAD','MV','Maalhosmadulu Dhekunu',NULL,0),(2614,'MV-MAU','MV','Maalhosmadulu Uthuru',NULL,0),(2615,'MV-MLD','MV','Miladhunmadulu Dhekunu',NULL,0),(2616,'MV-MLU','MV','Miladhunmadulu Uthuru',NULL,0),(2617,'MV-MUA','MV','Mulaku Atoll',NULL,0),(2618,'MV-NAD','MV','Nilandhe Atoll Dhekunu',NULL,0),(2619,'MV-NAU','MV','Nilandhe Atoll Uthuru',NULL,0),(2620,'MV-THD','MV','Thiladhunmathi Dhekunu',NULL,0),(2621,'MV-THU','MV','Thiladhunmathi Uthuru',NULL,0),(2622,'MW-BLK','MW','Balaka',NULL,0),(2623,'MW-BLT','MW','Blantyre',NULL,0),(2624,'MW-CKW','MW','Chikwawa',NULL,0),(2625,'MW-CRD','MW','Chiradzulu',NULL,0),(2626,'MW-CTP','MW','Chitipa',NULL,0),(2627,'MW-DDZ','MW','Dedza',NULL,0),(2628,'MW-DWA','MW','Dowa',NULL,0),(2629,'MW-KRG','MW','Karonga',NULL,0),(2630,'MW-KSG','MW','Kasungu',NULL,0),(2631,'MW-LKM','MW','Likoma',NULL,0),(2632,'MW-LLG','MW','Lilongwe',NULL,0),(2633,'MW-MCG','MW','Machinga',NULL,0),(2634,'MW-MCH','MW','Mchinji',NULL,0),(2635,'MW-MGC','MW','Mangochi',NULL,0),(2636,'MW-MLJ','MW','Mulanje',NULL,0),(2637,'MW-MWZ','MW','Mwanza',NULL,0),(2638,'MW-MZM','MW','Mzimba',NULL,0),(2639,'MW-NKB','MW','Nkhata Bay',NULL,0),(2640,'MW-NKH','MW','Nkhotakota',NULL,0),(2641,'MW-NSJ','MW','Nsanje',NULL,0),(2642,'MW-NTI','MW','Ntchisi',NULL,0),(2643,'MW-NTU','MW','Ntcheu',NULL,0),(2644,'MW-PHL','MW','Phalombe',NULL,0),(2645,'MW-RMP','MW','Rumphi',NULL,0),(2646,'MW-SLM','MW','Salima',NULL,0),(2647,'MW-THY','MW','Thyolo',NULL,0),(2648,'MW-ZBA','MW','Zomba',NULL,0),(2649,'MX-AGU','MX','Aguascalientes',NULL,0),(2650,'MX-BCN','MX','Baja California',NULL,0),(2651,'MX-BCS','MX','Baja California Sur',NULL,0),(2652,'MX-CAM','MX','Campeche',NULL,0),(2653,'MX-CHH','MX','Chihuahua',NULL,0),(2654,'MX-CHP','MX','Chiapas',NULL,0),(2655,'MX-COA','MX','Coahuila',NULL,0),(2656,'MX-COL','MX','Colima',NULL,0),(2657,'MX-DIF','MX','Distrito Federal',NULL,0),(2658,'MX-DUR','MX','Durango',NULL,0),(2659,'MX-GRO','MX','Guerrero',NULL,0),(2660,'MX-GUA','MX','Guanajuato',NULL,0),(2661,'MX-HID','MX','Hidalgo',NULL,0),(2662,'MX-JAL','MX','Jalisco',NULL,0),(2663,'MX-MEX','MX','Mexico',NULL,0),(2664,'MX-MIC','MX','Michoacan',NULL,0),(2665,'MX-MOR','MX','Morelos',NULL,0),(2666,'MX-NAY','MX','Nayarit',NULL,0),(2667,'MX-NLE','MX','Nuevo Leon',NULL,0),(2668,'MX-OAX','MX','Oaxaca',NULL,0),(2669,'MX-PUE','MX','Puebla',NULL,0),(2670,'MX-QUE','MX','Queretaro',NULL,0),(2671,'MX-ROO','MX','Quintana Roo',NULL,0),(2672,'MX-SIN','MX','Sinaloa',NULL,0),(2673,'MX-SLP','MX','San Luis Potosi',NULL,0),(2674,'MX-SON','MX','Sonora',NULL,0),(2675,'MX-TAB','MX','Tabasco',NULL,0),(2676,'MX-TAM','MX','Tamaulipas',NULL,0),(2677,'MX-TLA','MX','Tlaxcala',NULL,0),(2678,'MX-VER','MX','Veracruz',NULL,0),(2679,'MX-YUC','MX','Yucatan',NULL,0),(2680,'MX-ZAC','MX','Zacatecas',NULL,0),(2681,'MY-JH','MY','Johor',NULL,0),(2682,'MY-KD','MY','Kedah',NULL,0),(2683,'MY-KL','MY','Kuala Lumpur',NULL,0),(2684,'MY-KN','MY','Kelantan',NULL,0),(2685,'MY-LB','MY','Labuan',NULL,0),(2686,'MY-ML','MY','Malacca',NULL,0),(2687,'MY-NS','MY','Negeri Sembilan',NULL,0),(2688,'MY-PG','MY','Penang',NULL,0),(2689,'MY-PH','MY','Pahang',NULL,0),(2690,'MY-PK','MY','Perak',NULL,0),(2691,'MY-PS','MY','Perlis',NULL,0),(2692,'MY-SB','MY','Sabah',NULL,0),(2693,'MY-SL','MY','Selangor',NULL,0),(2694,'MY-SR','MY','Sarawak',NULL,0),(2695,'MY-TR','MY','Terengganu',NULL,0),(2696,'MY-WP','MY','Wilayah Persekutuan',NULL,0),(2697,'MZ-CD','MZ','Cabo Delgado',NULL,0),(2698,'MZ-GZ','MZ','Gaza',NULL,0),(2699,'MZ-IN','MZ','Inhambane',NULL,0),(2700,'MZ-MC','MZ','Maputo (city)',NULL,0),(2701,'MZ-MN','MZ','Manica',NULL,0),(2702,'MZ-MP','MZ','Maputo',NULL,0),(2703,'MZ-NA','MZ','Nampula',NULL,0),(2704,'MZ-NI','MZ','Niassa',NULL,0),(2705,'MZ-SO','MZ','Sofala',NULL,0),(2706,'MZ-TE','MZ','Tete',NULL,0),(2707,'MZ-ZA','MZ','Zambezia',NULL,0),(2708,'NA-CA','NA','Caprivi',NULL,0),(2709,'NA-ER','NA','Erongo',NULL,0),(2710,'NA-HA','NA','Hardap',NULL,0),(2711,'NA-KH','NA','Khomas',NULL,0),(2712,'NA-KR','NA','Karas',NULL,0),(2713,'NA-KU','NA','Kunene',NULL,0),(2714,'NA-KV','NA','Kavango',NULL,0),(2715,'NA-OJ','NA','Otjozondjupa',NULL,0),(2716,'NA-OK','NA','Omaheke',NULL,0),(2717,'NA-ON','NA','Oshana',NULL,0),(2718,'NA-OO','NA','Oshikoto',NULL,0),(2719,'NA-OT','NA','Omusati',NULL,0),(2720,'NA-OW','NA','Ohangwena',NULL,0),(2721,'NC-L','NC','Iles Loyaute',NULL,0),(2722,'NC-N','NC','Nord',NULL,0),(2723,'NC-S','NC','Sud',NULL,0),(2724,'NG-AB','NG','Abia',NULL,0),(2725,'NG-AD','NG','Adamawa',NULL,0),(2726,'NG-AG','NG','Agadez',NULL,0),(2727,'NG-AK','NG','Akwa Ibom',NULL,0),(2728,'NG-AN','NG','Anambra',NULL,0),(2729,'NG-BC','NG','Bauchi',NULL,0),(2730,'NG-BN','NG','Benue',NULL,0),(2731,'NG-BO','NG','Borno',NULL,0),(2732,'NG-BY','NG','Bayelsa',NULL,0),(2733,'NG-CR','NG','Cross River',NULL,0),(2734,'NG-CT','NG','Federal Capital Territory',NULL,0),(2735,'NG-DE','NG','Delta',NULL,0),(2736,'NG-DF','NG','Diffa',NULL,0),(2737,'NG-DS','NG','Dosso',NULL,0),(2738,'NG-EB','NG','Ebonyi',NULL,0),(2739,'NG-ED','NG','Edo',NULL,0),(2740,'NG-EK','NG','Ekiti',NULL,0),(2741,'NG-EN','NG','Enugu',NULL,0),(2742,'NG-GO','NG','Gombe',NULL,0),(2743,'NG-IM','NG','Imo',NULL,0),(2744,'NG-JI','NG','Jigawa',NULL,0),(2745,'NG-KD','NG','Kaduna',NULL,0),(2746,'NG-KE','NG','Kebbi',NULL,0),(2747,'NG-KN','NG','Kano',NULL,0),(2748,'NG-KO','NG','Kogi',NULL,0),(2749,'NG-KT','NG','Katsina',NULL,0),(2750,'NG-KW','NG','Kwara',NULL,0),(2751,'NG-LA','NG','Lagos',NULL,0),(2752,'NG-MA','NG','Maradi',NULL,0),(2753,'NG-NA','NG','Nassarawa',NULL,0),(2754,'NG-NI','NG','Niger',NULL,0),(2755,'NG-NM','NG','Niamey',NULL,0),(2756,'NG-OG','NG','Ogun',NULL,0),(2757,'NG-ONG','NG','Ondo',NULL,0),(2758,'NG-OS','NG','Osun',NULL,0),(2759,'NG-OY','NG','Oyo',NULL,0),(2760,'NG-PL','NG','Plateau',NULL,0),(2761,'NG-RI','NG','Rivers',NULL,0),(2762,'NG-SO','NG','Sokoto',NULL,0),(2763,'NG-TA','NG','Taraba',NULL,0),(2764,'NG-TH','NG','Tahoua',NULL,0),(2765,'NG-TL','NG','Tillaberi',NULL,0),(2766,'NG-YO','NG','Yobe',NULL,0),(2767,'NG-ZA','NG','Zamfara',NULL,0),(2768,'NG-ZD','NG','Zinder',NULL,0),(2769,'NI-AN','NI','Region Autonoma del Atlantico Norte',NULL,0),(2770,'NI-AS','NI','Region Autonoma del Atlantico Sur',NULL,0),(2771,'NI-BO','NI','Boaco',NULL,0),(2772,'NI-CA','NI','Carazo',NULL,0),(2773,'NI-CD','NI','Chinandega',NULL,0),(2774,'NI-CT','NI','Chontales',NULL,0),(2775,'NI-ES','NI','Esteli',NULL,0),(2776,'NI-GR','NI','Granada',NULL,0),(2777,'NI-JI','NI','Jinotega',NULL,0),(2778,'NI-LE','NI','Leon',NULL,0),(2779,'NI-MD','NI','Madriz',NULL,0),(2780,'NI-MN','NI','Managua',NULL,0),(2781,'NI-MS','NI','Masaya',NULL,0),(2782,'NI-MT','NI','Matagalpa',NULL,0),(2783,'NI-NS','NI','Nueva Segovia',NULL,0),(2784,'NI-RV','NI','Rivas',NULL,0),(2785,'NI-SJ','NI','Rio San Juan',NULL,0),(2786,'NL-DR','NL','Drenthe',NULL,0),(2787,'NL-FL','NL','Flevoland',NULL,0),(2788,'NL-FR','NL','Friesland',NULL,0),(2789,'NL-GE','NL','Gelderland',NULL,0),(2790,'NL-GR','NL','Groningen',NULL,0),(2791,'NL-LI','NL','Limburg',NULL,0),(2792,'NL-NB','NL','Noord Brabant',NULL,0),(2793,'NL-NH','NL','Noord Holland',NULL,0),(2794,'NL-OV','NL','Overijssel',NULL,0),(2795,'NL-UT','NL','Utrecht',NULL,0),(2796,'NL-ZE','NL','Zeeland',NULL,0),(2797,'NL-ZH','NL','Zuid Holland',NULL,0),(2798,'NO-AA','NO','Aust-Agder',NULL,0),(2799,'NO-AK','NO','Akershus',NULL,0),(2800,'NO-BU','NO','Buskerud',NULL,0),(2801,'NO-FM','NO','Finnmark',NULL,0),(2802,'NO-HL','NO','Hordaland',NULL,0),(2803,'NO-HM','NO','Hedmark',NULL,0),(2804,'NO-MR','NO','More og Romdal',NULL,0),(2805,'NO-NL','NO','Nordland',NULL,0),(2806,'NO-NT','NO','Nord-Trondelag',NULL,0),(2807,'NO-OF','NO','Ostfold',NULL,0),(2808,'NO-OL','NO','Oslo',NULL,0),(2809,'NO-OP','NO','Oppland',NULL,0),(2810,'NO-RL','NO','Rogaland',NULL,0),(2811,'NO-SJ','NO','Sogn og Fjordane',NULL,0),(2812,'NO-ST','NO','Sor-Trondelag',NULL,0),(2813,'NO-TM','NO','Telemark',NULL,0),(2814,'NO-TR','NO','Troms',NULL,0),(2815,'NO-VA','NO','Vest-Agder',NULL,0),(2816,'NO-VF','NO','Vestfold',NULL,0),(2817,'NP-BA','NP','Bagmati',NULL,0),(2818,'NP-BH','NP','Bheri',NULL,0),(2819,'NP-DH','NP','Dhawalagiri',NULL,0),(2820,'NP-GA','NP','Gandaki',NULL,0),(2821,'NP-JA','NP','Janakpur',NULL,0),(2822,'NP-KA','NP','Karnali',NULL,0),(2823,'NP-KO','NP','Kosi',NULL,0),(2824,'NP-LU','NP','Lumbini',NULL,0),(2825,'NP-MA','NP','Mahakali',NULL,0),(2826,'NP-ME','NP','Mechi',NULL,0),(2827,'NP-NA','NP','Narayani',NULL,0),(2828,'NP-RA','NP','Rapti',NULL,0),(2829,'NP-SA','NP','Sagarmatha',NULL,0),(2830,'NP-SE','NP','Seti',NULL,0),(2831,'NR-AA','NR','Anabar',NULL,0),(2832,'NR-AI','NR','Anibare',NULL,0),(2833,'NR-AO','NR','Aiwo',NULL,0),(2834,'NR-AT','NR','Anetan',NULL,0),(2835,'NR-BA','NR','Baiti',NULL,0),(2836,'NR-BO','NR','Boe',NULL,0),(2837,'NR-BU','NR','Buada',NULL,0),(2838,'NR-DE','NR','Denigomodu',NULL,0),(2839,'NR-EW','NR','Ewa',NULL,0),(2840,'NR-IJ','NR','Ijuw',NULL,0),(2841,'NR-ME','NR','Meneng',NULL,0),(2842,'NR-NI','NR','Nibok',NULL,0),(2843,'NR-UA','NR','Uaboe',NULL,0),(2844,'NR-YA','NR','Yaren',NULL,0),(2845,'NZ-AUK','NZ','Auckland',NULL,0),(2846,'NZ-BOP','NZ','Bay of Plenty',NULL,0),(2847,'NZ-CAN','NZ','Canterbury',NULL,0),(2848,'NZ-GIS','NZ','Gisborne',NULL,0),(2849,'NZ-HKB','NZ','Hawke\'s Bay',NULL,0),(2850,'NZ-MBH','NZ','Marlborough',NULL,0),(2851,'NZ-MWT','NZ','Manawatu-Wanganui',NULL,0),(2852,'NZ-NSN','NZ','Nelson',NULL,0),(2853,'NZ-NTL','NZ','Northland',NULL,0),(2854,'NZ-OTA','NZ','Otago',NULL,0),(2855,'NZ-STL','NZ','Southland',NULL,0),(2856,'NZ-TAS','NZ','Tasman',NULL,0),(2857,'NZ-TKI','NZ','Taranaki',NULL,0),(2858,'NZ-WGN','NZ','Wellington',NULL,0),(2859,'NZ-WKO','NZ','Waikato',NULL,0),(2860,'NZ-WTC','NZ','West Coast',NULL,0),(2861,'OM-BA','OM','Al Batinah',NULL,0),(2862,'OM-DA','OM','Ad Dakhiliyah',NULL,0),(2863,'OM-MA','OM','Masqat',NULL,0),(2864,'OM-MU','OM','Musandam',NULL,0),(2865,'OM-SH','OM','Ash Sharqiyah',NULL,0),(2866,'OM-WU','OM','Al Wusta',NULL,0),(2867,'OM-ZA','OM','Az Zahirah',NULL,0),(2868,'OM-ZU','OM','Zufar',NULL,0),(2869,'PA-BT','PA','Bocas del Toro',NULL,0),(2870,'PA-CC','PA','Cocle',NULL,0),(2871,'PA-CH','PA','Chiriqui',NULL,0),(2872,'PA-CL','PA','Colon',NULL,0),(2873,'PA-DA','PA','Darien',NULL,0),(2874,'PA-HE','PA','Herrera',NULL,0),(2875,'PA-LS','PA','Los Santos',NULL,0),(2876,'PA-PA','PA','Panama',NULL,0),(2877,'PA-SB','PA','San Blas',NULL,0),(2878,'PA-VG','PA','Veraguas',NULL,0),(2879,'PE-AM','PE','Amazonas',NULL,0),(2880,'PE-AN','PE','Ancash',NULL,0),(2881,'PE-AP','PE','Apurimac',NULL,0),(2882,'PE-AR','PE','Arequipa',NULL,0),(2883,'PE-AY','PE','Ayacucho',NULL,0),(2884,'PE-CJ','PE','Cajamarca',NULL,0),(2885,'PE-CL','PE','Callao',NULL,0),(2886,'PE-CU','PE','Cusco',NULL,0),(2887,'PE-HO','PE','Huanuco',NULL,0),(2888,'PE-HV','PE','Huancavelica',NULL,0),(2889,'PE-IC','PE','Ica',NULL,0),(2890,'PE-JU','PE','Junin',NULL,0),(2891,'PE-LD','PE','La Libertad',NULL,0),(2892,'PE-LI','PE','Lima',NULL,0),(2893,'PE-LO','PE','Loreto',NULL,0),(2894,'PE-LY','PE','Lambayeque',NULL,0),(2895,'PE-MD','PE','Madre de Dios',NULL,0),(2896,'PE-MO','PE','Moquegua',NULL,0),(2897,'PE-PA','PE','Pasco',NULL,0),(2898,'PE-PI','PE','Piura',NULL,0),(2899,'PE-PU','PE','Puno',NULL,0),(2900,'PE-SM','PE','San Martin',NULL,0),(2901,'PE-TA','PE','Tacna',NULL,0),(2902,'PE-TU','PE','Tumbes',NULL,0),(2903,'PE-UC','PE','Ucayali',NULL,0),(2904,'PF-I','PF','Archipel des Tubuai',NULL,0),(2905,'PF-M','PF','Archipel des Marquises',NULL,0),(2906,'PF-S','PF','Iles Sous-le-Vent',NULL,0),(2907,'PF-T','PF','Archipel des Tuamotu',NULL,0),(2908,'PF-V','PF','Iles du Vent',NULL,0),(2909,'PG-BV','PG','Bougainville',NULL,0),(2910,'PG-CE','PG','Central',NULL,0),(2911,'PG-CH','PG','Chimbu',NULL,0),(2912,'PG-EB','PG','East New Britain',NULL,0),(2913,'PG-EH','PG','Eastern Highlands',NULL,0),(2914,'PG-EN','PG','Enga',NULL,0),(2915,'PG-ES','PG','East Sepik',NULL,0),(2916,'PG-GU','PG','Gulf',NULL,0),(2917,'PG-MB','PG','Milne Bay',NULL,0),(2918,'PG-MD','PG','Madang',NULL,0),(2919,'PG-MN','PG','Manus',NULL,0),(2920,'PG-MR','PG','Morobe',NULL,0),(2921,'PG-NC','PG','National Capital',NULL,0),(2922,'PG-NI','PG','New Ireland',NULL,0),(2923,'PG-NO','PG','Northern',NULL,0),(2924,'PG-SA','PG','Sandaun',NULL,0),(2925,'PG-SH','PG','Southern Highlands',NULL,0),(2926,'PG-WB','PG','West New Britain',NULL,0),(2927,'PG-WE','PG','Western',NULL,0),(2928,'PG-WH','PG','Western Highlands',NULL,0),(2929,'PH-ABR','PH','Abra',NULL,0),(2930,'PH-AKL','PH','Aklan',NULL,0),(2931,'PH-ALB','PH','Albay',NULL,0),(2932,'PH-ANO','PH','Agusan del Norte',NULL,0),(2933,'PH-ANT','PH','Antique',NULL,0),(2934,'PH-APY','PH','Apayao',NULL,0),(2935,'PH-ASU','PH','Agusan del Sur',NULL,0),(2936,'PH-AUR','PH','Aurora',NULL,0),(2937,'PH-BAS','PH','Basilan',NULL,0),(2938,'PH-BEN','PH','Benguet',NULL,0),(2939,'PH-BLR','PH','Biliran',NULL,0),(2940,'PH-BOL','PH','Bohol',NULL,0),(2941,'PH-BTA','PH','Bataan',NULL,0),(2942,'PH-BTE','PH','Batanes',NULL,0),(2943,'PH-BTG','PH','Batangas',NULL,0),(2944,'PH-BUK','PH','Bukidnon',NULL,0),(2945,'PH-BUL','PH','Bulacan',NULL,0),(2946,'PH-CAG','PH','Cagayan',NULL,0),(2947,'PH-CAM','PH','Camiguin',NULL,0),(2948,'PH-CAP','PH','Capiz',NULL,0),(2949,'PH-CAT','PH','Catanduanes',NULL,0),(2950,'PH-CAV','PH','Cavite',NULL,0),(2951,'PH-CEB','PH','Cebu',NULL,0),(2952,'PH-CMP','PH','Compostela',NULL,0),(2953,'PH-CNO','PH','Camarines Norte',NULL,0),(2954,'PH-CSU','PH','Camarines Sur',NULL,0),(2955,'PH-DNO','PH','Davao del Norte',NULL,0),(2956,'PH-DOR','PH','Davao Oriental',NULL,0),(2957,'PH-DSU','PH','Davao del Sur',NULL,0),(2958,'PH-ESA','PH','Eastern Samar',NULL,0),(2959,'PH-GUI','PH','Guimaras',NULL,0),(2960,'PH-IFU','PH','Ifugao',NULL,0),(2961,'PH-ILO','PH','Iloilo',NULL,0),(2962,'PH-INO','PH','Ilocos Norte',NULL,0),(2963,'PH-ISA','PH','Isabela',NULL,0),(2964,'PH-ISU','PH','Ilocos Sur',NULL,0),(2965,'PH-KAL','PH','Kalinga',NULL,0),(2966,'PH-LAG','PH','Laguna',NULL,0),(2967,'PH-LEY','PH','Leyte',NULL,0),(2968,'PH-LNO','PH','Lanao del Norte',NULL,0),(2969,'PH-LSU','PH','Lanao del Sur',NULL,0),(2970,'PH-MAG','PH','Maguindanao',NULL,0),(2971,'PH-MIC','PH','Mindoro Occidental',NULL,0),(2972,'PH-MIR','PH','Mindoro Oriental',NULL,0),(2973,'PH-MOP','PH','Mountain Province',NULL,0),(2974,'PH-MOR','PH','Misamis Oriental',NULL,0),(2975,'PH-MRN','PH','Marinduque',NULL,0),(2976,'PH-MSB','PH','Masbate',NULL,0),(2977,'PH-MSC','PH','Misamis Occidental',NULL,0),(2978,'PH-NCT','PH','North Cotabato',NULL,0),(2979,'PH-NEC','PH','Nueva Ecija',NULL,0),(2980,'PH-NOC','PH','Negros Occidental',NULL,0),(2981,'PH-NOR','PH','Negros Oriental',NULL,0),(2982,'PH-NSM','PH','Northern Samar',NULL,0),(2983,'PH-NVZ','PH','Nueva Vizcaya',NULL,0),(2984,'PH-PLW','PH','Palawan',NULL,0),(2985,'PH-PMP','PH','Pampanga',NULL,0),(2986,'PH-PNG','PH','Pangasinan',NULL,0),(2987,'PH-QRN','PH','Quirino',NULL,0),(2988,'PH-QZN','PH','Quezon',NULL,0),(2989,'PH-RIZ','PH','Rizal',NULL,0),(2990,'PH-ROM','PH','Romblon',NULL,0),(2991,'PH-SCO','PH','South Cotabato',NULL,0),(2992,'PH-SKU','PH','Sultan Kudarat',NULL,0),(2993,'PH-SLE','PH','Southern Leyte',NULL,0),(2994,'PH-SLU','PH','Sulu',NULL,0),(2995,'PH-SMR','PH','Samar',NULL,0),(2996,'PH-SNO','PH','Surigao del Norte',NULL,0),(2997,'PH-SQJ','PH','Siquijor',NULL,0),(2998,'PH-SRG','PH','Sarangani',NULL,0),(2999,'PH-SRS','PH','Sorsogon',NULL,0),(3000,'PH-SSU','PH','Surigao del Sur',NULL,0),(3001,'PH-TAR','PH','Tarlac',NULL,0),(3002,'PH-TAW','PH','Tawi-Tawi',NULL,0),(3003,'PH-UNI','PH','La Union',NULL,0),(3004,'PH-ZBL','PH','Zambales',NULL,0),(3005,'PH-ZNO','PH','Zamboanga del Norte',NULL,0),(3006,'PH-ZSI','PH','Zamboanga Sibugay',NULL,0),(3007,'PH-ZSU','PH','Zamboanga del Sur',NULL,0),(3008,'PK-B','PK','Balochistan',NULL,0),(3009,'PK-I','PK','Islamabad Capital Territory',NULL,0),(3010,'PK-N','PK','North-West Frontier Province',NULL,0),(3011,'PK-P','PK','Punjab',NULL,0),(3012,'PK-S','PK','Sindh',NULL,0),(3013,'PK-T','PK','Federally Administered Tribal Areas',NULL,0),(3014,'PL-DO','PL','Dolnoslaskie',NULL,0),(3015,'PL-KP','PL','Kujawsko-Pomorskie',NULL,0),(3016,'PL-LL','PL','Lubelskie',NULL,0),(3017,'PL-LO','PL','Lodzkie',NULL,0),(3018,'PL-LU','PL','Lubuskie',NULL,0),(3019,'PL-ML','PL','Malopolskie',NULL,0),(3020,'PL-MZ','PL','Mazowieckie',NULL,0),(3021,'PL-OP','PL','Opolskie',NULL,0),(3022,'PL-PL','PL','Podlaskie',NULL,0),(3023,'PL-PM','PL','Pomorskie',NULL,0),(3024,'PL-PP','PL','Podkarpackie',NULL,0),(3025,'PL-SL','PL','Slaskie',NULL,0),(3026,'PL-SW','PL','Swietokrzyskie',NULL,0),(3027,'PL-WM','PL','Warminsko-Mazurskie',NULL,0),(3028,'PL-WP','PL','Wielkopolskie',NULL,0),(3029,'PL-ZA','PL','Zachodniopomorskie',NULL,0),(3030,'PM-M','PM','Miquelon',NULL,0),(3031,'PM-P','PM','Saint Pierre',NULL,0),(3032,'PT-AR','PT','Acores (Azores)',NULL,0),(3033,'PT-AV','PT','Aveiro',NULL,0),(3034,'PT-BA','PT','Braga',NULL,0),(3035,'PT-BJ','PT','Beja',NULL,0),(3036,'PT-BN','PT','Braganca',NULL,0),(3037,'PT-CB','PT','Castelo Branco',NULL,0),(3038,'PT-CO','PT','Coimbra',NULL,0),(3039,'PT-EV','PT','Evora',NULL,0),(3040,'PT-FA','PT','Faro',NULL,0),(3041,'PT-GU','PT','Guarda',NULL,0),(3042,'PT-LE','PT','Leiria',NULL,0),(3043,'PT-LI','PT','Lisboa',NULL,0),(3044,'PT-MA','PT','Madeira',NULL,0),(3045,'PT-PG','PT','Portalegre',NULL,0),(3046,'PT-PO','PT','Porto',NULL,0),(3047,'PT-SA','PT','Santarem',NULL,0),(3048,'PT-SE','PT','Setubal',NULL,0),(3049,'PT-VC','PT','Viana do Castelo',NULL,0),(3050,'PT-VR','PT','Vila Real',NULL,0),(3051,'PT-VS','PT','Viseu',NULL,0),(3052,'PW-AM','PW','Aimeliik',NULL,0),(3053,'PW-AN','PW','Angaur',NULL,0),(3054,'PW-AR','PW','Airai',NULL,0),(3055,'PW-HA','PW','Hatohobei',NULL,0),(3056,'PW-KA','PW','Kayangel',NULL,0),(3057,'PW-KO','PW','Koror',NULL,0),(3058,'PW-ME','PW','Melekeok',NULL,0),(3059,'PW-NA','PW','Ngaraard',NULL,0),(3060,'PW-NC','PW','Ngchesar',NULL,0),(3061,'PW-ND','PW','Ngardmau',NULL,0),(3062,'PW-NG','PW','Ngarchelong',NULL,0),(3063,'PW-NR','PW','Ngeremlengui',NULL,0),(3064,'PW-NT','PW','Ngatpang',NULL,0),(3065,'PW-NW','PW','Ngiwal',NULL,0),(3066,'PW-PE','PW','Peleliu',NULL,0),(3067,'PW-SO','PW','Sonsorol',NULL,0),(3068,'PY-AG','PY','Alto Paraguay',NULL,0),(3069,'PY-AM','PY','Amambay',NULL,0),(3070,'PY-AN','PY','Alto Parana',NULL,0),(3071,'PY-AS','PY','Asuncion',NULL,0),(3072,'PY-BO','PY','Boqueron',NULL,0),(3073,'PY-CC','PY','Concepcion',NULL,0),(3074,'PY-CD','PY','Cordillera',NULL,0),(3075,'PY-CE','PY','Central',NULL,0),(3076,'PY-CG','PY','Caaguazu',NULL,0),(3077,'PY-CN','PY','Canindeyu',NULL,0),(3078,'PY-CZ','PY','Caazapa',NULL,0),(3079,'PY-GU','PY','Guaira',NULL,0),(3080,'PY-IT','PY','Itapua',NULL,0),(3081,'PY-MI','PY','Misiones',NULL,0),(3082,'PY-NE','PY','Neembucu',NULL,0),(3083,'PY-PA','PY','Paraguari',NULL,0),(3084,'PY-PH','PY','Presidente Hayes',NULL,0),(3085,'PY-SP','PY','San Pedro',NULL,0),(3086,'QA-DW','QA','Ad Dawhah',NULL,0),(3087,'QA-GW','QA','Al Ghuwayriyah',NULL,0),(3088,'QA-JB','QA','Jarayan al Batinah',NULL,0),(3089,'QA-JM','QA','Al Jumayliyah',NULL,0),(3090,'QA-KR','QA','Al Khawr',NULL,0),(3091,'QA-MS','QA','Madinat ash Shamal',NULL,0),(3092,'QA-RN','QA','Ar Rayyan',NULL,0),(3093,'QA-UD','QA','Umm Sa\'id',NULL,0),(3094,'QA-UL','QA','Umm Salal',NULL,0),(3095,'QA-WK','QA','Al Wakrah',NULL,0),(3096,'RO-AD','RO','Arad',NULL,0),(3097,'RO-AG','RO','Arges',NULL,0),(3098,'RO-AL','RO','Alba',NULL,0),(3099,'RO-BA','RO','Bacau',NULL,0),(3100,'RO-BC','RO','Bucuresti',NULL,0),(3101,'RO-BH','RO','Bihor',NULL,0),(3102,'RO-BL','RO','Braila',NULL,0),(3103,'RO-BN','RO','Bistrita-Nasaud',NULL,0),(3104,'RO-BO','RO','Botosani',NULL,0),(3105,'RO-BS','RO','Brasov',NULL,0),(3106,'RO-BZ','RO','Buzau',NULL,0),(3107,'RO-CJ','RO','Cluj',NULL,0),(3108,'RO-CR','RO','Calarasi',NULL,0),(3109,'RO-CS','RO','Caras-Severin',NULL,0),(3110,'RO-CT','RO','Constanta',NULL,0),(3111,'RO-CV','RO','Covasna',NULL,0),(3112,'RO-DI','RO','Dimbovita',NULL,0),(3113,'RO-DO','RO','Dolj',NULL,0),(3114,'RO-GG','RO','Giurgiu',NULL,0),(3115,'RO-GJ','RO','Gorj',NULL,0),(3116,'RO-GL','RO','Galati',NULL,0),(3117,'RO-HA','RO','Harghita',NULL,0),(3118,'RO-HU','RO','Hunedoara',NULL,0),(3119,'RO-IF','RO','Ilfov',NULL,0),(3120,'RO-IM','RO','Ialomita',NULL,0),(3121,'RO-IS','RO','Iasi',NULL,0),(3122,'RO-MA','RO','Maramures',NULL,0),(3123,'RO-ME','RO','Mehedinti',NULL,0),(3124,'RO-MU','RO','Mures',NULL,0),(3125,'RO-NE','RO','Neamt',NULL,0),(3126,'RO-OL','RO','Olt',NULL,0),(3127,'RO-PR','RO','Prahova',NULL,0),(3128,'RO-SI','RO','Timis',NULL,0),(3129,'RO-SJ','RO','Salaj',NULL,0),(3130,'RO-SM','RO','Satu Mare',NULL,0),(3131,'RO-SO','RO','Sibiu',NULL,0),(3132,'RO-SU','RO','Suceava',NULL,0),(3133,'RO-TE','RO','Teleorman',NULL,0),(3134,'RO-TU','RO','Tulcea',NULL,0),(3135,'RO-VA','RO','Vaslui',NULL,0),(3136,'RO-VI','RO','Vilcea',NULL,0),(3137,'RO-VR','RO','Vrancea',NULL,0),(3138,'RS-00','RS','Belgrade',NULL,0),(3139,'RS-14','RS','Borski okrug',NULL,0),(3140,'RS-11','RS','Braničevski okrug',NULL,0),(3141,'RS-23','RS','Jablanički okrug',NULL,0),(3142,'RS-06','RS','Južnobanatski okrug',NULL,0),(3143,'RS-04','RS','Južnobanatski okrug',NULL,0),(3144,'RS-09','RS','Kolubarski okrug',NULL,0),(3145,'RS-25','RS','Kosovski okrug',NULL,0),(3146,'RS-28','RS','Kosovsko-Mitrovački okrug',NULL,0),(3147,'RS-29','RS','Kosovsko-Pomoravski okrug',NULL,0),(3148,'RS-08','RS','Mačvanski okrug',NULL,0),(3149,'RS-17','RS','Moravički okrug',NULL,0),(3150,'RS-20','RS','Nišavski okrug',NULL,0),(3151,'RS-26','RS','Pećki okrug',NULL,0),(3152,'RS-22','RS','Pirotski okrug',NULL,0),(3153,'RS-10','RS','Podunavski okrug',NULL,0),(3154,'RS-13','RS','Pomoravski okrug',NULL,0),(3155,'RS-27','RS','Prizrenski okrug',NULL,0),(3156,'RS-24','RS','Pčinjski okrug',NULL,0),(3157,'RS-19','RS','Rasinski okrug',NULL,0),(3158,'RS-18','RS','Raška okrug',NULL,0),(3159,'RS-03','RS','Severnobanatski okrug',NULL,0),(3160,'RS-01','RS','Severnobački okrug',NULL,0),(3161,'RS-02','RS','Srednjebanatski okrug',NULL,0),(3162,'RS-07','RS','Sremski okrug',NULL,0),(3163,'RS-21','RS','Toplièki okrug',NULL,0),(3164,'RS-15','RS','Zajeèarski okrug',NULL,0),(3165,'RS-05','RS','Zapadnobaèki okrug',NULL,0),(3166,'RS-16','RS','Zlatiborski okrug',NULL,0),(3167,'RS-12','RS','Šumadijski okrug',NULL,0),(3168,'RU-AD','RU','Adygeya',NULL,0),(3169,'RU-AGB','RU','Aga Buryatia',NULL,0),(3170,'RU-AL','RU','Altai Republic',NULL,0),(3171,'RU-ALT','RU','Altai Krai',NULL,0),(3172,'RU-AMU','RU','Amur',NULL,0),(3173,'RU-ARK','RU','Arkhangelsk',NULL,0),(3174,'RU-AST','RU','Astrakhan',NULL,0),(3175,'RU-BA','RU','Bashkortostan',NULL,0),(3176,'RU-BEL','RU','Belgorod',NULL,0),(3177,'RU-BRY','RU','Bryansk',NULL,0),(3178,'RU-BU','RU','Buryatia',NULL,0),(3179,'RU-CE','RU','Chechnya',NULL,0),(3180,'RU-CHE','RU','Chelyabinsk',NULL,0),(3181,'RU-CHI','RU','Chita',NULL,0),(3182,'RU-CHU','RU','Chukotka',NULL,0),(3183,'RU-CU','RU','Chuvashia',NULL,0),(3184,'RU-DA','RU','Dagestan',NULL,0),(3185,'RU-EVE','RU','Evenkia',NULL,0),(3186,'RU-IN','RU','Ingushetia',NULL,0),(3187,'RU-IRK','RU','Irkutsk',NULL,0),(3188,'RU-IVA','RU','Ivanovo',NULL,0),(3189,'RU-KAM','RU','Kamchatka',NULL,0),(3190,'RU-KB','RU','Kabardino-Balkaria',NULL,0),(3191,'RU-KC','RU','Karachay-Cherkessia',NULL,0),(3192,'RU-KDA','RU','Krasnodar',NULL,0),(3193,'RU-KEM','RU','Kemerovo',NULL,0),(3194,'RU-KGD','RU','Kaliningrad',NULL,0),(3195,'RU-KGN','RU','Kurgan',NULL,0),(3196,'RU-KHA','RU','Khabarovsk',NULL,0),(3197,'RU-KHM','RU','Khantia-Mansia',NULL,0),(3198,'RU-KIR','RU','Kirov',NULL,0),(3199,'RU-KK','RU','Khakassia',NULL,0),(3200,'RU-KL','RU','Kalmykia',NULL,0),(3201,'RU-KLU','RU','Kaluga',NULL,0),(3202,'RU-KO','RU','Komi',NULL,0),(3203,'RU-KOP','RU','Permyakia',NULL,0),(3204,'RU-KOR','RU','Koryakia',NULL,0),(3205,'RU-KOS','RU','Kostroma',NULL,0),(3206,'RU-KR','RU','Karelia',NULL,0),(3207,'RU-KRS','RU','Kursk',NULL,0),(3208,'RU-KYA','RU','Krasnoyarsk',NULL,0),(3209,'RU-LEN','RU','Leningrad',NULL,0),(3210,'RU-LIP','RU','Lipetsk',NULL,0),(3211,'RU-MAG','RU','Magadan',NULL,0),(3212,'RU-ME','RU','Mari El',NULL,0),(3213,'RU-MO','RU','Mordovia',NULL,0),(3214,'RU-MOS','RU','Moscow (Province)',NULL,0),(3215,'RU-MOW','RU','Moscow (City)',NULL,0),(3216,'RU-MUR','RU','Murmansk',NULL,0),(3217,'RU-NEN','RU','Nenetsia',NULL,0),(3218,'RU-NGR','RU','Novgorod',NULL,0),(3219,'RU-NIZ','RU','Nizhny Novgorod',NULL,0),(3220,'RU-NVS','RU','Novosibirsk',NULL,0),(3221,'RU-OMS','RU','Omsk',NULL,0),(3222,'RU-ORE','RU','Orenburg',NULL,0),(3223,'RU-ORL','RU','Oryol',NULL,0),(3224,'RU-PER','RU','Perm',NULL,0),(3225,'RU-PNZ','RU','Penza',NULL,0),(3226,'RU-PRI','RU','Primorsky',NULL,0),(3227,'RU-PSK','RU','Pskov',NULL,0),(3228,'RU-ROS','RU','Rostov',NULL,0),(3229,'RU-RYA','RU','Ryazan',NULL,0),(3230,'RU-SA','RU','Sakha',NULL,0),(3231,'RU-SAK','RU','Sakhalin',NULL,0),(3232,'RU-SAM','RU','Samara',NULL,0),(3233,'RU-SAR','RU','Saratov',NULL,0),(3234,'RU-SE','RU','North Ossetia',NULL,0),(3235,'RU-SMO','RU','Smolensk',NULL,0),(3236,'RU-SPE','RU','St. Petersburg',NULL,0),(3237,'RU-STA','RU','Stavropol',NULL,0),(3238,'RU-SVE','RU','Sverdlovsk',NULL,0),(3239,'RU-TA','RU','Tatarstan',NULL,0),(3240,'RU-TAM','RU','Tambov',NULL,0),(3241,'RU-TAY','RU','Taymyria',NULL,0),(3242,'RU-TOM','RU','Tomsk',NULL,0),(3243,'RU-TUL','RU','Tula',NULL,0),(3244,'RU-TVE','RU','Tver',NULL,0),(3245,'RU-TY','RU','Tuva',NULL,0),(3246,'RU-TYU','RU','Tyumen',NULL,0),(3247,'RU-UD','RU','Udmurtia',NULL,0),(3248,'RU-ULY','RU','Ulynovsk',NULL,0),(3249,'RU-UOB','RU','Ust-Orda Buryatia',NULL,0),(3250,'RU-VGG','RU','Volgograd',NULL,0),(3251,'RU-VLA','RU','Vladimir',NULL,0),(3252,'RU-VLG','RU','Vologda',NULL,0),(3253,'RU-VOR','RU','Voronezh',NULL,0),(3254,'RU-YAN','RU','Yamalia',NULL,0),(3255,'RU-YAR','RU','Yaroslavl',NULL,0),(3256,'RU-YEV','RU','Jewish Oblast',NULL,0),(3257,'RW-BU','RW','Butare',NULL,0),(3258,'RW-BY','RW','Byumba',NULL,0),(3259,'RW-CY','RW','Cyangugu',NULL,0),(3260,'RW-GK','RW','Gikongoro',NULL,0),(3261,'RW-GS','RW','Gisenyi',NULL,0),(3262,'RW-GT','RW','Gitarama',NULL,0),(3263,'RW-KG','RW','Kibungo',NULL,0),(3264,'RW-KR','RW','Kigali Rurale',NULL,0),(3265,'RW-KV','RW','Kigali-ville',NULL,0),(3266,'RW-KY','RW','Kibuye',NULL,0),(3267,'RW-RU','RW','Ruhengeri',NULL,0),(3268,'RW-UM','RW','Umutara',NULL,0),(3269,'SA-AQ','SA','Ash Sharqiyah (Eastern Province)',NULL,0),(3270,'SA-AS','SA','\'Asir',NULL,0),(3271,'SA-BH','SA','Al Bahah',NULL,0),(3272,'SA-HL','SA','Ha\'il',NULL,0),(3273,'SA-HS','SA','Al Hudud ash Shamaliyah',NULL,0),(3274,'SA-JF','SA','Al Jawf',NULL,0),(3275,'SA-JZ','SA','Jizan',NULL,0),(3276,'SA-MD','SA','Al Madinah',NULL,0),(3277,'SA-ML','SA','Makkah',NULL,0),(3278,'SA-NR','SA','Najran',NULL,0),(3279,'SA-QS','SA','Al Qasim',NULL,0),(3280,'SA-RD','SA','Ar Riyad',NULL,0),(3281,'SA-TB','SA','Tabuk',NULL,0),(3282,'SB-CE','SB','Central',NULL,0),(3283,'SB-CH','SB','Choiseul',NULL,0),(3284,'SB-GC','SB','Guadalcanal',NULL,0),(3285,'SB-HO','SB','Honiara',NULL,0),(3286,'SB-IS','SB','Isabel',NULL,0),(3287,'SB-MK','SB','Makira',NULL,0),(3288,'SB-ML','SB','Malaita',NULL,0),(3289,'SB-RB','SB','Rennell and Bellona',NULL,0),(3290,'SB-TM','SB','Temotu',NULL,0),(3291,'SB-WE','SB','Western',NULL,0),(3292,'SC-AB','SC','Anse Boileau',NULL,0),(3293,'SC-AE','SC','Anse Etoile',NULL,0),(3294,'SC-AL','SC','Anse Louis',NULL,0),(3295,'SC-AP','SC','Anse aux Pins',NULL,0),(3296,'SC-AR','SC','Anse Royale',NULL,0),(3297,'SC-BA','SC','Bel Air',NULL,0),(3298,'SC-BL','SC','Baie Lazare',NULL,0),(3299,'SC-BO','SC','Bel Ombre',NULL,0),(3300,'SC-BS','SC','Baie Sainte Anne',NULL,0),(3301,'SC-BV','SC','Beau Vallon',NULL,0),(3302,'SC-CA','SC','Cascade',NULL,0),(3303,'SC-DG','SC','La Digue',NULL,0),(3304,'SC-GL','SC','Glacis',NULL,0),(3305,'SC-GM','SC','Grand\' Anse (on Mahe)',NULL,0),(3306,'SC-GP','SC','Grand\' Anse (on Praslin)',NULL,0),(3307,'SC-MB','SC','Mont Buxton',NULL,0),(3308,'SC-MF','SC','Mont Fleuri',NULL,0),(3309,'SC-PG','SC','Port Glaud',NULL,0),(3310,'SC-PL','SC','Plaisance',NULL,0),(3311,'SC-PR','SC','Pointe La Rue',NULL,0),(3312,'SC-RA','SC','La Riviere Anglaise',NULL,0),(3313,'SC-SL','SC','Saint Louis',NULL,0),(3314,'SC-TA','SC','Takamaka',NULL,0),(3315,'SD-ANB','SD','An Nil al Abyad',NULL,0),(3316,'SD-ANL','SD','A\'ali an Nil',NULL,0),(3317,'SD-ANZ','SD','An Nil al Azraq',NULL,0),(3318,'SD-ASH','SD','Ash Shamaliyah',NULL,0),(3319,'SD-BAM','SD','Al Bahr al Ahmar',NULL,0),(3320,'SD-BJA','SD','Bahr al Jabal',NULL,0),(3321,'SD-BRT','SD','Al Buhayrat',NULL,0),(3322,'SD-GBG','SD','Gharb Bahr al Ghazal',NULL,0),(3323,'SD-GDA','SD','Gharb Darfur',NULL,0),(3324,'SD-GIS','SD','Gharb al Istiwa\'iyah',NULL,0),(3325,'SD-GKU','SD','Gharb Kurdufan',NULL,0),(3326,'SD-JDA','SD','Janub Darfur',NULL,0),(3327,'SD-JKU','SD','Janub Kurdufan',NULL,0),(3328,'SD-JQL','SD','Junqali',NULL,0),(3329,'SD-JZR','SD','Al Jazirah',NULL,0),(3330,'SD-KRT','SD','Al Khartum',NULL,0),(3331,'SD-KSL','SD','Kassala',NULL,0),(3332,'SD-NNL','SD','Nahr an Nil',NULL,0),(3333,'SD-QDR','SD','Al Qadarif',NULL,0),(3334,'SD-SBG','SD','Shamal Bahr al Ghazal',NULL,0),(3335,'SD-SDA','SD','Shamal Darfur',NULL,0),(3336,'SD-SIS','SD','Sharq al Istiwa\'iyah',NULL,0),(3337,'SD-SKU','SD','Shamal Kurdufan',NULL,0),(3338,'SD-SNR','SD','Sinnar',NULL,0),(3339,'SD-WDH','SD','Al Wahdah',NULL,0),(3340,'SD-WRB','SD','Warab',NULL,0),(3341,'SH-A','SH','Ascension',NULL,0),(3342,'SH-S','SH','Saint Helena',NULL,0),(3343,'SH-T','SH','Tristan da Cunha',NULL,0),(3344,'SK-BA','SK','Banskobystricky',NULL,0),(3345,'SK-BR','SK','Bratislavsky',NULL,0),(3346,'SK-KO','SK','Kosicky',NULL,0),(3347,'SK-NI','SK','Nitriansky',NULL,0),(3348,'SK-PR','SK','Presovsky',NULL,0),(3349,'SK-TC','SK','Trenciansky',NULL,0),(3350,'SK-TV','SK','Trnavsky',NULL,0),(3351,'SK-ZI','SK','Zilinsky',NULL,0),(3352,'SL-E','SL','Eastern',NULL,0),(3353,'SL-N','SL','Northern',NULL,0),(3354,'SL-S','SL','Southern',NULL,0),(3355,'SL-W','SL','Western',NULL,0),(3356,'SM-AC','SM','Acquaviva',NULL,0),(3357,'SM-BM','SM','Borgo Maggiore',NULL,0),(3358,'SM-CH','SM','Chiesanuova',NULL,0),(3359,'SM-DO','SM','Domagnano',NULL,0),(3360,'SM-FA','SM','Faetano',NULL,0),(3361,'SM-FI','SM','Fiorentino',NULL,0),(3362,'SM-MO','SM','Montegiardino',NULL,0),(3363,'SM-SE','SM','Serravalle',NULL,0),(3364,'SM-SM','SM','Citta di San Marino',NULL,0),(3365,'SN-DA','SN','Dakar',NULL,0),(3366,'SN-DI','SN','Diourbel',NULL,0),(3367,'SN-FA','SN','Fatick',NULL,0),(3368,'SN-KA','SN','Kaolack',NULL,0),(3369,'SN-KO','SN','Kolda',NULL,0),(3370,'SN-LO','SN','Louga',NULL,0),(3371,'SN-MA','SN','Matam',NULL,0),(3372,'SN-SL','SN','Saint-Louis',NULL,0),(3373,'SN-TA','SN','Tambacounda',NULL,0),(3374,'SN-TH','SN','Thies',NULL,0),(3375,'SN-ZI','SN','Ziguinchor',NULL,0),(3376,'SO-AW','SO','Awdal',NULL,0),(3377,'SO-BK','SO','Bakool',NULL,0),(3378,'SO-BN','SO','Banaadir',NULL,0),(3379,'SO-BR','SO','Bari',NULL,0),(3380,'SO-BY','SO','Bay',NULL,0),(3381,'SO-GA','SO','Galguduud',NULL,0),(3382,'SO-GE','SO','Gedo',NULL,0),(3383,'SO-HI','SO','Hiiraan',NULL,0),(3384,'SO-JD','SO','Jubbada Dhexe',NULL,0),(3385,'SO-JH','SO','Jubbada Hoose',NULL,0),(3386,'SO-MU','SO','Mudug',NULL,0),(3387,'SO-NU','SO','Nugaal',NULL,0),(3388,'SO-SA','SO','Sanaag',NULL,0),(3389,'SO-SD','SO','Shabeellaha Dhexe',NULL,0),(3390,'SO-SH','SO','Shabeellaha Hoose',NULL,0),(3391,'SO-SL','SO','Sool',NULL,0),(3392,'SO-TO','SO','Togdheer',NULL,0),(3393,'SO-WG','SO','Woqooyi Galbeed',NULL,0),(3394,'SR-BR','SR','Brokopondo',NULL,0),(3395,'SR-CM','SR','Commewijne',NULL,0),(3396,'SR-CR','SR','Coronie',NULL,0),(3397,'SR-MA','SR','Marowijne',NULL,0),(3398,'SR-NI','SR','Nickerie',NULL,0),(3399,'SR-PA','SR','Para',NULL,0),(3400,'SR-PM','SR','Paramaribo',NULL,0),(3401,'SR-SA','SR','Saramacca',NULL,0),(3402,'SR-SI','SR','Sipaliwini',NULL,0),(3403,'SR-WA','SR','Wanica',NULL,0),(3404,'ST-P','ST','Principe',NULL,0),(3405,'ST-S','ST','Sao Tome',NULL,0),(3406,'SV-AH','SV','Ahuachapan',NULL,0),(3407,'SV-CA','SV','Cabanas',NULL,0),(3408,'SV-CH','SV','Chalatenango',NULL,0),(3409,'SV-CU','SV','Cuscatlan',NULL,0),(3410,'SV-LB','SV','La Libertad',NULL,0),(3411,'SV-MO','SV','Morazan',NULL,0),(3412,'SV-PZ','SV','La Paz',NULL,0),(3413,'SV-SA','SV','Santa Ana',NULL,0),(3414,'SV-SM','SV','San Miguel',NULL,0),(3415,'SV-SO','SV','Sonsonate',NULL,0),(3416,'SV-SS','SV','San Salvador',NULL,0),(3417,'SV-SV','SV','San Vicente',NULL,0),(3418,'SV-UN','SV','La Union',NULL,0),(3419,'SV-US','SV','Usulutan',NULL,0),(3420,'SE-BL','SE','Blekinge',NULL,0),(3421,'SE-DA','SE','Dalama',NULL,0),(3422,'SE-GA','SE','Gavleborg',NULL,0),(3423,'SE-GO','SE','Gotland',NULL,0),(3424,'SE-HA','SE','Halland',NULL,0),(3425,'SE-JA','SE','Jamtland',NULL,0),(3426,'SE-JO','SE','Jonkping',NULL,0),(3427,'SE-KA','SE','Kalmar',NULL,0),(3428,'SE-KR','SE','Kronoberg',NULL,0),(3429,'SE-NO','SE','Norrbotten',NULL,0),(3430,'SE-OG','SE','Ostergotland',NULL,0),(3431,'SE-OR','SE','Orebro',NULL,0),(3432,'SE-SK','SE','Skane',NULL,0),(3433,'SE-SO','SE','Sodermanland',NULL,0),(3434,'SE-ST','SE','Stockholm',NULL,0),(3435,'SE-UP','SE','Uppdala',NULL,0),(3436,'SE-VB','SE','Vasterbotten',NULL,0),(3437,'SE-VG','SE','Vastra Gotaland',NULL,0),(3438,'SE-VL','SE','Varmland',NULL,0),(3439,'SE-VM','SE','Vastmanland',NULL,0),(3440,'SE-VN','SE','Vasternorrland',NULL,0),(3441,'SY-DA','SY','Dara',NULL,0),(3442,'SY-DI','SY','Dimashq',NULL,0),(3443,'SY-DZ','SY','Dayr az Zawr',NULL,0),(3444,'SY-HA','SY','Al Hasakah',NULL,0),(3445,'SY-HI','SY','Hims',NULL,0),(3446,'SY-HL','SY','Halab',NULL,0),(3447,'SY-HM','SY','Hamah',NULL,0),(3448,'SY-ID','SY','Idlib',NULL,0),(3449,'SY-LA','SY','Al Ladhiqiyah',NULL,0),(3450,'SY-QU','SY','Al Qunaytirah',NULL,0),(3451,'SY-RD','SY','Rif Dimashq',NULL,0),(3452,'SY-RQ','SY','Ar Raqqah',NULL,0),(3453,'SY-SU','SY','As Suwayda',NULL,0),(3454,'SY-TA','SY','Tartus',NULL,0),(3455,'SZ-H','SZ','Hhohho',NULL,0),(3456,'SZ-L','SZ','Lubombo',NULL,0),(3457,'SZ-M','SZ','Manzini',NULL,0),(3458,'SZ-S','SZ','Shishelweni',NULL,0),(3459,'TC-AC','TC','Ambergris Cays',NULL,0),(3460,'TC-DC','TC','Dellis Cay',NULL,0),(3461,'TC-EC','TC','East Caicos',NULL,0),(3462,'TC-FC','TC','French Cay',NULL,0),(3463,'TC-GT','TC','Grand Turk',NULL,0),(3464,'TC-LW','TC','Little Water Cay',NULL,0),(3465,'TC-MC','TC','Middle Caicos',NULL,0),(3466,'TC-NC','TC','North Caicos',NULL,0),(3467,'TC-PN','TC','Pine Cay',NULL,0),(3468,'TC-PR','TC','Providenciales',NULL,0),(3469,'TC-RC','TC','Parrot Cay',NULL,0),(3470,'TC-SC','TC','South Caicos',NULL,0),(3471,'TC-SL','TC','Salt Cay',NULL,0),(3472,'TC-WC','TC','West Caicos',NULL,0),(3473,'TD-BA','TD','Batha',NULL,0),(3474,'TD-BE','TD','Borkou-Ennedi-Tibesti',NULL,0),(3475,'TD-BI','TD','Biltine',NULL,0),(3476,'TD-CB','TD','Chari-Baguirmi',NULL,0),(3477,'TD-GU','TD','Guera',NULL,0),(3478,'TD-KA','TD','Kanem',NULL,0),(3479,'TD-LA','TD','Lac',NULL,0),(3480,'TD-LC','TD','Logone Occidental',NULL,0),(3481,'TD-LR','TD','Logone Oriental',NULL,0),(3482,'TD-MC','TD','Moyen-Chari',NULL,0),(3483,'TD-MK','TD','Mayo-Kebbi',NULL,0),(3484,'TD-OU','TD','Ouaddai',NULL,0),(3485,'TD-SA','TD','Salamat',NULL,0),(3486,'TD-TA','TD','Tandjile',NULL,0),(3487,'TF-A','TF','Ile Amsterdam',NULL,0),(3488,'TF-C','TF','Iles Crozet',NULL,0),(3489,'TF-D','TF','Adelie Land',NULL,0),(3490,'TF-K','TF','Iles Kerguelen',NULL,0),(3491,'TF-P','TF','Ile Saint-Paul',NULL,0),(3492,'TG-C','TG','Centrale',NULL,0),(3493,'TG-K','TG','Kara',NULL,0),(3494,'TG-M','TG','Maritime',NULL,0),(3495,'TG-P','TG','Plateaux',NULL,0),(3496,'TG-S','TG','Savanes',NULL,0),(3497,'TH-10','TH','Bangkok',NULL,0),(3498,'TH-11','TH','Samut Prakan',NULL,0),(3499,'TH-12','TH','Nonthaburi',NULL,0),(3500,'TH-13','TH','Pathum Thani',NULL,0),(3501,'TH-14','TH','Phra Nakhon Si Ayutthaya',NULL,0),(3502,'TH-15','TH','Ang Thong',NULL,0),(3503,'TH-16','TH','Lop Buri',NULL,0),(3504,'TH-17','TH','Sing Buri',NULL,0),(3505,'TH-18','TH','Chai Nat',NULL,0),(3506,'TH-19','TH','Saraburi',NULL,0),(3507,'TH-20','TH','Chon Buri',NULL,0),(3508,'TH-21','TH','Rayong',NULL,0),(3509,'TH-22','TH','Chanthaburi',NULL,0),(3510,'TH-23','TH','Trat',NULL,0),(3511,'TH-24','TH','Chachoengsao',NULL,0),(3512,'TH-25','TH','Prachin Buri',NULL,0),(3513,'TH-26','TH','Nakhon Nayok',NULL,0),(3514,'TH-27','TH','Sa Kaeo',NULL,0),(3515,'TH-30','TH','Nakhon Ratchasima',NULL,0),(3516,'TH-31','TH','Buri Ram',NULL,0),(3517,'TH-32','TH','Surin',NULL,0),(3518,'TH-33','TH','Si Sa Ket',NULL,0),(3519,'TH-34','TH','Ubon Ratchathani',NULL,0),(3520,'TH-35','TH','Yasothon',NULL,0),(3521,'TH-36','TH','Chaiyaphum',NULL,0),(3522,'TH-37','TH','Amnat Charoen',NULL,0),(3523,'TH-39','TH','Nong Bua Lam Phu',NULL,0),(3524,'TH-40','TH','Khon Kaen',NULL,0),(3525,'TH-41','TH','Udon Thani',NULL,0),(3526,'TH-42','TH','Loei',NULL,0),(3527,'TH-43','TH','Nong Khai',NULL,0),(3528,'TH-44','TH','Maha Sarakham',NULL,0),(3529,'TH-45','TH','Roi Et',NULL,0),(3530,'TH-46','TH','Kalasin',NULL,0),(3531,'TH-47','TH','Sakon Nakhon',NULL,0),(3532,'TH-48','TH','Nakhon Phanom',NULL,0),(3533,'TH-49','TH','Mukdahan',NULL,0),(3534,'TH-50','TH','Chiang Mai',NULL,0),(3535,'TH-51','TH','Lamphun',NULL,0),(3536,'TH-52','TH','Lampang',NULL,0),(3537,'TH-53','TH','Uttaradit',NULL,0),(3538,'TH-54','TH','Phrae',NULL,0),(3539,'TH-55','TH','Nan',NULL,0),(3540,'TH-56','TH','Phayao',NULL,0),(3541,'TH-57','TH','Chiang Rai',NULL,0),(3542,'TH-58','TH','Mae Hong Son',NULL,0),(3543,'TH-60','TH','Nakhon Sawan',NULL,0),(3544,'TH-61','TH','Uthai Thani',NULL,0),(3545,'TH-62','TH','Kamphaeng Phet',NULL,0),(3546,'TH-63','TH','Tak',NULL,0),(3547,'TH-64','TH','Sukhothai',NULL,0),(3548,'TH-65','TH','Phitsanulok',NULL,0),(3549,'TH-66','TH','Phichit',NULL,0),(3550,'TH-70','TH','Ratchaburi',NULL,0),(3551,'TH-71','TH','Kanchanaburi',NULL,0),(3552,'TH-72','TH','Suphanburi',NULL,0),(3553,'TH-73','TH','Nakhon Pathom',NULL,0),(3554,'TH-74','TH','Samut Sakhon',NULL,0),(3555,'TH-75','TH','Samut Songkhram',NULL,0),(3556,'TH-76','TH','Phetchabun',NULL,0),(3557,'TH-77','TH','Prachuap Khiri Khan',NULL,0),(3558,'TH-78','TH','Phetchaburi',NULL,0),(3559,'TH-80','TH','Nakhon Si Thammarat',NULL,0),(3560,'TH-81','TH','Krabi',NULL,0),(3561,'TH-82','TH','Phang Nga',NULL,0),(3562,'TH-83','TH','Phuket',NULL,0),(3563,'TH-84','TH','Surat Thani',NULL,0),(3564,'TH-85','TH','Ranong',NULL,0),(3565,'TH-86','TH','Chumpon',NULL,0),(3566,'TH-90','TH','Songkhla',NULL,0),(3567,'TH-91','TH','Satun',NULL,0),(3568,'TH-92','TH','Trang',NULL,0),(3569,'TH-93','TH','Phattalung',NULL,0),(3570,'TH-94','TH','Pattani',NULL,0),(3571,'TH-95','TH','Yala',NULL,0),(3572,'TH-96','TH','Narathiwat',NULL,0),(3573,'TH-S','TH','Pattaya',NULL,0),(3574,'TJ-GB','TJ','Gorno-Badakhstan',NULL,0),(3575,'TJ-KT','TJ','Khatlon',NULL,0),(3576,'TJ-SU','TJ','Sughd',NULL,0),(3577,'TK-A','TK','Atafu',NULL,0),(3578,'TK-F','TK','Fakaofo',NULL,0),(3579,'TK-N','TK','Nukunonu',NULL,0),(3580,'TL-AL','TL','Aileu',NULL,0),(3581,'TL-AN','TL','Ainaro',NULL,0),(3582,'TL-BA','TL','Baucau',NULL,0),(3583,'TL-BO','TL','Bobonaro',NULL,0),(3584,'TL-CO','TL','Cova Lima',NULL,0),(3585,'TL-DI','TL','Dili',NULL,0),(3586,'TL-ER','TL','Ermera',NULL,0),(3587,'TL-LA','TL','Lautem',NULL,0),(3588,'TL-LI','TL','Liquica',NULL,0),(3589,'TL-MF','TL','Manufahi',NULL,0),(3590,'TL-MT','TL','Manatuto',NULL,0),(3591,'TL-OE','TL','Oecussi',NULL,0),(3592,'TL-VI','TL','Viqueque',NULL,0),(3593,'TM-A','TM','Ahal Welayaty',NULL,0),(3594,'TM-B','TM','Balkan Welayaty',NULL,0),(3595,'TM-D','TM','Dashhowuz Welayaty',NULL,0),(3596,'TM-L','TM','Lebap Welayaty',NULL,0),(3597,'TM-M','TM','Mary Welayaty',NULL,0),(3598,'TN-AR','TN','Ariana',NULL,0),(3599,'TN-BA','TN','Ben Arous',NULL,0),(3600,'TN-BI','TN','Bizerte',NULL,0),(3601,'TN-BJ','TN','Beja',NULL,0),(3602,'TN-GB','TN','Gabes',NULL,0),(3603,'TN-GF','TN','Gafsa',NULL,0),(3604,'TN-JE','TN','Jendouba',NULL,0),(3605,'TN-KB','TN','Kebili',NULL,0),(3606,'TN-KF','TN','Kef',NULL,0),(3607,'TN-KR','TN','Kairouan',NULL,0),(3608,'TN-KS','TN','Kasserine',NULL,0),(3609,'TN-ME','TN','Medenine',NULL,0),(3610,'TN-MH','TN','Mahdia',NULL,0),(3611,'TN-MN','TN','Manouba',NULL,0),(3612,'TN-MO','TN','Monastir',NULL,0),(3613,'TN-NA','TN','Nabeul',NULL,0),(3614,'TN-SD','TN','Sidi',NULL,0),(3615,'TN-SF','TN','Sfax',NULL,0),(3616,'TN-SL','TN','Siliana',NULL,0),(3617,'TN-SO','TN','Sousse',NULL,0),(3618,'TN-TA','TN','Tataouine',NULL,0),(3619,'TN-TO','TN','Tozeur',NULL,0),(3620,'TN-TU','TN','Tunis',NULL,0),(3621,'TN-ZA','TN','Zaghouan',NULL,0),(3622,'TO-H','TO','Ha\'apai',NULL,0),(3623,'TO-T','TO','Tongatapu',NULL,0),(3624,'TO-V','TO','Vava\'u',NULL,0),(3625,'TR-ADA','TR','Adana',NULL,0),(3626,'TR-ADI','TR','Adiyaman',NULL,0),(3627,'TR-AFY','TR','Afyonkarahisar',NULL,0),(3628,'TR-AGR','TR','Agri',NULL,0),(3629,'TR-AKS','TR','Aksaray',NULL,0),(3630,'TR-AMA','TR','Amasya',NULL,0),(3631,'TR-ANK','TR','Ankara',NULL,0),(3632,'TR-ANT','TR','Antalya',NULL,0),(3633,'TR-ARD','TR','Ardahan',NULL,0),(3634,'TR-ART','TR','Artvin',NULL,0),(3635,'TR-AYI','TR','Aydin',NULL,0),(3636,'TR-BAL','TR','Balikesir',NULL,0),(3637,'TR-BAR','TR','Bartin',NULL,0),(3638,'TR-BAT','TR','Batman',NULL,0),(3639,'TR-BAY','TR','Bayburt',NULL,0),(3640,'TR-BIL','TR','Bilecik',NULL,0),(3641,'TR-BIN','TR','Bingol',NULL,0),(3642,'TR-BIT','TR','Bitlis',NULL,0),(3643,'TR-BOL','TR','Bolu',NULL,0),(3644,'TR-BRD','TR','Burdur',NULL,0),(3645,'TR-BRS','TR','Bursa',NULL,0),(3646,'TR-CKL','TR','Canakkale',NULL,0),(3647,'TR-CKR','TR','Cankiri',NULL,0),(3648,'TR-COR','TR','Corum',NULL,0),(3649,'TR-DEN','TR','Denizli',NULL,0),(3650,'TR-DIY','TR','Diyarbakir',NULL,0),(3651,'TR-DUZ','TR','Duzce',NULL,0),(3652,'TR-EDI','TR','Edirne',NULL,0),(3653,'TR-ELA','TR','Elazig',NULL,0),(3654,'TR-ESK','TR','Eskisehir',NULL,0),(3655,'TR-EZC','TR','Erzincan',NULL,0),(3656,'TR-EZR','TR','Erzurum',NULL,0),(3657,'TR-GAZ','TR','Gaziantep',NULL,0),(3658,'TR-GIR','TR','Giresun',NULL,0),(3659,'TR-GMS','TR','Gumushane',NULL,0),(3660,'TR-HKR','TR','Hakkari',NULL,0),(3661,'TR-HTY','TR','Hatay',NULL,0),(3662,'TR-IGD','TR','Igdir',NULL,0),(3663,'TR-ISP','TR','Isparta',NULL,0),(3664,'TR-IST','TR','Istanbul',NULL,0),(3665,'TR-IZM','TR','Izmir',NULL,0),(3666,'TR-KAH','TR','Kahramanmaras',NULL,0),(3667,'TR-KAS','TR','Kastamonu',NULL,0),(3668,'TR-KAY','TR','Kayseri',NULL,0),(3669,'TR-KLR','TR','Kirklareli',NULL,0),(3670,'TR-KLS','TR','Kilis',NULL,0),(3671,'TR-KOC','TR','Kocaeli',NULL,0),(3672,'TR-KON','TR','Konya',NULL,0),(3673,'TR-KRB','TR','Karabuk',NULL,0),(3674,'TR-KRH','TR','Kirsehir',NULL,0),(3675,'TR-KRK','TR','Kirikkale',NULL,0),(3676,'TR-KRM','TR','Karaman',NULL,0),(3677,'TR-KRS','TR','Kars',NULL,0),(3678,'TR-KUT','TR','Kutahya',NULL,0),(3679,'TR-MAL','TR','Malatya',NULL,0),(3680,'TR-MAN','TR','Manisa',NULL,0),(3681,'TR-MAR','TR','Mardin',NULL,0),(3682,'TR-MER','TR','Mersin',NULL,0),(3683,'TR-MUG','TR','Mugla',NULL,0),(3684,'TR-MUS','TR','Mus',NULL,0),(3685,'TR-NEV','TR','Nevsehir',NULL,0),(3686,'TR-NIG','TR','Nigde',NULL,0),(3687,'TR-ORD','TR','Ordu',NULL,0),(3688,'TR-OSM','TR','Osmaniye',NULL,0),(3689,'TR-RIZ','TR','Rize',NULL,0),(3690,'TR-SAK','TR','Sakarya',NULL,0),(3691,'TR-SAM','TR','Samsun',NULL,0),(3692,'TR-SAN','TR','Sanliurfa',NULL,0),(3693,'TR-SII','TR','Siirt',NULL,0),(3694,'TR-SIN','TR','Sinop',NULL,0),(3695,'TR-SIR','TR','Sirnak',NULL,0),(3696,'TR-SIV','TR','Sivas',NULL,0),(3697,'TR-TEL','TR','Tekirdag',NULL,0),(3698,'TR-TOK','TR','Tokat',NULL,0),(3699,'TR-TRA','TR','Trabzon',NULL,0),(3700,'TR-TUN','TR','Tunceli',NULL,0),(3701,'TR-USK','TR','Usak',NULL,0),(3702,'TR-VAN','TR','Van',NULL,0),(3703,'TR-YAL','TR','Yalova',NULL,0),(3704,'TR-YOZ','TR','Yozgat',NULL,0),(3705,'TR-ZON','TR','Zonguldak',NULL,0),(3706,'TT-AR','TT','Arima',NULL,0),(3707,'TT-CH','TT','Chaguanas',NULL,0),(3708,'TT-CT','TT','Couva/Tabaquite/Talparo',NULL,0),(3709,'TT-DM','TT','Diego Martin',NULL,0),(3710,'TT-MR','TT','Mayaro/Rio Claro',NULL,0),(3711,'TT-PD','TT','Penal/Debe',NULL,0),(3712,'TT-PF','TT','Point Fortin',NULL,0),(3713,'TT-PS','TT','Port of Spain',NULL,0),(3714,'TT-PT','TT','Princes Town',NULL,0),(3715,'TT-SF','TT','San Fernando',NULL,0),(3716,'TT-SG','TT','Sangre Grande',NULL,0),(3717,'TT-SI','TT','Siparia',NULL,0),(3718,'TT-SL','TT','San Juan/Laventille',NULL,0),(3719,'TT-TO','TT','Tobago',NULL,0),(3720,'TT-TP','TT','Tunapuna/Piarco',NULL,0),(3721,'TV-FUN','TV','Funafuti',NULL,0),(3722,'TV-NFT','TV','Nukufetau',NULL,0),(3723,'TV-NLK','TV','Niulakita',NULL,0),(3724,'TV-NLL','TV','Nukulaelae',NULL,0),(3725,'TV-NME','TV','Nanumea',NULL,0),(3726,'TV-NMG','TV','Nanumanga',NULL,0),(3727,'TV-NTO','TV','Niutao',NULL,0),(3728,'TV-NUI','TV','Nui',NULL,0),(3729,'TV-VAI','TV','Vaitupu',NULL,0),(3730,'TW-CC','TW','Chia-i city',NULL,0),(3731,'TW-CH','TW','Chang-hua',NULL,0),(3732,'TW-CI','TW','Chia-i',NULL,0),(3733,'TW-CL','TW','Chi-lung',NULL,0),(3734,'TW-HC','TW','Hsin-chu',NULL,0),(3735,'TW-HL','TW','Hua-lien',NULL,0),(3736,'TW-HS','TW','Hsin-chu',NULL,0),(3737,'TW-IL','TW','I-lan',NULL,0),(3738,'TW-KC','TW','Kao-hsiung city',NULL,0),(3739,'TW-KH','TW','Kao-hsiung county',NULL,0),(3740,'TW-KM','TW','Kin-men',NULL,0),(3741,'TW-LC','TW','Lien-chiang',NULL,0),(3742,'TW-ML','TW','Miao-li',NULL,0),(3743,'TW-NT','TW','Nan-t\'ou',NULL,0),(3744,'TW-PH','TW','P\'eng-hu',NULL,0),(3745,'TW-PT','TW','P\'ing-tung',NULL,0),(3746,'TW-TA','TW','T\'ai-nan',NULL,0),(3747,'TW-TC','TW','T\'ai-pei city',NULL,0),(3748,'TW-TG','TW','T\'ai-chung',NULL,0),(3749,'TW-TH','TW','T\'ai-chung',NULL,0),(3750,'TW-TN','TW','T\'ai-nan',NULL,0),(3751,'TW-TP','TW','T\'ai-pei county',NULL,0),(3752,'TW-TT','TW','T\'ai-tung',NULL,0),(3753,'TW-TY','TW','T\'ao-yuan',NULL,0),(3754,'TW-YL','TW','Yun-lin',NULL,0),(3755,'TZ-AR','TZ','Arusha',NULL,0),(3756,'TZ-DO','TZ','Dodoma',NULL,0),(3757,'TZ-DS','TZ','Dar es Salaam',NULL,0),(3758,'TZ-IR','TZ','Iringa',NULL,0),(3759,'TZ-KA','TZ','Kagera',NULL,0),(3760,'TZ-KI','TZ','Kigoma',NULL,0),(3761,'TZ-KJ','TZ','Kilimanjaro',NULL,0),(3762,'TZ-LN','TZ','Lindi',NULL,0),(3763,'TZ-MB','TZ','Mbeya',NULL,0),(3764,'TZ-MO','TZ','Morogoro',NULL,0),(3765,'TZ-MR','TZ','Mara',NULL,0),(3766,'TZ-MT','TZ','Mtwara',NULL,0),(3767,'TZ-MW','TZ','Mwanza',NULL,0),(3768,'TZ-MY','TZ','Manyara',NULL,0),(3769,'TZ-PN','TZ','Pemba North',NULL,0),(3770,'TZ-PS','TZ','Pemba South',NULL,0),(3771,'TZ-PW','TZ','Pwani',NULL,0),(3772,'TZ-RK','TZ','Rukwa',NULL,0),(3773,'TZ-RV','TZ','Ruvuma',NULL,0),(3774,'TZ-SH','TZ','Shinyanga',NULL,0),(3775,'TZ-SI','TZ','Singida',NULL,0),(3776,'TZ-TB','TZ','Tabora',NULL,0),(3777,'TZ-TN','TZ','Tanga',NULL,0),(3778,'TZ-ZC','TZ','Zanzibar Central/South',NULL,0),(3779,'TZ-ZN','TZ','Zanzibar North',NULL,0),(3780,'TZ-ZU','TZ','Zanzibar Urban/West',NULL,0),(3781,'UA-CH','UA','Chernihiv',NULL,0),(3782,'UA-CK','UA','Cherkasy',NULL,0),(3783,'UA-CR','UA','Crimea',NULL,0),(3784,'UA-CV','UA','Chernivtsi',NULL,0),(3785,'UA-DN','UA','Dnipropetrovs\'k',NULL,0),(3786,'UA-DO','UA','Donets\'k',NULL,0),(3787,'UA-IV','UA','Ivano-Frankivs\'k',NULL,0),(3788,'UA-KL','UA','Kharkiv Kherson',NULL,0),(3789,'UA-KM','UA','Khmel\'nyts\'kyy',NULL,0),(3790,'UA-KR','UA','Kirovohrad',NULL,0),(3791,'UA-KV','UA','Kiev',NULL,0),(3792,'UA-KY','UA','Kyyiv',NULL,0),(3793,'UA-LU','UA','Luhans\'k',NULL,0),(3794,'UA-LV','UA','L\'viv',NULL,0),(3795,'UA-MY','UA','Mykolayiv',NULL,0),(3796,'UA-OD','UA','Odesa',NULL,0),(3797,'UA-PO','UA','Poltava',NULL,0),(3798,'UA-RI','UA','Rivne',NULL,0),(3799,'UA-SE','UA','Sevastopol',NULL,0),(3800,'UA-SU','UA','Sumy',NULL,0),(3801,'UA-TE','UA','Ternopil\'',NULL,0),(3802,'UA-VI','UA','Vinnytsya',NULL,0),(3803,'UA-VO','UA','Volyn\'',NULL,0),(3804,'UA-ZA','UA','Zaporizhzhya',NULL,0),(3805,'UA-ZH','UA','Zhytomyr',NULL,0),(3806,'UA-ZK','UA','Zakarpattya',NULL,0),(3807,'UG-ADJ','UG','Adjumani',NULL,0),(3808,'UG-APC','UG','Apac',NULL,0),(3809,'UG-ARU','UG','Arua',NULL,0),(3810,'UG-BSH','UG','Bushenyi',NULL,0),(3811,'UG-BUG','UG','Bugiri',NULL,0),(3812,'UG-BUN','UG','Bundibugyo',NULL,0),(3813,'UG-BUS','UG','Busia',NULL,0),(3814,'UG-GUL','UG','Gulu',NULL,0),(3815,'UG-HOI','UG','Hoima',NULL,0),(3816,'UG-IGA','UG','Iganga',NULL,0),(3817,'UG-JIN','UG','Jinja',NULL,0),(3818,'UG-KAB','UG','Kaberamaido',NULL,0),(3819,'UG-KAL','UG','Kalangala',NULL,0),(3820,'UG-KAM','UG','Kamwenge',NULL,0),(3821,'UG-KAN','UG','Kanungu',NULL,0),(3822,'UG-KAR','UG','Kabarole',NULL,0),(3823,'UG-KAS','UG','Kasese',NULL,0),(3824,'UG-KAY','UG','Kayunga',NULL,0),(3825,'UG-KBA','UG','Kibaale',NULL,0),(3826,'UG-KBL','UG','Kabale',NULL,0),(3827,'UG-KIB','UG','Kiboga',NULL,0),(3828,'UG-KIS','UG','Kisoro',NULL,0),(3829,'UG-KIT','UG','Kitgum',NULL,0),(3830,'UG-KML','UG','Kamuli',NULL,0),(3831,'UG-KMP','UG','Kampala',NULL,0),(3832,'UG-KOT','UG','Kotido',NULL,0),(3833,'UG-KPC','UG','Kapchorwa',NULL,0),(3834,'UG-KTK','UG','Katakwi',NULL,0),(3835,'UG-KUM','UG','Kumi',NULL,0),(3836,'UG-KYE','UG','Kyenjojo',NULL,0),(3837,'UG-LIR','UG','Lira',NULL,0),(3838,'UG-LUW','UG','Luwero',NULL,0),(3839,'UG-MAS','UG','Masaka',NULL,0),(3840,'UG-MAY','UG','Mayuge',NULL,0),(3841,'UG-MBA','UG','Mbale',NULL,0),(3842,'UG-MBR','UG','Mbarara',NULL,0),(3843,'UG-MOY','UG','Moyo',NULL,0),(3844,'UG-MPI','UG','Mpigi',NULL,0),(3845,'UG-MRT','UG','Moroto',NULL,0),(3846,'UG-MSN','UG','Masindi',NULL,0),(3847,'UG-MUB','UG','Mubende',NULL,0),(3848,'UG-MUK','UG','Mukono',NULL,0),(3849,'UG-NAK','UG','Nakapiripirit',NULL,0),(3850,'UG-NEB','UG','Nebbi',NULL,0),(3851,'UG-NKS','UG','Nakasongola',NULL,0),(3852,'UG-NTU','UG','Ntungamo',NULL,0),(3853,'UG-PAD','UG','Pader',NULL,0),(3854,'UG-PAL','UG','Pallisa',NULL,0),(3855,'UG-RAK','UG','Rakai',NULL,0),(3856,'UG-RUK','UG','Rukungiri',NULL,0),(3857,'UG-SEM','UG','Sembabule',NULL,0),(3858,'UG-SIR','UG','Sironko',NULL,0),(3859,'UG-SOR','UG','Soroti',NULL,0),(3860,'UG-TOR','UG','Tororo',NULL,0),(3861,'UG-WAK','UG','Wakiso',NULL,0),(3862,'UG-YUM','UG','Yumbe',NULL,0),(3863,'UM-BI','UM','Baker Island',NULL,0),(3864,'UM-HI','UM','Howland Island',NULL,0),(3865,'UM-JA','UM','Johnston Atoll',NULL,0),(3866,'UM-JI','UM','Jarvis Island',NULL,0),(3867,'UM-KR','UM','Kingman Reef',NULL,0),(3868,'UM-MA','UM','Midway Atoll',NULL,0),(3869,'UM-NI','UM','Navassa Island',NULL,0),(3870,'UM-PA','UM','Palmyra Atoll',NULL,0),(3871,'UM-WI','UM','Wake Island',NULL,0),(3872,'AK','US','Alaska',NULL,0),(3873,'AL','US','Alabama',NULL,0),(3874,'AR','US','Arkansas',NULL,0),(3875,'AS','US','American Samoa',NULL,0),(3876,'AZ','US','Arizona',NULL,0),(3877,'CA','US','California',NULL,0),(3878,'CO','US','Colorado',NULL,0),(3879,'CT','US','Connecticut',NULL,0),(3880,'DC','US','District of Columbia',NULL,0),(3881,'DE','US','Delaware',NULL,0),(3882,'FL','US','Florida',NULL,0),(3883,'GA','US','Georgia',NULL,0),(3884,'GU','US','Guam',NULL,0),(3885,'HI','US','Hawaii',NULL,0),(3886,'IA','US','Iowa',NULL,0),(3887,'ID','US','Idaho',NULL,0),(3888,'IL','US','Illinois',NULL,0),(3889,'IN','US','Indiana',NULL,0),(3890,'KS','US','Kansas',NULL,0),(3891,'KY','US','Kentucky',NULL,0),(3892,'LA','US','Louisiana',NULL,0),(3893,'MA','US','Massachusetts',NULL,0),(3894,'MD','US','Maryland',NULL,0),(3895,'ME','US','Maine',NULL,0),(3896,'MI','US','Michigan',NULL,0),(3897,'MN','US','Minnesota',NULL,0),(3898,'MO','US','Missouri',NULL,0),(3899,'MP','US','Northern Mariana Islands',NULL,0),(3900,'MS','US','Mississippi',NULL,0),(3901,'MT','US','Montana',NULL,0),(3902,'NC','US','North Carolina',NULL,0),(3903,'ND','US','North Dakota',NULL,0),(3904,'NE','US','Nebraska',NULL,0),(3905,'NH','US','New Hampshire',NULL,0),(3906,'NJ','US','New Jersey',NULL,0),(3907,'NM','US','New Mexico',NULL,0),(3908,'NV','US','Nevada',NULL,0),(3909,'NY','US','New York',NULL,0),(3910,'OH','US','Ohio',NULL,0),(3911,'OK','US','Oklahoma',NULL,0),(3912,'OR','US','Oregon',NULL,0),(3913,'PA','US','Pennsylvania',NULL,0),(3914,'PR','US','Puerto Rico',NULL,0),(3915,'RI','US','Rhode Island',NULL,0),(3916,'SC','US','South Carolina',NULL,0),(3917,'SD','US','South Dakota',NULL,0),(3918,'TN','US','Tennessee',NULL,0),(3919,'TX','US','Texas',NULL,0),(3920,'UM','US','U.S. Minor Outlying Islands',NULL,0),(3921,'UT','US','Utah',NULL,0),(3922,'VA','US','Virginia',NULL,0),(3923,'VI','US','Virgin Islands of the U.S.',NULL,0),(3924,'VT','US','Vermont',NULL,0),(3925,'WA','US','Washington',NULL,0),(3926,'WI','US','Wisconsin',NULL,0),(3927,'WV','US','West Virginia',NULL,0),(3928,'WY','US','Wyoming',NULL,0),(3929,'UY-AR','UY','Artigas',NULL,0),(3930,'UY-CA','UY','Canelones',NULL,0),(3931,'UY-CL','UY','Cerro Largo',NULL,0),(3932,'UY-CO','UY','Colonia',NULL,0),(3933,'UY-DU','UY','Durazno',NULL,0),(3934,'UY-FA','UY','Florida',NULL,0),(3935,'UY-FS','UY','Flores',NULL,0),(3936,'UY-LA','UY','Lavalleja',NULL,0),(3937,'UY-MA','UY','Maldonado',NULL,0),(3938,'UY-MO','UY','Montevideo',NULL,0),(3939,'UY-PA','UY','Paysandu',NULL,0),(3940,'UY-RN','UY','Rio Negro',NULL,0),(3941,'UY-RO','UY','Rocha',NULL,0),(3942,'UY-RV','UY','Rivera',NULL,0),(3943,'UY-SJ','UY','San Jose',NULL,0),(3944,'UY-SL','UY','Salto',NULL,0),(3945,'UY-SO','UY','Soriano',NULL,0),(3946,'UY-TT','UY','Treinta y Tres',NULL,0),(3947,'UZ-AN','UZ','Andijon',NULL,0),(3948,'UZ-BU','UZ','Buxoro',NULL,0),(3949,'UZ-FA','UZ','Farg\'ona',NULL,0),(3950,'UZ-JI','UZ','Jizzax',NULL,0),(3951,'UZ-NG','UZ','Namangan',NULL,0),(3952,'UZ-NW','UZ','Navoiy',NULL,0),(3953,'UZ-QA','UZ','Qashqadaryo',NULL,0),(3954,'UZ-QR','UZ','Qoraqalpog\'iston Republikasi',NULL,0),(3955,'UZ-SA','UZ','Samarqand',NULL,0),(3956,'UZ-SI','UZ','Sirdaryo',NULL,0),(3957,'UZ-SU','UZ','Surxondaryo',NULL,0),(3958,'UZ-TK','UZ','Toshkent city',NULL,0),(3959,'UZ-TO','UZ','Toshkent region',NULL,0),(3960,'UZ-XO','UZ','Xorazm',NULL,0),(3961,'VC-A','VC','Saint Andrew',NULL,0),(3962,'VC-C','VC','Charlotte',NULL,0),(3963,'VC-D','VC','Saint David',NULL,0),(3964,'VC-G','VC','Saint George',NULL,0),(3965,'VC-P','VC','Saint Patrick',NULL,0),(3966,'VC-R','VC','Grenadines',NULL,0),(3967,'VE-A','VE','Federal District',NULL,0),(3968,'VE-B','VE','Anzoategui',NULL,0),(3969,'VE-C','VE','Apure',NULL,0),(3970,'VE-D','VE','Aragua',NULL,0),(3971,'VE-E','VE','Barinas',NULL,0),(3972,'VE-F','VE','Bolivar',NULL,0),(3973,'VE-G','VE','Carabobo',NULL,0),(3974,'VE-H','VE','Cojedes',NULL,0),(3975,'VE-I','VE','Falcon',NULL,0),(3976,'VE-J','VE','Guarico',NULL,0),(3977,'VE-K','VE','Lara',NULL,0),(3978,'VE-L','VE','Merida',NULL,0),(3979,'VE-M','VE','Miranda',NULL,0),(3980,'VE-N','VE','Monagas',NULL,0),(3981,'VE-O','VE','Nueva Esparta',NULL,0),(3982,'VE-P','VE','Portuguesa',NULL,0),(3983,'VE-R','VE','Sucre',NULL,0),(3984,'VE-S','VE','Tachira',NULL,0),(3985,'VE-T','VE','Trujillo',NULL,0),(3986,'VE-U','VE','Yaracuy',NULL,0),(3987,'VE-V','VE','Zulia',NULL,0),(3988,'VE-W','VE','Federal Dependency',NULL,0),(3989,'VE-X','VE','Vargas',NULL,0),(3990,'VE-Y','VE','Delta Amacuro',NULL,0),(3991,'VE-Z','VE','Amazonas',NULL,0),(3992,'VI-C','VI','Saint Croix',NULL,0),(3993,'VI-J','VI','Saint John',NULL,0),(3994,'VI-T','VI','Saint Thomas',NULL,0),(3995,'VN-AG','VN','An Giang',NULL,0),(3996,'VN-BC','VN','Bac Ninh',NULL,0),(3997,'VN-BG','VN','Bac Giang',NULL,0),(3998,'VN-BH','VN','Binh Dinh',NULL,0),(3999,'VN-BK','VN','Bac Kan',NULL,0),(4000,'VN-BL','VN','Bac Lieu',NULL,0),(4001,'VN-BN','VN','Ben Tre',NULL,0),(4002,'VN-BP','VN','Binh Phuoc',NULL,0),(4003,'VN-BR','VN','Ba Ria-Vung Tau',NULL,0),(4004,'VN-BT','VN','Binh Thuan',NULL,0),(4005,'VN-BU','VN','Binh Duong',NULL,0),(4006,'VN-CB','VN','Cao Bang',NULL,0),(4007,'VN-CM','VN','Ca Mau',NULL,0),(4008,'VN-CT','VN','Can Tho',NULL,0),(4009,'VN-DB','VN','Dien Bien',NULL,0),(4010,'VN-DG','VN','Dak Nong',NULL,0),(4011,'VN-DI','VN','Dong Nai',NULL,0),(4012,'VN-DL','VN','Dak Lak',NULL,0),(4013,'VN-DN','VN','Da Nang',NULL,0),(4014,'VN-DT','VN','Dong Thap',NULL,0),(4015,'VN-GL','VN','Gia Lai',NULL,0),(4016,'VN-HB','VN','Hoa Binh',NULL,0),(4017,'VN-HC','VN','Ho Chin Minh',NULL,0),(4018,'VN-HD','VN','Hai Duong',NULL,0),(4019,'VN-HG','VN','Ha Giang',NULL,0),(4020,'VN-HH','VN','Ha Tinh',NULL,0),(4021,'VN-HI','VN','Ha Noi',NULL,0),(4022,'VN-HM','VN','Ha Nam',NULL,0),(4023,'VN-HP','VN','Hai Phong',NULL,0),(4024,'VN-HT','VN','Ha Tay',NULL,0),(4025,'VN-HU','VN','Hau Giang',NULL,0),(4026,'VN-HY','VN','Hung Yen',NULL,0),(4027,'VU-MA','VU','Malampa',NULL,0),(4028,'VU-PE','VU','Penama',NULL,0),(4029,'VU-SA','VU','Sanma',NULL,0),(4030,'VU-SH','VU','Shefa',NULL,0),(4031,'VU-TA','VU','Tafea',NULL,0),(4032,'VU-TO','VU','Torba',NULL,0),(4033,'WF-A','WF','Alo',NULL,0),(4034,'WF-S','WF','Sigave',NULL,0),(4035,'WF-W','WF','Wallis',NULL,0),(4036,'WS-AI','WS','Aiga-i-le-Tai',NULL,0),(4037,'WS-AN','WS','A\'ana',NULL,0),(4038,'WS-AT','WS','Atua',NULL,0),(4039,'WS-FA','WS','Fa\'asaleleaga',NULL,0),(4040,'WS-GE','WS','Gaga\'emauga',NULL,0),(4041,'WS-GF','WS','Gagaifomauga',NULL,0),(4042,'WS-PA','WS','Palauli',NULL,0),(4043,'WS-SA','WS','Satupa\'itea',NULL,0),(4044,'WS-TU','WS','Tuamasaga',NULL,0),(4045,'WS-VF','WS','Va\'a-o-Fonoti',NULL,0),(4046,'WS-VS','WS','Vaisigano',NULL,0),(4047,'YE-AB','YE','Abyan',NULL,0),(4048,'YE-AD','YE','Adan',NULL,0),(4049,'YE-AM','YE','Amran',NULL,0),(4050,'YE-BA','YE','Al Bayda',NULL,0),(4051,'YE-DA','YE','Ad Dali',NULL,0),(4052,'YE-DH','YE','Dhamar',NULL,0),(4053,'YE-HD','YE','Hadramawt',NULL,0),(4054,'YE-HJ','YE','Hajjah',NULL,0),(4055,'YE-HU','YE','Al Hudaydah',NULL,0),(4056,'YE-IB','YE','Ibb',NULL,0),(4057,'YE-JA','YE','Al Jawf',NULL,0),(4058,'YE-LA','YE','Lahij',NULL,0),(4059,'YE-MA','YE','Ma\'rib',NULL,0),(4060,'YE-MR','YE','Al Mahrah',NULL,0),(4061,'YE-MW','YE','Al Mahwit',NULL,0),(4062,'YE-SD','YE','Sa\'dah',NULL,0),(4063,'YE-SH','YE','Shabwah',NULL,0),(4064,'YE-SN','YE','San\'a',NULL,0),(4065,'YE-TA','YE','Ta\'izz',NULL,0),(4066,'ZA-EC','ZA','Eastern Cape',NULL,0),(4067,'ZA-FS','ZA','Free State',NULL,0),(4068,'ZA-GT','ZA','Gauteng',NULL,0),(4069,'ZA-KN','ZA','KwaZulu-Natal',NULL,0),(4070,'ZA-LP','ZA','Limpopo',NULL,0),(4071,'ZA-MP','ZA','Mpumalanga',NULL,0),(4072,'ZA-NC','ZA','Northern Cape',NULL,0),(4073,'ZA-NW','ZA','North West',NULL,0),(4074,'ZA-WC','ZA','Western Cape',NULL,0),(4075,'ZM-CB','ZM','Copperbelt Province',NULL,0),(4076,'ZM-CE','ZM','Central Province',NULL,0),(4077,'ZM-EA','ZM','Eastern Province',NULL,0),(4078,'ZM-LK','ZM','Lusaka Province',NULL,0),(4079,'ZM-LP','ZM','Luapula Province',NULL,0),(4080,'ZM-NO','ZM','Northern Province',NULL,0),(4081,'ZM-NW','ZM','North-Western Province',NULL,0),(4082,'ZM-SO','ZM','Southern Province',NULL,0),(4083,'ZM-WE','ZM','Western Province',NULL,0),(4084,'ZW-BU','ZW','Bulawayo (city)',NULL,0),(4085,'ZW-HA','ZW','Harare (city)',NULL,0),(4086,'ZW-MC','ZW','Mashonaland Central',NULL,0),(4087,'ZW-MD','ZW','Midlands',NULL,0),(4088,'ZW-ME','ZW','Mashonaland East',NULL,0),(4089,'ZW-ML','ZW','Manicaland',NULL,0),(4090,'ZW-MN','ZW','Matabeleland North',NULL,0),(4091,'ZW-MS','ZW','Matabeleland South',NULL,0),(4092,'ZW-MV','ZW','Masvingo',NULL,0),(4093,'ZW-MW','ZW','Mashonaland West',NULL,0);
/*!40000 ALTER TABLE `am_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_store`
--

DROP TABLE IF EXISTS `am_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_store` (
  `store_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `blob_value` blob,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`store_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_store`
--

LOCK TABLES `am_store` WRITE;
/*!40000 ALTER TABLE `am_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_store_rebuild`
--

DROP TABLE IF EXISTS `am_store_rebuild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_store_rebuild` (
  `store_rebuild_id` int(11) NOT NULL AUTO_INCREMENT,
  `rebuild_name` char(32) NOT NULL,
  `session_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`store_rebuild_id`),
  UNIQUE KEY `full_name` (`rebuild_name`,`session_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_store_rebuild`
--

LOCK TABLES `am_store_rebuild` WRITE;
/*!40000 ALTER TABLE `am_store_rebuild` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_store_rebuild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_subusers_subscription`
--

DROP TABLE IF EXISTS `am_subusers_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_subusers_subscription` (
  `subusers_subscription_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`subusers_subscription_id`),
  UNIQUE KEY `user_list` (`product_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_subusers_subscription`
--

LOCK TABLES `am_subusers_subscription` WRITE;
/*!40000 ALTER TABLE `am_subusers_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_subusers_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_translation`
--

DROP TABLE IF EXISTS `am_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_translation` (
  `language` varchar(10) NOT NULL,
  `translations` mediumtext NOT NULL,
  PRIMARY KEY (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_translation`
--

LOCK TABLES `am_translation` WRITE;
/*!40000 ALTER TABLE `am_translation` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_upload`
--

DROP TABLE IF EXISTS `am_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_upload` (
  `upload_id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `prefix` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mime` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `delete` int(11) DEFAULT NULL,
  `uploaded` int(11) DEFAULT NULL,
  `storage_id` varchar(32) DEFAULT 'null',
  `admin_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`upload_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_upload`
--

LOCK TABLES `am_upload` WRITE;
/*!40000 ALTER TABLE `am_upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_upsell`
--

DROP TABLE IF EXISTS `am_upsell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_upsell` (
  `upsell_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `conditions` text,
  `configuration` text,
  PRIMARY KEY (`upsell_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_upsell`
--

LOCK TABLES `am_upsell` WRITE;
/*!40000 ALTER TABLE `am_upsell` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_upsell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_user`
--

DROP TABLE IF EXISTS `am_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL,
  `pass` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `name_f` varchar(64) NOT NULL,
  `name_l` varchar(64) NOT NULL,
  `street` varchar(255) DEFAULT NULL,
  `street2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `remote_addr` varchar(15) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `unsubscribed` tinyint(4) NOT NULL DEFAULT '0',
  `lang` varchar(32) DEFAULT NULL,
  `i_agree` tinyint(4) DEFAULT '0',
  `is_approved` tinyint(4) DEFAULT '1',
  `is_locked` tinyint(4) DEFAULT '0',
  `reseller_id` int(11) DEFAULT NULL,
  `comment` text,
  `tax_id` varchar(255) DEFAULT NULL,
  `aff_id` int(11) DEFAULT NULL,
  `is_affiliate` tinyint(4) DEFAULT NULL,
  `aff_payout_type` varchar(32) DEFAULT NULL,
  `directory_exclude` tinyint(4) DEFAULT NULL,
  `subusers_parent_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `login` (`login`),
  KEY `subusers` (`subusers_parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_user`
--

LOCK TABLES `am_user` WRITE;
/*!40000 ALTER TABLE `am_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_user_group`
--

DROP TABLE IF EXISTS `am_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_user_group` (
  `user_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `parent_id` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_group_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_user_group`
--

LOCK TABLES `am_user_group` WRITE;
/*!40000 ALTER TABLE `am_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_user_status`
--

DROP TABLE IF EXISTS `am_user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_user_status` (
  `user_status_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_status_id`),
  UNIQUE KEY `user_id` (`user_id`,`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_user_status`
--

LOCK TABLES `am_user_status` WRITE;
/*!40000 ALTER TABLE `am_user_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_user_user_group`
--

DROP TABLE IF EXISTS `am_user_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_user_user_group` (
  `user_user_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_group_id` int(11) NOT NULL,
  PRIMARY KEY (`user_user_group_id`),
  UNIQUE KEY `user_group` (`user_id`,`user_group_id`),
  KEY `user_group_id` (`user_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_user_user_group`
--

LOCK TABLES `am_user_user_group` WRITE;
/*!40000 ALTER TABLE `am_user_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_user_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am_video`
--

DROP TABLE IF EXISTS `am_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am_video` (
  `video_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `desc` text,
  `path` varchar(255) NOT NULL,
  `mime` varchar(64) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `dattm` datetime DEFAULT NULL,
  `hide` smallint(6) DEFAULT '0',
  `config` blob,
  PRIMARY KEY (`video_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am_video`
--

LOCK TABLES `am_video` WRITE;
/*!40000 ALTER TABLE `am_video` DISABLE KEYS */;
/*!40000 ALTER TABLE `am_video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-29  7:53:29
